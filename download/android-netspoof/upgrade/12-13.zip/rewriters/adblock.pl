#!/usr/bin/perl -w
#
# Release: 20110915 -> Wed Oct 19 20:28:37 EST 2011 (mozo-widgets)
#
# See the home page at:
#	http://adzapper.sourceforge.net/
# and the freshmeat record at:
#	http://freshmeat.net/projects/squid_redirect/
#
# Recode of the ad-zapper in perl.
# Only necessary because the shell seems to be failing big case statements.
# However, things are neater this way anyway because perl will build
# big optimised pattern matches.
#	- Cameron Simpson <cs@zip.com.au> 09apr1999
#
# Tunable policy by setting $STUBURL_xx to PASS.
#	- Cameron Simpson <cs@zip.com.au> 28jul1999
#
# Tunable CLEAR/VISIBLE mode by setting ZAP_MODE.
#	- Cameron Simpson <cs@zip.com.au> 26feb2000
#
# Personal zap pattern support.
#	- Cameron Simpson <cs@zip.com.au> 05mar2000
#
# Standalone proxy mode.
#	- Cameron Simpson <cs@zip.com.au> 02may2004
#

# Modified by digitalsquid.co.uk for Network Spoofer

use strict qw(vars);
use bytes;

use POSIX ":sys_wait_h";
use Socket;
require 'flush.pl';

$::IOSIZE=1024;

sub mkzapcode($);
sub mkredirectfn($);
sub proxy_forkchild($$$);
sub proxy_getheaders($);
sub proxy_lookup($);
sub proxy_main($$;$);
sub proxy_munge($$);
sub proxy_rigsocket($);
sub proxy_copybody($$$$$);

$::cmd=$0;

# restart hook
$SIG{HUP}=sub { exec($0,@ARGV) };

# what to do if we don't change anything - Johannes Berg <johannes@sipsolutions.net>
$::NoChangeValue=( defined $ENV{ZAP_NO_CHANGE} ? $ENV{ZAP_NO_CHANGE} : '' );

# where to find the replacement URLs
$::StubBase=( defined $ENV{ZAP_BASE} && length $ENV{ZAP_BASE}
	    ? $ENV{ZAP_BASE}
	    : 'http://127.0.0.1/adblock'
	    );
# not actually useful, because SSL doesn't go via the proxy
$::SSLStubBase=( defined $ENV{ZAP_BASE_SSL} && length $ENV{ZAP_BASE_SSL}
	       ? $ENV{ZAP_BASE_SSL}
	       : 'https://127.0.0.1/adblock'
	       );
$::SSLStubBase =~ s/^http:/https:/;	# in case

# we always zap ads, web bugs and counters so set default placeholders
$::StubURLs{NOZAP}=1;		# http://noads/ bypasses the zapper
$::StubURLs{AD}="$::StubBase/blank.png";
$::StubURLs{ADSSL}="$::SSLStubBase/blank.png";
$::StubURLs{ADBG}="$::StubBase/blank.png";
$::StubURLs{ADPOPUP}="$::StubBase/close.htm";
$::StubURLs{ADJS}="$::StubBase/blank.js";
$::StubURLs{ADHTML}="$::StubBase/blank.htm";
$::StubURLs{COUNTER}="$::StubBase/blank.png";
$::StubURLs{COUNTERJS}="$::StubBase/blank.js";
$::StubURLs{COUNTERHTML}="$::StubBase/blank.htm";
$::StubURLs{WEBBUG}="$::StubBase/blank.png";
$::StubURLs{WEBBUGJS}="$::StubBase/blank.js";
$::StubURLs{WEBBUGHTML}="$::StubBase/blank.htm";
$::StubURLs{ADMP3}="$::StubBase/ad.mp3";
$::StubURLs{ADSWF}="$::StubBase/ad.swf";
$::StubURLs{PRINT}=IGNORE;	# PRINT rules disabled by default
$::StubURLs{REWRITE}=1;		# typeless rewrite
$::StubURLs{ANTICRACK}=$::StubURLs{AD};	# vehicles for crackers
$::StubURLs{ADHTMLTEXT}=$::StubURLs{ADHTML};
$::StubURLs{ADJSTEXT}=$::StubURLs{ADJS};

# make use of the qr() syntax to precompile pattern REs?
# I'd do this based on perl version if I could find out when it came in...
$::UseQR=0;
if (defined $ENV{ZAP_USE_QR} && length($ENV{ZAP_USE_QR}))
{ $::UseQR=1;
}
@::ZapRE=();

# backwards compatible
if (defined $ENV{STUBURL} && length $ENV{STUBURL}
 && ! defined $ENV{STUBURL_AD})
{ $ENV{STUBURL_AD}=$ENV{STUBURL};
}

# arrange paths for the active zap classes
{ my @classes = grep(/^STUBURL_/, keys %ENV);
  for (@classes)
  { $_ =~ s/^STUBURL_//;
  }

  for my $class (@classes)
  { $::StubURLs{$class}=$ENV{"STUBURL_$class"}
	if defined $ENV{"STUBURL_$class"}
	&& length  $ENV{"STUBURL_$class"}
	;
  }
}

# use the "clear" versions if ZAP_MODE is "CLEAR"
if (defined $ENV{ZAP_MODE} && $ENV{ZAP_MODE} eq CLEAR)
{ for my $type (keys %::StubURLs)
  { $::StubURLs{$type} =~ s/\.[^.]+$/-clear$&/;
  }
}

# "generate perl" mode
if (@ARGV == 2 && $ARGV[0] eq '--generate')
{ my $ptnfile=$ARGV[1];
  if ($ptnfile eq '-')
  {}
  elsif (! open(STDIN,"< $ptnfile\0"))
  { die "$::cmd: can't open $ptnfile: $!\n";
  }

  print mkzapcode(STDIN);
  exit 0;
}

$::Verbose=0;
$::DoProxy='';
undef $::LogFile;
if (exists $ENV{ZAP_LOGFILE} && length($ENV{ZAP_LOGFILE}))
{ $::LogFile=$ENV{ZAP_LOGFILE};
}

GETOPT:
while (@ARGV)
{ if ($ARGV[0] eq '-v')
  { $::Verbose=1;
    shift(@ARGV);
  }
  elsif ($ARGV[0] eq '-P')
  { shift(@ARGV);
    $::DoProxy=shift(@ARGV);
  }
  elsif ($ARGV[0] eq '-l')
  { shift(@ARGV);
    $::LogFile=shift(@ARGV);
  }
  elsif ($ARGV[0] =~ /^-./)
  { die "$::cmd: unsupported command like option: $ARGV[0]\n";
  }
  else
  { last GETOPT;
  }
}

if (defined $::LogFile)
{ open(LOGFILE,">> $::LogFile\0")
    || die "$::cmd: can't append to $::LogFile: $!\n";
}

# Note: the $ZAP_CHAINING variable is obsolete.
#       It was originally intented for piping redirectors
#	together, but that simply doesn't work right because
#	of the protocol specification.
#	Instead, use the wrapzap script.
$::Chaining = ( exists $ENV{ZAP_CHAINING} && length $ENV{ZAP_CHAINING}
	      ? $ENV{ZAP_CHAINING} eq 'FULL'
		? 2
		: 1
	      : 0
	      );

undef $::PreMatch;
if (defined $ENV{ZAP_PREMATCH} && -s $ENV{ZAP_PREMATCH})
{ if (open(PTNS,"< $ENV{ZAP_PREMATCH}\0"))
  { $::PreMatch=mkredirectfn(PTNS);
    close(PTNS);
  }
  else
  { warn "$::cmd: can't open \$ZAP_PREMATCH ($ENV{ZAP_PREMATCH}: $!";
  }
}

if (defined $ENV{ZAP_MATCH} && -s $ENV{ZAP_MATCH})
{ if (open(PTNS,"< $ENV{ZAP_MATCH}\0"))
  { $::Redirect=mkredirectfn(PTNS);
    close(PTNS);
  }
  else
  { warn "$::cmd: can't open \$ZAP_MATCH ($ENV{ZAP_MATCH}: $!";
  }
}
else
{ $::Redirect=mkredirectfn(DATA);
}

undef $::PostMatch;
if (defined $ENV{ZAP_POSTMATCH} && -s $ENV{ZAP_POSTMATCH})
{ if (open(PTNS,"< $ENV{ZAP_POSTMATCH}\0"))
  { $::PostMatch=mkredirectfn(PTNS);
    close(PTNS);
  }
  else
  { warn "$::cmd: can't open \$ZAP_POSTMATCH ($ENV{ZAP_POSTMATCH}: $!";
  }
}

# -P lport:rproxy:rport
if (length $::DoProxy)
{ if ($::DoProxy =~ /^((\d+):)?([^:]+):([^:]+)$/)
  { my($lport,$rproxy,$rport)=($2,$3,$4);
    $lport=8080 if ! length $lport;
    warn "proxy_main($lport,\"$rproxy:$rport\",5) ...";
    proxy_main($lport,"$rproxy:$rport",5);
  }

  exit 0;
}

while (defined ($_=<STDIN>))
{
  if (defined $::LogFile)
  { print LOGFILE $_;
    flush(LOGFILE);
  }
  chomp;
  
  my @words = split;

  my $ourl = $words[0];
  my $nurl = '';	# gets set on a redirection

  if (@words == 1 || $words[3] eq GET)
  { $nurl=redirect(@words);
  }

  if (! $::Chaining)
  { print "$nurl\n";
  }
  else
  { $nurl=$ourl if ! length $nurl;

    if ($::Chaining == 1)
    { print "$nurl\n";
    }
    else
    { print "$nurl @words[1..$#words]\n";
    }
  }

  flush(STDOUT);
}

exit 0;

# We need to deal correctly with whitespace and %xx stuff.
# Report from Rod Savard 29mar2004.
sub unpcnt($)
{ my($txt)=@_;
  $txt =~ s/%([0-9a-f][0-9a-f])/eval "chr(0x$1)"/eg;
  return $txt;
}

sub pcnt($)
{ my($txt)=@_;
  ##my $otxt = $txt;
  $txt =~ s/[\s'"\000-\031\177-\377]/sprintf("%%%02x",ord($&))/eg;
  ##warn "<= $otxt\n=> $txt\n";
  return $txt;
}

sub redirect
{ my(@words)=@_;

  my $nurl='';

  if (defined $::PreMatch)
  { $nurl=&$::PreMatch(@words);
  }
  if (! length $nurl)
  { $nurl=&$::Redirect(@words);
  }
  if ( ! length $nurl && defined $::PostMatch)
  { $nurl=&$::PostMatch(@words);
  }
  if ( ! length $nurl )
  { $nurl=$::NoChangeValue;
  }


  return pcnt($nurl);
}

# Read pattern specs from a stream and turn into perl code.
# Patterns are shell-style patterns, except that:
#	** matches strings including /
#	? is not a meta character
#	. isn't either
#	\ doesn't work
# - Cameron Simpson <cs@zip.com.au> 09apr1999
#

sub mkzapcode($)
{ my($STREAM)=@_;

  my $code = "y|/||s;
	      if (0) {}\n";
  my $ncode;

  my $lastclass;
  my @ptns;

  local($_);

  RULE:
  while (defined($_=<$STREAM>))
  { chomp;

    s/^\s+//;
    s/^#.*//;
    next if ! length;

    my(@F)=split;
    if (@F < 2 || @F > 3)
    { warn "$::cmd: $STREAM, line $.: wrong number of arguments\n\tneed CLASS pattern\n\tor   CLASS pattern subst\n";
      next RULE;
    }

    my($class)=shift(@F);
    $class=uc($class);

    # avert our eyes from some classes
    if ($class ne PASS
     && ( ! exists($::StubURLs{$class})
       || $::StubURLs{$class} eq IGNORE
	))
    { ##warn "skip (class=$class) $_\n";
      next RULE;
    }

    if (@F == 1)
    # plain match
    {
      my $ptn = shift(@F);

      $lastclass=$class if ! defined $lastclass;
      if ($class ne $lastclass)
      { if (@ptns)
	{ $code.=process($lastclass,@ptns);
	  @ptns=();
	}

	$lastclass=$class;
      }

      push(@ptns,$ptn);
    }
    elsif (@F == 2)
    # rewrite
    { my($ptn,$subst)=@F;

      # flush pending patterns
      if (@ptns)
      { $code.=process($lastclass,@ptns);
	@ptns=();
      }

      undef $lastclass;

      # for debugging
      my $ptndesc = "$class $ptn $subst";
      $ptndesc =~ s/['\\]/\\$&/g;

      $ptn='^'.ptn2re($ptn).'$';
      my $ptnexpr = re2expr($ptn);

      $code.="  elsif($ptnexpr)\n"
	    ."  { \$nurl=\"$subst\";\n"
	    ."    if (\$::Verbose)\n"
	    ."    { warn \"$class \$_\\non:\\n\".'$ptndesc'.\"\\n\";\n"
	    ."    }\n"
	    ."  }\n";
    }
    else
    { warn "$::cmd: $STREAM, line $.: unhandled number of fields [@F]\n\t";
    }
  }

  # flush pending patterns
  $code.=process($lastclass,@ptns) if @ptns;

  $code.="  elsif (\$::Verbose)\n"
	."  { warn \"PASS \$_ on no match\\n\";\n"
	."  }\n";

  $code;
}


sub subptn2re($)
{ local($_)=@_;
  return "[^/]*" if $_ eq '*';	# * -> [^/]*
  return ".*" if /^\*+$/;	# ** -> .*
  return $_;			# leave everything else alone
}

sub ptn2re($)
{ local($_)=@_;
  y|/||s;				# turn slashes into "/+"
  s|[.\@\%\$?+]|\\$&|g;			# quote specials
  s:(\\.|[^*\\]|\*+):subptn2re($&):eg;
  return $_;
}

sub re2expr
{ my($re)=@_;

  # old style compile-on-first-use
  return "m($re)o" if ! $::UseQR;

  # new style - force compilation now
  my $qr = eval 'qr($re)o';
  if ($@)
  { warn "$::cmd: qr fails: qr($re): $@";
    $::UseQR=0;
    return "m($re)o";
  }

  push(@::ZapRE,$qr);
  my $expr = "/\$::ZapRE[$#::ZapRE]/";
  warn "re=[ $re ]\nexpr=[ $expr ]";
  return $expr;
}

sub process
{ my($class)=shift;
  my(@ptns)=@_;

  my $nurl;

  if ($class eq PASS)
  { $nurl=PASS;
  }
  else
  # we trimmed unknown classes and IGNORE classes in mkzapcode()
  # so we can believe this without further checks
  { $nurl = $::StubURLs{$class};
  }

  my $code = '';

  # for debugging
  my $ptndesc = join("\n\t\t\t", map("$class $_", @ptns));
  $ptndesc =~ s/['\\]/\\$&/g;

  local($_);

  # transmute patterns into regexps
  @ptns=map(ptn2re($_),@ptns);

  # was joined with \n\t| but older perls don't like that
  my $bigptn = '^('.join('|', @ptns).')$';
  my $ptnexpr = re2expr($bigptn);

  $code.="  elsif ($ptnexpr)\n";
  if ($nurl eq PASS)
	{ $code.="  { \$nurl=\$url;\n"
		."    warn \"PASS \$_\\non:\\t\\t\\t\".\n\t\t\t'$ptndesc'.\"\\n\" if \$::Verbose;\n"
		."  }\n";
	}
  else	{ $code.="  { \$nurl=\$::StubURLs{$class};\n"
		."    if (\$::Verbose)\n"
		."    { warn \"$class \$_\\non:\\t\\t\\t\"\n\t\t\t.'$ptndesc'.\"\\n\";\n"
		."    }\n"
		."  }\n";
	}

  return $code;
}

sub mkredirectfn($)
{ my($STREAM)=@_;

  my $fn = 'sub { my($url,$client,$ident,$method)=@_;
		  local($_)=unpcnt($url);

		  my $nurl = "";
	   '
	 . mkzapcode($STREAM)
	 . '
		  return $nurl;
	    }';

  my $fnref;
  eval "\$fnref=$fn";
  if ($@)
  { warn "$::cmd: error compiling function: $@\n\tcode is:\n$fn\n";
    undef $fnref;
  }

  return $fnref;
}

sub proxy_term($)
{ my($sig)=@_;
  if ($$ == $::ProxyMainPid)
  {
    for my $pid (@::ProxyChildren)
    { kill($pid,15);
    }
  }
  exit 1;
}

sub proxy_main($$;$)
{ my($listen_port,$upstream,$nforks)=@_;
  $nforks=5 if ! defined $nforks;

  # nail children on abort
  @::ProxyChildren=();
  $::ProxyMainPid=$$;
  $SIG{__DIE__}=\&proxy_term;
  $SIG{HUP}=\&proxy_term;
  $SIG{INT}=\&proxy_term;
  $SIG{TERM}=\&proxy_term;

  local($::TCP_Proto)=scalar(getprotobyname('tcp'));
  ##warn "[$$]: TCP_Proto=[$::TCP_Proto]";

  my($proxy_name,$proxy_port,$proxy_addr,$proxy_paddr)
   = proxy_lookup($upstream);

  # set up token stream
  pipe(FROMCHILD, TOPARENT) || die "$::cmd: pipe: $!";

  proxy_rigsocket($listen_port);

  warn "[$$]: listening on port $listen_port ...\n";

  for my $i (1..$nforks)
  { push(@::ProxyChildren,proxy_forkchild($proxy_paddr,$proxy_name,$proxy_port));
  }

  # spawn new children as the old children die
  while (<FROMCHILD>)
  {
    # grab any dead children
    my $pid;
    while (($pid=waitpid(-1,WNOHANG)) > 0)
    { ##warn "[$$]: waitpid got something\n";
      @::ProxyChildren=grep($_ != $pid, @::ProxyChildren);
    }

    # spawn fresh child
    push(@::ProxyChildren,proxy_forkchild($proxy_paddr,$proxy_name,$proxy_port));
  }

  die "[$$]: exit from supposed main (parent is ".getppid().")";
}

sub proxy_lookup($)
{ my($upstream)=@_;

  my $proxy_name = 'proxy';
  my $proxy_port = 8080;
  my $proxy_addr;
  my $proxy_paddr;

  if ($upstream =~ /^(\S+):(\S+)$/)
  { $proxy_name=$1;
    $proxy_port=$2;
  }
  elsif (length $upstream)
  { $proxy_name=$upstream;
  }

  if ($proxy_port =~ /^\D/)
  { $proxy_port=getservbyname($proxy_port, 'tcp');
    die "$::cmd: No proxy port" unless $proxy_port;
  }

  $proxy_addr = inet_aton($proxy_name) || die "$::cmd: can't look up \"$proxy_name\"";
  $proxy_paddr = sockaddr_in($proxy_port, $proxy_addr);

  return ($proxy_name,$proxy_port,$proxy_addr,$proxy_paddr);
}

sub proxy_rigsocket($)
{ my($listen_port)=@_;
  die "$::cmd: socket: $!" if ! socket(SOCK, PF_INET, SOCK_STREAM, $::TCP_Proto);

  die "$::cmd: setsockopt: $!" if ! setsockopt(SOCK,
					SOL_SOCKET,
					SO_REUSEADDR,
					pack("l", 1));

  ##warn "[$$]: bind to port $listen_port ...";
  die "$::cmd: bind: $!" if ! bind(SOCK, sockaddr_in($listen_port, INADDR_ANY));

  die "$::cmd: listen: $!" if ! listen(SOCK,SOMAXCONN);
  ##system("netstat -an | grep $listen_port");
}

sub proxy_forkchild($$$)
{ my($proxy_paddr,$proxy_name,$proxy_port)=@_;

  my $pid;
  if (! defined ($pid=fork))
  { die "$::cmd: fork fails: $!";
  }

  # parent returns, child proceeds
  return $pid if $pid != 0;

  ##warn "[$$]: new child forked...";

  # we don't need this
  close(FROMCHILD);

  my $ok = accept(CONN,SOCK);
  die "$::cmd: accept: $!" if !$ok;
  # tell parent we need a new child
  print TOPARENT "\n";
  close(TOPARENT);
  ##warn "[$$]: new child: accepted";
  close(SOCK);	# let go of socket

  my $persist=1;
  my @hdrs;
  my $gotproxy=0;
  my($method,$uri,$v1,$v2);
  local($_);
  my $pass=0;
  my $orq;
  my $grandchild;

  REQUEST:
  while ($persist)
  {
    ++$pass;

    warn "[$$]: pass $pass: waiting for request ...\n";
    if ($pass > 1)
    { ##warn "[$$]:      last rq was $orq\n";
    }

    # read request
    if (! defined($_=<CONN>))
    { ##warn "[$$]: EOF from client, quitting\n";
      if ($gotproxy)
      { ##warn "[$$]: killing grandchild $grandchild\n";
	kill(15,$grandchild)
		|| warn "$::cmd: [$$]: kill(TERM,$grandchild): $!";
      }
      exit 0;
    }

    chomp;
    s/\r$//;
    s/\s+$//;

    if (! m:^(\S+)\s+(.*\S)\s+HTTP/0*(\d)\.0*(\d+)\s*\r?$:)
    { warn "$::cmd: bad syntax from client: $_";
      print CONN "400 Invalid HTTP request: $_\r\n";
      exit 0;
    }

    ($method,$uri,$v1,$v2)=($1,$2,$3+0,$4+0);
    $orq="$method $uri HTTP/$v1.$v2";
    warn "[$$]: pass $pass: $orq\n";

    # or depend on keep-alive? check >= 1.1
    $persist = ($v1 > 1 || ($v1 == 1 && $v2 >= 1));
    ##warn "[$$]: persist from request = [$persist]";

    # gather up the request
    @hdrs=proxy_getheaders(CONN);

    ## see if "Connection: close" supplied
    if (grep(uc($_->[0]) eq CONNECTION && $_->[1] =~ /\bclose\b/i, @hdrs))
    { $persist=0;
      ##warn "[$$]: disable persist by Connection: close";
    }

    ## munge URL here and adjust Host: if changed
    { my $muri = $uri;	# URI to munge

      # turn into absolute URL if necessary
      if ($muri !~ m|^[a-z][-a-z\d+.]*:|i)
      # no scheme - add http:// and Host
      { my @hosts = map($_->[1], grep(uc($_->[0]) eq HOST, @hdrs));
	if (@hosts)
	# yes, there is a Host: header
	{ @hosts = grep(length,split(/\s+/,$hosts[0]));
	  if (@hosts)
	  # yes, there's a host in the first Host: header
	  { $muri = "/$muri" unless $muri =~ m:^/:;
	    $muri="http://".lc($hosts[0])."$muri";
	  }
	}
      }

      my $nuri=proxy_munge($muri,$method);

      if ($nuri ne $muri)
      {
	warn "[$$]: ouri: $muri\n";
	warn "[$$]: nuri: $nuri\n";

	$uri=$nuri;

	# see if we need to change the Host: header
	if ($muri =~ m|^https?://([^@/]*@)?([^/:]+)(:[^/]*)?/|i)
	{ my $ohost=lc($2);
	  if ($nuri =~ m|^https?://([^@/]*@)?([^/]+)/|i)
	  { my $nhost=lc($2);
	    if ($nhost ne $ohost)
	    { for my $H (@hdrs)
	      { if (uc($H->[0]) eq HOST)
		{ ##warn "[$$]: $H->[0]: $H->[1] -> $nhost\n";
		  $H->[1]=" $nhost";
		}
	      }
	    }
	  }
	}
      }
    } ## end of munge

    my $proxyagain=1;

    PROXYLOOP:
    while($proxyagain)
    {
      # we general run this loop only once
      $proxyagain=0;

      # ready to go - connect to upstream server if necessary
      if (! $gotproxy)
      {
	# channel to report persistence
	# \n - persist
	# EOF - close upstream connection and refork, reconnect on next rq
	pipe(FROMGRANDCHILD, TOCHILD) || die "$::cmd: [$$]: pipe: $!";
	pipe(GCHILD_READ, GCHILD_WRITE) || die "$::cmd: [$$]: pipe: $!";

	# connection to upstream
	socket(PROXY, PF_INET, SOCK_STREAM, $::TCP_Proto)
	  || die "$::cmd: proxy socket: $!";
	connect(PROXY, $proxy_paddr)
	  || die "$::cmd: connect($proxy_name:$proxy_port): $!";

	$gotproxy=1;
	##warn "[$$]: connected to proxy\n";

	# fork child to stream proxy responses
	my $child=$$;
	$grandchild = fork();
	if ($grandchild < 0)
	{ my $err = "$!";
	  warn "$::cmd: fork: $err";
	  print CONN "503 fork: $err\r\n";
	  exit 0;
	}

	if ($grandchild == 0)
	# child - copy proxy output
	# this used to be a straight copy
	# but we must parse and honour "Connection: close"
	# from upstream
	{ proxy_grandchild($child);
	  exit 0;
	}

	# parent - fall through and handle connection
	close(TOCHILD);
	close(GCHILD_READ);
      }

      # dispatch request and headers
      printflush(GCHILD_WRITE,"$method $uri $v1 $v2\n")
	|| die "tell grandchild the request: $!";

      print PROXY "$method $uri HTTP/$v1.$v2\r\n";
      for my $H (@hdrs)
      { print PROXY $H->[0], ":", $H->[1], "\r\n";
      }
      printflush(PROXY,"\r\n");
      ##warn "[$$]: sent rq to proxy\n";

      proxy_copybody(CONN,PROXY,$method,$persist,\@hdrs)
	|| die "copybody up to PROXY failed: $!";

      ##warn "[$$]: end request for $uri\n";

      # read [persist response] from child
      if (!defined($_=<FROMGRANDCHILD>))
      { $gotproxy=0;
	close(FROMGRANDCHILD);
	warn "[$$]: abort from grandchild, retrying with new grandchild";
	$proxyagain=1;
	next PROXYLOOP;
      }
      chomp; s/\r$//; s/\s+$//;
      warn "[$$]: grandchild said [$_]\n";
      if (!/^([A-Z]+)\s+(\d\d\d)\s*/)
      { warn "[$$]: bad grandchild return, bailing out";
	exit 0;
      }
      my($gchoice,$gresponse,$getc)=($1,$2,$3);
      if ($gchoice eq PERSIST)
      { $persist=1;
      }
      elsif ($gchoice eq CLOSE)
      { $persist=0;
      }
      else
      { die "[$$]: unsupported choice \"$gchoice\", aborting";
      }

      warn "[$$]: loop bottom: persist=$persist";
    }	# end of PROXYLOOP
  }	# end of REQUEST $persist loop

  ##warn "[$$]: child exits";

  exit 0;
}

sub proxy_getheaders($)
{ my($conn)=@_;

  # list of [field,body] pairs
  my @hdrs=();

  local($_);

  my($f,$b);

  HEADER:
  while (defined($_=<$conn>))
  {
    # trim end of line
    chomp;
    s/\r$//;

    last HEADER if ! length;

    if (/^[ \t]/)
    # continuation
    { $b.="\r\n$_";
    }
    else
    # end of current header, start new
    {
      # stash pending header, if any
      if (defined $f)
      { ##warn "[$$]: [$f: $b]";
	push(@hdrs,[$f,$b]);
	undef $f;
	undef $b;
      }

      if (/^([^:\s]+):/)
      # new header
      { $f=$1; $b=$';
      }
      else
      { s/\s+$//;
	warn "$::cmd: bad header line: $_\n\tending header read";
	last HEADER;
      }
    }
  }

  # stash pending header, if any
  if (defined $f)
  { ##warn "[$$]: [$f: $b]";
    push(@hdrs,[$f,$b]);
    undef $f;
    undef $b;
  }

  ##warn "[$$]: got headers";
  return @hdrs;
}

sub proxy_grandchild($)
{ my($child)=@_;

  close(FROMGRANDCHILD);
  close(GCHILD_WRITE);

  select(CONN);
  $|=1;

  ##warn "[$child:$$]: grandchild, copying from proxy ...\n";

  local($_);
  my $rq;

  RESPONSE:
  while (defined($rq=<GCHILD_READ>) && defined($_=<PROXY>))
  {
    my($rq_method, $rq_uri, $rq_v1, $rq_v2)=split(/\s+/,$rq);

    # collect response line
    if (! m:^HTTP/(\d+)\.0*(\d+)\s+(\d\d\d)\s*([^\r\n]*):)
    { warn "$::cmd: [$child:$$]: bad response from proxy: $_\n";
      close(TOCHILD);
      last RESPONSE;
    }

    my($v1,$v2,$code,$info)=($1,$2,$3,$4);
    warn "[$$:$child]: [HTTP/$v1.$v2 $code $info]\n";

    # collect response headers
    my @hdrs = proxy_getheaders(PROXY);
    for my $H (@hdrs)
    { warn "  $H->[0]:$H->[1]\n";
    }

    # adjust persistence based on response code and headers

    # disable persistence for HTTP/1.0 and below by default,
    # then permit it if "Proxy-Connection: keep-alive"
    my $persist = 1;
    if ($v1 < 1 || ($v1 == 1 && $v2 < 1))
    { $persist=0; warn "[$child:$$]: disable persist - HTTP < 1.1\n";

      if (0&&grep( uc($_->[0]) eq 'PROXY-CONNECTION'
	     && $_->[1] =~ /\bkeep-alive\b/i,
		@hdrs
	      )
	 )
      { $persist=1;
	warn "[$child:$$]: enable persist by proxy's Proxy-Connection: keep-alive";
      }
    }
    else
    { warn "disable persist for HTTP/$v1.$v2 response anyway\n";
      $persist=0;
    }

    # see if "Connection: close" supplied
    # or "Proxy-Connection: close" (from Netscape-Enterprise/3.6 SP3)
    if (grep( ( uc($_->[0]) eq CONNECTION
	     || uc($_->[0]) eq "PROXY-CONNECTION"
	      ) && $_->[1] =~ /\bclose\b/i,
	     @hdrs)
       )
    { $persist=0;
      warn "[$child:$$]: disable persist by proxy's Connection: close";
    }

    warn "[$child:$$]: pass response to parent\n";
    printflush(TOCHILD,($persist ? PERSIST : CLOSE)." $code $info")
	|| die "[$child:$$]: print(TOCHILD) fails: $!";
    warn "[$child:$$]: told parent, passing response to client\n";

    # copy to child
    print CONN "HTTP/$v1.$v2 $code $info\r\n";
    for my $H (@hdrs)
    { print CONN $H->[0], ":", $H->[1], "\r\n";
    }
    printflush(CONN,"\r\n");

    # see RFC2616 section 10
    if (
	$rq_method ne HEAD
     && (
	  $code == 200 && grep($rq_method eq $_,GET,POST,TRACE)
       || grep($code == $_, 201,202,203,206,
			    300,301,302,303,307,
			    401,403,404,406,409)
       || $code =~ /^5/
	)
       )
    { 
      proxy_copybody(PROXY,CONN,'',$persist,\@hdrs)
	|| die "copybody from PROXY to CLIENT fails: $!";
    }

    last RESPONSE if !$persist;
    warn "[$child:$$]: getting next PROXY response...\n";
  }

  warn "[$child:$$]: exiting\n";
  exit 0;
}

sub proxy_copybody($$$$$)
{ my($from,$to,$method,$persist,$H)=@_;

  my $ok=1;
  my $err;

  warn "[$$]: copybody($from,$to,...)\n";
  ## copy the body, if any
  ## deduce length according to RFC2616 part 4.4
  my @te = grep(uc($_->[0]) eq 'TRANSFER-ENCODING', @$H);
  if (@te && uc($te[0]->[1]) ne IDENTITY)
  # expect chunked data transfer
  { my($ok,$err)=proxy_copychunked($from,$to);
  }
  else
  # expect ordinary body, possibly with Content-Length
  {
    my $cl = undef;
    my @cl = grep(uc($_->[0]) eq 'CONTENT-LENGTH', @$H);
    if (@cl)
    { $cl=$cl[0]->[1]+0;
      warn "  content-length=$cl\n";
    }
    elsif ($persist)
    { $cl=0;	# assume no body
    }

    if ($persist ? 1 : ($method ne GET && $method ne HEAD))
    # copy body using Content-Length
    { ($ok,$err)=proxy_copycl($from,$to,$cl);
    }
  }
  warn "[$$]: copybody done\n";

  return $ok;
}

sub proxy_copycl($$$)
{ my($from,$to,$cl)=@_;

  my $ok=1;

  warn "[$$]: reading unchunked body from $from";
  local($_)='';
  COPY:
  while ((!defined($cl) || $cl > 0)
      && read($from,$_,(defined $cl && $cl < $::IOSIZE ? $cl : $::IOSIZE)) > 0
	)
  {
    ##warn "[$$]: read ".length($_)." bytes of request body\n";
    if (! printflush($to,$_))
    { warn "$::cmd: [$$]: printflush($to,..): $!";
      $ok=0;
      last COPY;
    }
    $cl-=length if defined $cl;
  }
  warn "[$$]: finished unchunked body, ok=$ok";

  return ($ok,"");
}
sub proxy_copychunked($$)
{ my($from,$to)=@_;

  local($_);
  my $chunksize;

  CHUNK:
  while (defined($_=<$from>))
  {
    if (! /^([\da-f]+)/)
    { return (0,"bad chunk size: $_");
    }
    $chunksize=eval("0x$1");
    print $to $_;

    last CHUNK if $chunksize == 0;
    
    $_='';
    while ($chunksize > 0 && read($from,$_,($chunksize < $::IOSIZE ? $chunksize : $::IOSIZE)) > 0)
    { print $to $_;
      $chunksize-=length;
    }
    flush($to);
  }

  flush($to);

  # pass trailer headers
  while (defined($_=<$from>) && !/^\r?\n/)
  { print $to $_;
  }
  if (defined)
  { ##warn "[$$]: final trailer: $_";
    print $to $_;
  }
  flush($to);

  return (1,"");
}

sub proxy_munge($$)
{ my($uri,$method)=@_;

  my $nuri = redirect($uri,'-','-',$method);
  $uri=$nuri if length $nuri;

  return $uri;
}

__DATA__
##
## Last updated Wed Oct 19 20:28:37 EST 2011 (mozo-widgets).
##
#list commen
NOZAP (*://**)?NOZAP $1
PRINT http://((www*.|)washingtonpost.com)/wp-dyn/articles/(A[0-9]*).html http://$1/ac2/wp-dyn/$3?language=printer
PRINT http://((www*.|)news.utoronto.ca)/bin6/(*).asp http://$1/bin6/print/$3.htm
PRINT http://(www*.|)gamegirladvance.com/(archives/20[0-9][0-9]/[0-9][0-9]/[0-9][0-9]/*).html http://www.gamegirladvance.com/$2-print.html
PRINT http://(www*.|)internetnews.com/(*)/article.php/([0-9]*) http://www.internetnews.com/$2/print.php/$3
PRINT (http://(www*.|)enterpriseitplanet.com/**)/article.php/([0-9]*) $1/print.php/$3
PRINT http://(www*.|)wi-fiplanet.com/news/article.php/([0-9]*) http://www.wi-fiplanet.com/news/print.php/$2
PRINT http://(www*.|)smh.com.au(/articles/**.html) http://www.smh.com.au/cgi-bin/common/popupPrintArticle.pl?path=$2
PRINT http://(www*.|)zdnet.com.au/newstech/**/0,([0-9]*),([0-9]*),00.htm http://www.zdnet.com.au/printfriendly?AT=$2-$3
PRINT https://freeinternetpress.com/modules.php?name=News&file=article&sid=(*) 302:http://freeinternetpress.com/modules.php?name=News&file=print&sid=$1
PRINT http://*.zdnet.com/*/stories/*/0,14179,(*),00.html http://www.zdnet.com/filters/printerfriendly/0,6061,$1-92,00.html
PRINT http://news.zdnet.co.uk/story/0,,t([0-9]*)-s([0-9]*),00.html http://news.zdnet.co.uk/cgi-bin/uk/printerfriendly.cgi?id=$2&tid=$1
PRINT http://(*.zdnet.co.uk)/**/0,([0-9]*[0-9]),([0-9]*[0-9]),00.htm http://www.zdnet.co.uk/print/?TYPE=story&AT=$3-$2t-10000018c
PRINT http://www.zdnet.com.au/news/(*)/0,(*),(*),00.htm http://www.zdnet.com.au/news/$1/print.htm?TYPE=story&AT=$3-$2-10000004c
##PRINT http://(news.|)zdnet.com(|.com)/[0-9][0-9][0-9][0-9]-(*).html* http://$1zdnet.com$2/2102-$3.html?tag=printthis
PRINT http://zdnet.com.com/m/2100-([0-9]*_[0-9]-*).html* http://zdnet.com.com/2102-$1.html?tag=printthis
PRINT http://((www*.|)fool.com)/N(ews/mft/20[0-9][0-9]/mft*.htm) http://$1/Server/FoolPrint.asp?File=/n$3
PRINT http://(*.silicon.com)/(**)/0,([0-9]*[0-9]),([0-9]*[0-9]),00.htm http://$1/$2/print.htm?TYPE=story&AT=$4-$3t-40000019c
PRINT http://(www*.|)timesonline.co.uk/article/0,,(*),00.html http://www.timesonline.co.uk/printFriendly/0,,$2-2,00.html
PRINT http://((*.|)reuters.(com|co.uk))/**(newsArticle|newsPackageArticle).jhtml*(storyID=[0-9]*[0-9])* 302:http://$1/printerFriendlyPopup.jhtml?$5
PRINT http://((*.|)reuters.(com|co.uk))/**(newsArticle|newsPackageArticle).aspx*storyID=(*.xml) 302:http://$1/printerFriendlyPopup.aspx?storyID=uri:$5
PRINT http://(www*.|)technologyreview.com/articles/(*).asp** http://www.technologyreview.com/articles/print_version/$2.asp
PRINT (http://(www*.|)technologyreview.com/articles/*/**.asp?p=)2 ${1}0
PRINT http://(www*.|)techcentralstation.com/(*)/techwrapper.jsp?**&CID=(*) http://www.techcentralstation.com/$2/printer.jsp?CID=$3
PRINT http://(www*.|)pcworld.com/news/article/0,aid,([0-9]*[0-9]),00.asp http://www.pcworld.com/resource/printable/article/0,aid,$2,00.asp
PRINT http://(www*.|)kobtv.com/index.cfm?viewer=storyviewer&id=([0-9][^&]*)** http://www.kobtv.com/process/printstory.cfm?id=$2
PRINT (http://(www*.|)popularmechanics.com/**/20[0-9][0-9]/**/)index.phtml $1/print.phtml
PRINT http://abcnews.go.com/(**)/(story|wireStory)?(id=**) http://abcnews.go.com/$1/print?$3
PRINT http://www.technologyreview.com/read_article.aspx?(id=[1-9]**) http://www.technologyreview.com/printer_friendly_article.aspx?$1
PRINT (http://(www*.|)wkrn.com/*/story.asp?S=[0-9]*) $&&ClientType=Printable
PRINT http://cnews.canoe.ca/CNEWS/(*/20[0-9][0-9]/[01][0-9]/[0123][0-9])/([0-9]*[0-9])-ap.html http://cnews.canoe.ca/CNEWS/$1/pf-$2.html
PRINT http://((ww*.|)ctv.ca/servlet/ArticleNews)/story/(CTVNews/[0-9]**) http://$1/print/$3&subhub=PrintStory
PRINT (http://(www*.|)canoe.ca/**/News/20[0-9][0-9]/[01][0-9]/[0123][0-9])/([0-9]*.html) $1/pf-$3
PRINT (http://(www*.|)post-gazette.com/pg)/([0-9]**[0-9].stm) $1/pp/$3
PRINT http://((www*.|)spectrum.ieee.org.nyud.net:8090)/[a-z]*[0-9]/([0-9]*[0-9]) http://$1/print/$3
PRINT http://((www*.|)smartmoney.com)/(*/index.cfm?story=**) http://www.smartmoney.com/print/index.cfm?printcontent=/$3
PRINT http://distrocenter.linux.com/distrocenter/([0-9]**[0-9]).shtml** http://distrocenter.linux.com/print.pl?sid=$1
##PRINT http://((*.|)news.com.au)/common/story_page/0,[0-9][0-9][0-9][0-9],([0-9]*[0-9]),00.html http://$1/common/printpage/0,6093,$3,00.html
PRINT http://(www*.|)redherring.com/article.aspx?a=([0-9]*[0-9]) http://www.redherring.com/PrintArticle.aspx?a=$2
PRINT http://(www*.|)astrobio.net/news/modules.php?**&(sid=[0-9][0-9]*)** http://www.astrobio.net/news/print.php?$2
PRINT (http://(www*.|)tomahjournal.com/articles/**).txt $1.prt
PRINT http://(www*.|)azcentral.com/community/tempe/articles/*.html http://www.azcentral.com/php-bin/clicktrack/print.php?referer=$&
PRINT http://(www*.|)csoonline.com/read/**.html $&?action=print
PRINT http://((www*.|)wwwcoder.com)/main/parentid/*/site/([[0-9]*[0-9])/*/default.aspx http://$1/main/DesktopModules/ResDirMgr/ASPSearch_Options.aspx?action=print&article=$3
PRINT http://(www*.|)scoop.co.nz/stories/**.htm $&?mode=print
PRINT http://(www*.|)wkyt.com/Global/story.asp?[Ss]=([0-9]*[0-9]) $&&ClientType=Printable
PRINT http://www.dailystar.com.lb/article.asp?edition_id=*&categ_id=([0-9])&article_id=([0-9]*[0-9]) http://www.dailystar.com.lb/printable.asp?art_ID=$2&cat_ID=$1
PRINT http://(www*.|)japancorp.net/Article.Asp?Art_ID=(*) http://$1japancorp.net/printarticle.asp?Art_ID=$2
PRINT http://(www*.|)japantoday.com/e/?content=comment&id=(*) http://www.japantoday.com/e/tools/print.asp?content=comment&id=$2
PRINT (http://(www*.|)democratandchronicle.com/biznews)/([0-9]*.shtml) $1/forprint/$3
PRINT http://(www*.|)physorg.com/news([0-9]*).html http://www.physorg.com/printnews.php?newsid=$2
PRINT http://((www*.|)(tdn|missoulian).com/articles/**).txt http://$1.prt
PRINT http://(www*.|)iol.co.za/index.php?*&art_id=([a-z][a-z][0-9]*[0-9]) http://www.iol.co.za/general/news/newsprint.php?art_id=$2&sf=
PRINT http://(www*.|)onlamp.com/pub/wlg/([0-9]**) http://www.onlamp.com/lpt/wlg/$2
PRINT http://((www*.|)rednova.com)/news/display/?(id=116562) http://$1/modules/news/tools.php?tool=print&$3
PRINT http://((www*.|)rednova.com)/news/*/([0-9]*[0-9])/**.html http://$1/modules/news/tools.php?tool=print&id=$3
PRINT (http://(www*.|)csmonitor.com/20[0-9][0-9]/*/p*.htm)l $1
PRINT http://judiciary.senate.gov/testimony.cfm?(id=**) http://judiciary.senate.gov/print_testimony.cfm?$1
PRINT http://(www*.|)enr.com/features/*/archives/[0-9]*[0-9]-[0-9].asp http://www.enr.com/print.asp?REF=$&
##PRINT http://news.com.com**/2*-(*-*).html** http://news.com.com/2102-$1.html?tag=ni_print
PRINT http://((www*.|)capitolhillblue.com/artman/publish)/article_([0-9]*).shtml http://$1/printer_$3.shtml
PRINT http://(www*.|)lcsun-news.com/artman/publish/article_(*).shtml http://www.lcsun-news.com/artman/publish/printer_$2.shtml
PRINT (http://(www*.|)digitimes.com)/news/(a2*.html) $1/print/$3
PRINT http://((www*.|)news-medical.net)/?id=([0-9]*[0-9]) http://$1/print_article.asp?id=$3
PRINT http://(www*.|)sltrib.com/2[0-9][0-9][0-9]/*/**.asp $&?display=print
PRINT (http://(www*.|)avnonline.com/index.php?*)&Action=View_Article&Content_ID=([0-9]*[0-9]) $1&Action=Print_Article&Content_ID=$3
PRINT http://(www*.|)economist.com/(**)/displayStory.cfm?[Ss]tory_[Ii][Dd]=(*) http://www.economist.com/$2/PrinterFriendly.cfm?Story_ID=$3
PRINT http://www.pawtuckettimes.com/site/news.cfm?(newsid=**) http://www.pawtuckettimes.com/site/printerFriendly.cfm?$1
PRINT http://(www*.|)xml.com/pub/(a/20[0-9][0-9]/[0-9][0-9]/[0-9][0-9]/*.html) http://www.xml.com/lpt/$2
PRINT http://allafrica.com/stories/([0-9]*).html http://allafrica.com/stories/printable/$1.html
PRINT http://(www*.|)acmqueue.com/modules.php?name=Content&pa=showpage&pid=([0-9]*[0-9]) http://www.acmqueue.com/modules.php?name=Content&pa=printer_friendly&pid=$2&page=1
PRINT http://((www*.|)dailyreviewonline.com)/Stories/0,[0-9][0-9][0-9][0-9],([0-9]*[0-9]),00.html http://$1/cda/article/print/0,1674,$3,00.html
PRINT http://newsforge.com/newsforge/([0-9][0-9]/*/*/*).shtml** http://newsforge.com/print.pl?sid=$1
PRINT http://((*.|)newsforge.com)/*/([0-9]**).shtml** http://$1/print.pl?sid=$3
PRINT http://(www*.|)advancedippipeline.com/news/([0-9]*[0-9]);jsessionid=** http://www.advancedippipeline.com/shared/article/printablePipelineArticle.jhtml?articleId=$2
PRINT http://(www*.|)wfmynews2.com/2wk/2wk.asp?ID=(**) http://www.wfmynews2.com/2wk/print2wk.asp?ID=$2
PRINT http://(www*.|)bizreport.com/article.php?art_id=(*) http://www.bizreport.com/print.php?art_id=$2
PRINT http://(www*.|)bizreport.com/news/([0-9]*[0-9])/ http://$1bizreport.com/print/$2/
PRINT http://(www*.|)upi.com/view.cfm?StoryID=(*) http://www.upi.com/print.cfm?StoryID=$2
PRINT http://(*.indiatimes.com)/articleshow/([0-9]*[0-9]).cms http://$1/articleshow/msid-$2,prtpage-1.cms
PASS http://news.independent.co.uk/low_res/story.jsp?story=**
PRINT http://news.independent.co.uk/**/story.jsp?story=(*) 302:http://news.independent.co.uk/low_res/story.jsp?story=$1&host=3&dir=505
## OLD RULE
##PRINT http://news.independent.co.uk/**/story.jsp?story=(*) http://news.independent.co.uk/low_res/story.jsp?story=$1&host=3&dir=60
PRINT http://(www*.|)thisislondon.com/news/articles/([0-9]*[0-9])?** http://www.thisislondon.com/til/jsp/modules/Article/print.jsp?itemId=$2
PRINT http://(www*.|)scidev.net/news/index.cfm?fuseaction=readnews&(itemid=**) http://www.scidev.net/News/index.cfm?fuseaction=printarticle&$2
PRINT http://(www*.|)sciam.com/article.cfm?*&articleID=(*) http://www.sciam.com/print_version.cfm?articleID=$2
PRINT http://((www*.|)(news4jax.com|thechamplainchannel.com))/*/([0-9]*[0-9])/detail.html http://$1/print/$4/detail.html?use=print
PRINT http://news.ninemsn.com.au/article.aspx?id=* $&&print=true
PRINT http://(www*.|)wired.com/wired/archive/(**).html** http://www.wired.com/wired/archive/${2}_pr.html
PRINT http://(www*.|)dailymail.co.uk/pages/live/articles/**.html?(in_article_id=*&in_page_id=*) http://www.dailymail.co.uk/pages/text/print.html?$2
PRINT http://(www*.|)medicalnewstoday.com/index.php?newsid=(*) http://www.medicalnewstoday.com/printerfriendlynews.php?newsid=$2
PASS http://(www*.|)techworld.com/**&printerfriendly=1
PRINT http://((www*.|)techworld.com)/**/index.cfm?FeatureID=([1-9]*[0-9]) http://$1/features/index.cfm?featureID=$3&printerfriendly=1
PRINT http://((www*.|)anandtech.com)/*/showdoc.(html|aspx)?i=(*) http://$1/printarticle.$3?i=$4
## number change?
PRINT http://(www*.|)wired.com/news/*/0,*,(*),00.html** http://www.wired.com/news/print/0,1294,$2,00.html
## need to turn $yyyymmdd into date of article, not today:-(
##PRINT http://seattletimes.nwsource.com/html/*/([0-9]*)_(*[0-9]).html http://seattletimes.nwsource.com/cgi-bin/PrintStory.pl?document_id=$1&slug=$2&date=$yyyymmdd
PRINT http://seattlepi.nwsource.com/*/[0-9]*_*.html http://seattlepi.nwsource.com/printer2/index.asp?ploc=t&refer=$&
PRINT http://(www*.|)computerworld.com/**/story/0,*,([0-9]*[0-9]),00.html http://www.computerworld.com/printthis/2004/0,4814,$2,00.html
PRINT http://(www*.|)computerworld.com/action/article.do?command=viewArticle*&articleId=([[0-9]*[0-9])* http://www.computerworld.com/action/article.do?command=printArticleBasic&articleId=$2
PRINT http://(news.bbc.co.uk/[0-9]/**.stm) http://newsvote.bbc.co.uk/mpapps/pagetools/print/$1
PRINT http://(www*.|)wweek.com/story.php?story=(*) http://www.wweek.com/print.php?story=$2
PRINT http://(*.itworld.com/**)/page_1.html http://$1/pfindex.html
PRINT http://((*.|)enterprisestorageforum.com/**)/article.php/([0-9]*[0-9]) http://$1/print.php/$3
PRINT http://iccheshireonline.icnetwork.co.uk/**/tm_objectid=([0-9]{1,8})*&siteid=([0-9]{1,6})** http://iccheshireonline.icnetwork.co.uk/printable_version.cfm?objectid=$1&siteid=$2
PRINT http://(www*.|)washingtonpost.com/wp-dyn/articles/(A*-*).html http://www.washingtonpost.com/ac2/wp-dyn/$2?language=printer
PRINT http://(www*.|)washingtonpost.com/ac2/wp-dyn?*&contentId=(A*-*)&notFound=true http://www.washingtonpost.com/ac2/wp-dyn/$2?language=printer
PRINT http://weekly.ahram.org.eg/(20[0-9][0-9]/**.htm) http://weekly.ahram.org.eg/print/$1
PRINT http://(www*.)minebox.com/australian-mining-news.asp?NID=(*) http://www.minebox.com/print-article.asp?article=$2
PRINT (http://(www*.|)thenation.com/)doc.mhtml?(*) $1/docprint.mhtml?$3
PRINT http://(www*.|)streathamguardian.co.uk/news/*/display.var.([0-9]*[0-9]).0.*.php http://www.streathamguardian.co.uk/misc/print.php?artid=$2
PRINT http://(www*.|)cancerresearchuk.org/news/pressreleases/(*) http://www.cancerresearchuk.org/news/pressreleases/$2?view=Printable
PRINT http://my.webmd.com/(content/article/**.htm)** http://my.webmd.com/$1?printing=true
## disabled - the 302 trick doesn't cut it - annoying
##PRINT http://(www*.|)cbsnews.com/(stories/2**)/main([0-9]*).shtml 302:http://www.cbsnews.com/$2/printable$3.shtml
PRINT http://(www*.|)hardwareanalysis.com/content/article/(*)/ http://www.hardwareanalysis.com/action/printarticle/$2/
PRINT http://(www*.|)nydailynews.com/(**)/story/([0-9]*).html http://www.nydailynews.com/$2/v-pfriendly/story/$3.html
PRINT http://(www*.|)adn.com/front/(story/[0-9]*-*.html) http://www.adn.com/front/v-printer/$2
PRINT http://dsc.discovery.com/news/(**).html http://dsc.discovery.com/news/${1}_print.html
PRINT http://www.newscientist.com/article.ns?id=** $&&print=true
PRINT http://(www*.|)newscientist.com/news/news.jsp?id=(*) http://www.newscientist.com/news/print.jsp?id=$2
PRINT http://(www*.|)sundayherald.com/([0-9]*[0-9]) http://www.sundayherald.com/print$2
PRINT http://(www*.|)greenpeace.org/press/release?item_id=** $&&print=1
PRINT http://(www*.|)nytimes.com/(aponline|20[0-9][0-9]/[01][0-9]/[0-3][0-9])/**.html?** $&&pagewanted=print
PRINT http://writ.news.findlaw.com/(*/20[0-9]*.html) http://writ.news.findlaw.com/scripts/printer_friendly.pl?page=/$1
PRINT http://(www*.|)oreillynet.com/pub/(wlg/[0-9]*) http://www.oreillynet.com/lpt/$2
PRINT http://(www*.|)siliconvalley.com/mld/siliconvalley/news/[0-9]*[0-9].htm $&?template=contentModules/printstory.jsp
PRINT http://(www*.|)grandforks.com/mld/grandforks/([0-9]*[0-9]).htm $&?template=contentModules/printstory.jsp
PRINT http://(www*.|)centredaily.com/mld/centredaily/*.htm $&?template=contentModules/printstory.jsp
PRINT http://rss.com.com/[0-9][0-9][0-9][0-9]-(*.html)?*tag=feed* http://rss.com.com/2102-$1?tag=ni_print
PRINT http://(www*.|)securityfocus.com/(*/[0-9]*) http://www.securityfocus.com/printable/$2
PRINT http://(www*.|)perl.com/pub/a/(20*/*/*/*.html) http://www.perl.com/lpt/a/$2
PRINT http://(www*.|)newmediazero.com/news/story.asp?id=(*) http://www.newmediazero.com/output/print.asp?id=$2
PRINT http://(www*.|)tribnet.com/news/story/([0-9]*).html http://www.tribnet.com/news/v-printer/story/$2.html
PRINT http://straitstimes.asia1.com.sg/singapore/story/0,*,(*),00.html* http://straitstimes.asia1.com.sg/storyprintfriendly/0,1887,$1,00.html
PRINT http://(www*.|)nettavisen.no/servlets/page?*(item=[0-9]*) http://www.nettavisen.no/servlets/page?section=99&$2
PRINT http://(www*.|)cbronline.com/latestnews/* http://www.cbronline.com/print_friendly/$2
PRINT http://(www*.|)cbronline.com/article_news.asp?guid=(**) http://www.cbronline.com/article_news_print.asp?guid=($2)
PRINT http://(www*.|)thestar.com/NASApp/cs/ContentServer?pagename=thestar/Layout/Article_Type1(&c=Article&cid=**) http://www.thestar.com/NASApp/cs/ContentServer?pagename=thestar/Layout/Article_PrintFriendly$2
PRINT http://www.thestar.com.my/news/story.asp?(file=**) http://www.thestar.com.my/services/printerfriendly.asp?$1
PRINT http://(www*.|)local6.com/*/*/detail.html $&?use=print
PRINT http://(www*.|)washingtonpost.com/wp-dyn/articles/(*-*).html http://www.washingtonpost.com/ac2/wp-dyn/$2?language=printer
PRINT http://www.indystar.com/articles/0/([0-9]*[0-9]-[0-9]*)-*.html http://www.indystar.com/articles/0/$1-P.html
PRINT http://wnd.com/news/article.asp?ARTICLE_ID=(*) http://wnd.com/news/printer-friendly.asp?ARTICLE_ID=$1
PRINT http://(www*.|)timesleader.com/mld/timesleader**/([0-9]*).htm $&?template=contentModules/printstory.jsp
PRINT http://(www*.|)voanews.com/article.cfm?objectID=(*) http://www.voanews.com/PrintArticle.cfm?objectID=$2
PRINT http://(www*.|)voanews.com/*/20[0-9][0-9]-[0-9][0-9]-[0-9][0-9]-*.cfm $&?renderforprint=1
PRINT http://(www*.|)(dmeurope.com|europemedia.net)/*.asp?ArticleID=([0-9]*) $&&Print=true
PRINT http://fpeng.peopledaily.com.cn/(20[0-9][0-9][0-9][0-9]/*)/eng(*_*).shtml http://fpeng.peopledaily.com.cn/$1/print$2.html
PRINT http://(www*.|)newsfactor.com/perl/story/(*).html http://www.newsfactor.com/perl/printer/$2/
PRINT http://(www*.|)rockymountainnews.com/drmn/*/article/0,*,(*),00.html http://www.rockymountainnews.com/drmn/cda/article_print/1,1983,${2}_ARTICLE-DETAIL-PRINT,00.html
PRINT http://(www*.|)nzherald.co.nz/storydisplay.cfm?storyID=([0-9]*[0-9])&** http://www.nzherald.co.nz/storyprint.cfm?storyID=$2
PRINT http://(www*.|)nzherald.co.nz/index.cfm?*ObjectID=([0-9]*[0-9]) http://www.nzherald.co.nz/print.cfm?objectid=$2
PRINT http://(www*.|)enterpriseitplanet.com/networking/features/article.phpr/(*) http://www.enterpriseitplanet.com/networking/features/print.php/$2
PRINT http://(www*.|)planetark.(org|com)/dailynewsstory.cfm/newsid/([0-9]*[0-9])/story.htm http://www.planetark.com/avantgo/dailynewsstory.cfm?newsid=$3
PRINT http://(www*.|)popularmechanics.com/*/*/20[0-9][0-9]/*/*/ $&print.phtml
PRINT http://(www*.|)docguide.com/news/content.nsf/news/(*) http://www.docguide.com/news/content.nsf/NewsPrint/$2
PRINT http://(www*.|)newsmax.com/archives/articles/20[0-9][0-9]/**.shtml http://www.newsmax.com/cgi-bin/printer_friendly.pl?page=$&
##PRINT http://(www*.|)eweek.com/article2/(0,*.asp) http://www.eweek.com/print_article/$2
PRINT http://(www*.|)scienceblog.com/community/modules.php?name=News&file=article&sid=(*) http://www.scienceblog.com/community/modules.php?name=News&file=print&sid=$2
PRINT http://(www*.|)scienceblog.com/community/article([0-9]*[0-9]).html http://www.scienceblog.com/community/article-print-$2.html
PRINT http://(www*.|)scienceblog.com/cms/*_([1-9]*[0-9]) http://www.scienceblog.com/cms/node/$2/print
##PRINT http://(www*.|)sciencedaily.com/(releases/20[0-9][0-9]/*/[0-9]*[0-9].htm) http://www.sciencedaily.com/print.php?url=$2
PRINT http://(www*.|)aftenposten.no/*/local/article.jhtml?articleID=(*) http://www.aftenposten.no/template/droplets/utskriftsvennlig.jhtml?articleID=$2
PRINT http://(www*.|)aftenposten.no/**/article*.ece $&?service=print
PRINT http://(www*.|)dailytimes.com.pk/default.asp?(page=story_*) http://www.dailytimes.com.pk/print.asp?$2
PRINT http://(www*.|)vnunet.com/News/(*) http://www.vnunet.com/Print/$2
PRINT http://(www*.|)vnunet.com/news/(*) http://www.vnunet.com/print/it/$2
PRINT (http://*.boston.com/**/articles/[0-9][0-9][0-9][0-9]/[0-9][0-9]/[0-9][0-9]/*/)(?|)** $1?mode=PF
PRINT http://(www*.|)worldnetdaily.com/news/article.asp?ARTICLE_ID=(*) http://www.worldnetdaily.com/news/printer-friendly.asp?ARTICLE_ID=$2
PRINT http://(www*.|)eet.com/sys/news/(*) http://www.eet.com/printableArticle?doc_id=$2
PRINT http://(www*.|)informationweek.com/story/showArticle.jhtml**?articleID=(*) http://www.informationweek.com/shared/printableArticle.jhtml?articleID=$2
PRINT http://(www*.|)edinburghnews.com/index.cfm?id=(*) http://www.edinburghnews.com/print.cfm?id=$2
PRINT http://www.fredericksburg.com/News/FLS/20[0-9][0-9]/**[0-9] $&/printer_friendly
PRINT http://(www*.|)nj.com/newsflash/*/index.ssf?/cgi-free/getstory_ssf.cgi%3f* http://www.nj.com/enter/index.ssf?/printer/printer.ssf%3f/newsflash/get_story.ssf%3f/cgi-free/getstory_ssf.cgi%3f$2%3faponline
PRINT http://(www*.|)nj.com/newsflash/*/index.ssf?(/**-0/[0-9]*[0-9]).xml http://www.nj.com/printer/printer.ssf?$2.xml?aponline
## ABC BUSTED THIS ## PRINT http://(www*.|)abc.net.au/(*/news/stories/s*[0-9].htm) http://www.abc.net.au/cgi-bin/common/printfriendly.pl?/$2
## ABC BUSTED THIS ##PRINT (http://(www*.|)abc.net.au/news/newsitems/**.htm) http://www.abc.net.au/cgi-bin/common/printfriendly.pl?$1
## ABC BUSTED THIS ##PRINT http://(www*.|)abc.net.au/(ra/newstories/*.htm) http://www.abc.net.au/cgi-bin/common/printfriendly.pl?/$2
## ABC BUSTED THIS ##PRINT http://(www*.|)abc.net.au/am/content/20[0-9][0-9]/s[0-9]*[0-9].htm http://www.abc.net.au/cgi-bin/common/printfriendly.pl?$&
PRINT http://(www*.|)betterhumans.com/(News/news|Features/**).aspx?articleID=(*) http://www.betterhumans.com/Print/index.aspx?articleID=$3
PRINT http://(www*.|)gulfnews.com/Articles/*.asp?ArticleID=(*) http://www.gulfnews.com/Articles/print.asp?ArticleID=$2
PASS http://(*.|)news.yahoo.com/**&printer=1
PRINT http://(*.|)news.yahoo.com/news?tmpl=story**&u=** $&&printer=1
PRINT http://(*.|)news.yahoo.com/s/ap/20[0-9][0-9]** $&&printer=1
PRINT http://(www*.|)globeandmail.com/servlet/ArticleNews/TPStory/(**)/Idx http://www.theglobeandmail.com/servlet/ArticleNews/TPPrint/$2/
PRINT http://(www*.|)(the|)globeandmail.com/servlet/story/(*)/BNStory/(**) http://www.theglobeandmail.com/servlet/story/$3/BNPrint/$4
PRINT http://(www*.|)boston.com/dailyglobe2/203/(**)+.shtml http://www.boston.com/dailyglobe2/203/$2P.shtml
PRINT http://slate.msn.com/id/(*)/** http://slate.msn.com/toolbar.aspx?action=print&id=$1
PRINT http://eetimes.com/sys/news/(*) http://eetimes.com/printableArticle?doc_id=$1
PRINT http://(www*.|)eetimes.com/**/showArticle.jhtml?articleID=([0-9]*[0-9]) http://www.eetimes.com/article/printableArticle.jhtml?articleID=$2
##PRINT http://(www*.|)msnbc.com/news/(*).asp http://www.msnbc.com/m/pt/printthis.asp?storyID=$2
PRINT http://(www*.|)msnbc.msn.com/id/[0-9]*[0-9]/ $&print/1/displaymode/1098/
PRINT http://(www*.|)af.mil/stories/story.asp?storyID=(*) http://www.af.mil/stories/story_print.asp?storyID=$2
PRINT http://(www*.|)fortune.com/fortune/technology/articles/0,*,(*),00.html http://www.fortune.com/fortune/print/0,15935,$2,00.html
PRINT http://(www*.|)salon.com/tech/wire/(20**)/index.html http://www.salon.com/tech/wire/$2/print.html
PRINT http://(www*.|)newsday.com/(news/**)/(*),0,*.story?coll=* http://www.newsday.com/templates/misc/printstory.jsp?slug=$3&section=/$2
PRINT http://(www*.|)dfw.com/mld/*/news/*/[0-9]*.htm $&?template=contentModules/printstory.jsp
PRINT http://orlando.bizjournals.com/orlando/stories/20[0-9][0-9]/[0-9][0-9]/[0-9][0-9]/story*.html?t=printable $&?t=printable
## osnews uses the Referrer header
PRINT http://(www*.|)osnews.com/story.php?news_id=(*) 302:http://www.osnews.com/printer.php?news_id=$2
##PRINT http://(www*.|)forbes.com/(20[0-9][0-9]/[0-9][0-9]/[0-9][0-9]/*).html** http://www.forbes.com/$2_print.html
##PRINT http://(www*.|)forbes.com/(**/20[0-9][0-9]/[0-9][0-9]/[0-9][0-9]/*).html** http://www.forbes.com/$2_print.html
PRINT http://((www*.|)forbes.com)/**/(20[0-9][0-9]/[0-9][0-9]/[0-9][0-9]/*).html http://$1/$3_print.html
PRINT http://sci.newsfactor.com/perl/story/(*).html http://sci.newsfactor.com/perl/printer/$1/
PASS http://(www*.|)sfgate.com/cgi-bin/article.cgi?**&type=printable
PRINT http://((www*.|)sfgate.com/cgi-bin/article.cgi?**)&type=* http://$1
PRINT http://(www*.|)sfgate.com/cgi-bin/article.cgi?f=(**) http://sfgate.com/cgi-bin/article.cgi?file=$2&type=printable
PRINT http://(www*.|)sfgate.com/cgi-bin/article.cgi?(f|file)=(**.DTL) http://sfgate.com/cgi-bin/article.cgi?file=$3&type=printable
PRINT http://(www*.|)iht.com/articles/(*).html http://www.iht.com/cgi-bin/generic.cgi?template=articleprint.tmplh&ArticleId=$2
PRINT http://(www*.|)stuff.co.nz/stuff/0,*,(*),00.html http://www.stuff.co.nz/stuff/print/0,1478,$2,00.html
PRINT http://(www*.|)smalltimes.com/document_display.cfm?document_id=(*) http://www.smalltimes.com/print_doc.cfm?doc_id=$2
PRINT http://(www*.|)canada.com/*/story.asp?id=(*) http://www.canada.com/components/print.aspx?id=$2
PRINT http://(www*.|)nature.com/nsu/(*/*.html) http://www.nature.com/nsu/nsu_pf/$2
PRINT (http://(www*.|)nature.com/news/20[0-9][0-9]/*)/full/([0-9]*).html $1/pf/$3_pf.html
PRINT http://(www*.|)javaworld.com/javaworld/(*/*).html http://www.javaworld.com/javaworld/${2}_p.html
PRINT (http://(www*.|)linuxworld.com/story/[0-9]*[0-9]).htm $1_p.htm
PRINT http://(www*.|)businessweek.com/(*/content/*/*.htm) http://www.businessweek.com/print/$2
PRINT http://(www*.|)theage.com.au(/articles/20**.html)** http://www.theage.com.au/cgi-bin/common/popupPrintArticle.pl?path=$2
PRINT http://(www*.|)kansascity.com/(mld/kansascity/news/**.htm) http://www.kansascity.com/($2)?template=contentModules/printstory.jsp
PRINT http://(www*.|)miami.com/mld/miamiherald**/[0-9]*.htm $&?template=contentModules/printstory.jsp
PRINT http://breakingnews.iol.ie/news/story.asp?(j=**) http://breakingnews.iol.ie/email/printer.asp?$1
PRINT http://(www*.|)enn.com/news/enn-stories/*/*/*/s_([0-9]*[0-9]).asp http://www.enn.com/extras/printer-friendly.asp?storyid=$2
PRINT http://(www*.|)chron.com/cs/CDA/ssistory.mpl/(*/[0-9]*[0-9]) http://www.chron.com/cs/CDA/printstory.hts/$2
PRINT http://(www*.|)scotlandonsunday.com/index.cfm?id=(*) http://www.scotlandonsunday.com/print.cfm?id=$2
PASS http://news.scotsman.com/print.cfm?**
PRINT http://news.scotsman.com/*.cfm?id=(*) http://news.scotsman.com/print.cfm?id=$1
##PRINT http://home.kyodo.co.jp/all/display.jsp?an=* http://home.kyodo.co.jp/all/printer_friendly.jsp?an=$1
PRINT http://(www*.|)foxnews.com/story/0,*,(*),00.html http://www.foxnews.com/printer_friendly_story/0,3566,$2,00.html
PRINT http://(www*.|)taipeitimes.com/News/edit/archives/20[0-9][0-9]/[0-9][0-9]/[0-9][0-9]/* $&/print
PRINT http://(www*.|)techtv.com/news/*/story/0,*,(*),00.html http://www.techtv.com/news/print/0,23102,$2,00.html
PRINT http://(www*.|)theregister.(com|co.uk)/20[01][0-9]/[0-9][0-9]/[0-9][0-9]/*/ $&print.html
PRINT http://osdir.com/Article([0-9]*).phtml http://osdir.com/PrintArticle$1.phtml
PRINT http://(www*.|)linux.com/article.pl?(sid=**) http://www.linux.com/print.pl?sid=$2
PASS ftp://**
PASS http://*.ac.uk/**
PASS http://webmail.aol.com/**
PASS http://images.google.com/images?**
PASS http://ads.nana.co.il/**
PASS http://ads.sms.at/**
PASS http://ads.x10.com/misc/*.gif
PASS http://(www*.|)infopark.de/images/**.gif
PASS http://(www*.|)bund.de/**
PASS http://*.sears.com/**
PASS http://(*.|)aliantlink.com/**
PASS http://(*.|)sysco.com/**
PASS http://(*.|)esysco.net/**
PASS http://(*.|)lead-pursuit.com/**
PASS http://(*.|)cervelo.com/**
PASS http://(*.|)alternate.de/**
PASS http://*.ereader.com/**
PASS http://*.atlasf1.com/**
PASS http://*.mediasupply.com/**
AD http://(www*.|)solariscentral.org/images/ads/**
AD http://(www*.|)superguadagni.net/public/banner/**.gif
AD http://(www*.|)girlsnavi.net/bn/*.gif
AD http://tremulous.bricosoft.com/images/banniere/b.php
AD http://(www*.|)net-security.org/images/ads/**
AD http://(www*.|)udel.edu/PR/UDaily/includes/ads/**
PASS http://*.(edu|gov|org)(|.au)/**.(gif|jpg)
# two exceptions from Putinas Piliponis
PASS http://*.bov.com/**
PASS http://*.exler.ru/**
PASS http://(www*.|)cbc.ca/mycbc/images/banner/banner*.gif
PRINT http://(www*.|)cbc.ca/story/**.html $&?print
PRINT http://(www*.|)cbc.ca/stories/(**) http://www.cbc.ca/cgi-bin/templates/print.cgi?/$2
PASS http://(www*.|)universetoday.com/am/publish/printer_*.html
PRINT http://(www*.|)universetoday.com/am/publish/(*).html* http://www.universetoday.com/am/publish/printer_$2.html
ADPOPUP http://ads.x10.com/traffic/*.htm
ADPOPUP http://ads.x10.com/advertisement/*.htm
ADPOPUP http://ads.x10.com/weather/**.htm
ADPOPUP http://ads.x10.com/yahoo/*.html
ADJS http://ads.x10.com/720x300/*/1/DSC
AD http://ads.x10.com/?**
PASS http://ads.x10.com/**
ADJS http://ads.**.js
## AD http://ads.x10.com/?**
AD http://ads.x10.com/**.gif
AD http://images.x10.com/traffic/*.jpg
AD http://ad.**.gif
AD http://ad.*/bb.cgi?cmd=ad**
AD http://ads.**.(gif|jpg)**
AD http://ads[0-9]*.**.gif**
ADPOPUP http://businessfactory.delphi.com/redir/**
##AD http://promo.*/**/*468*.gif
PASS http://banners.wunderground.com/banner/**.gif
AD http://businessfactory.delphi.com/delphi/exciting2.gif?**
AD http://businessfactory.delphi.com/returnfeed.asp?**
AD http://(www*.|)internetnews.com/icom_includes/special/**.(gif|jpg)
AD http://ads*.realcities.com/ads*/**.gif
AD http://banner*/**.gif
AD http://*/[0-9]*_banner_*.gif
AD http://*/*_ban/*.gif
AD http://*/adsdisplay?**
AD http://(www*.|)computers.us.fujitsu.com/internal/comps/**.gif
AD http://tools.epersonals.com/farm/epersonals_160x600_*.jpg
AD http://banners.advancewebhosting.com/rt.phtml?**
AD http://banners.advancewebhosting.com/test_image.phtml?**
AD http://banners.nextcard.com/affiliates/AffiliateImages?**
AD http://banners.pennyweb.com/**.(gif|jpg)***
AD http://(www*.|)jandraffiliates.com/Images/**.gif
AD http://(www*.|)officemax.com/images/affArt/**.gif
AD http://(www*.|)banneranswers.com/bin/bimg.cgi?**
AD http://bannerpower.com/cgi-bin/bannerpic.cgi?**
AD http://media.interadnet.com/**.gif
AD http://tr.adinterax.com/**.(gif|jpg)**
PASS http://(www*.|)commbank.com.au/**.gif
PASS http://(www*.|)bluemountain.com/homegifs/*_ad.gif
PASS http://images.delphi.com/dir-html/partner/delphi/home_images/*_ad.gif
PASS http://(www*.|)techiwarehouse.com/images/*_ad.gif
PASS http://*.hp.com/ghp/banners/*.gif
PASS http://*.hp.com/RealMedia/ads/Creatives/HP_emarketing/**
PASS http://img*.outblaze.com/graffiti.net/ads/login_ad.gif
PASS http://*.epicurious.com/**
PASS http://www.splenda.com/**
PASS http://(www*.|)zoomerang.com/images/recipient/**
AD http://**_ad.(gif|jpg)
AD http://**/affiliate-*.gif
AD http://ad.openfind.com.tw/cgi-bin/AD/advimage.exe?**
AD http://**/recip*/*.(gif|jpg)
AD http://ad.adware.hu/adware.big?**
AD http://ad.adware.hu/richfile.big?**
AD http://feedads*.googleadservices.com/**/i?*
AD http://pagead*.googlesyndication.com/pagead/imgad?**
ADJSTEXT http://pagead*.googlesyndication.com/pagead/*.js
ADHTMLTEXT http://pagead*.googlesyndication.com/pagead/ads?**
ADHTMLTEXT http://groups.google.com/groups/adfetch?**
ADHTMLTEXT http://*.mootermedia.com/ads/moot?page_view_id=**
WEBBUG http://mfhclive.112.2O7.net/b/**
WEBBUG http://www.google.com/ig/images/tick.gif?**
WEBBUG http://www.google-analytics.com/__utm.gif?**
WEBBUG http://pagead*.googlesyndication.com/pagead/imp.gif**
WEBBUG http://ad.adware.hu/files/default
WEBBUG http://audit.median.hu/cgi-bin/track.cgi?**
WEBBUG http://pestiest.hu/cgi-bin/matesz/CP/est?MIME=image/gif**
WEBBUG http://m1.nedstatbasic.net/n?id=**
WEBBUG http://cme*.americangreetings.com/images/blankpixel.gif**
WEBBUG http://*.sky.com/x/x.gif
WEBBUG http://didtheyreadit.com/index.php/worker?code=**
WEBBUG http://*/RealMedia/ads/adstream_lx.cgi/intm/it/*.*.*/**?_RM_EMPTY_
ADJS http://*/RealMedia/ads/adstream_mjx.cgi/**
WEBBUGHTML http://a.boom.ro/ads.php?**
WEBBUGHTML http://a.boom.ro/track.php?**
COUNTER http://log.trafic.ro/cgi-bin/pl.dll?**
COUNTER http://m1.webstats4u.com/n?**
COUNTERJS http://m1.webstats4u.com/m.js
COUNTERJS http://storage.trafic.ro/js/trafic.js
ADJS http://a.boom.ro/boom.php?**
ADJS http://ads.clicksor.com/show[Aa]d.php?**
AD http://(ads*.|)clicksor.com/showbanner.php**
AD http://(ads*.|)clicksor.com/bannerad.php**
AD http://(ads*.|)clicksor.com/serving/show[aA]d.php**
AD http://(ads*.|)clicksor.com/serving/showbanner.php**
AD http://(ads*.|)clicksor.com/serving/contextual[aA]d.php**
AD http://creative.clicksor.com/network_[1-9]/**.(gif|jpg)
AD http://www.linkpositions.com/**
AD http://(www*.|)redzee.com/adsredirect.htm**
ADSWF http://(ads*.|)clicksor.com/serving/flash/**
ADSWF http://[a-z][a-z].voice2page.com/**.swf**
ADSWF http://*.smartadserver.com/**.swf**
ADSWF http:/*.ads.hexus.net/**.swf**
AD http://adverts.lrfairplay.com/adredir.imgw?**
AD http://adverts.lrfairplay.com/getadvert.imgw?**
AD http://**/RealMedia/ads/adstream_nx.(ads|cgi)/**
AD http://**/RealMedia/ads/adstream_lx.(ads|cgi)/**
AD http://**/RealMedia/ads/**.gif**
AD http://static.sky.com/images/pictures/[0-9]*[0-9].gif
AD http://escati.linkopp.net/cgi-bin/date.cgi?**
AD http://escati.linkopp.net/cgi-bin/countdown.cgi?**
AD http://escati.linkopp.net/cgi-bin/clock.cgi?**
AD http://(www*.|)journalregister.com/circads/*.jpg
AD http://(www*.|)sfbg.com/images/tiles/*_*.gif
AD http://*.instacontent.net/adserver/**
AD http://(www*.|)fhm.ro/nou/*.(gif|jpg)
AD http://ad2.ip.ro/please/showit/11/1/1/1/?typkodu=img&**
AD http://ads*.quarterserver.de/**.gif
AD http://ad*.haynet.com:8080*/[1-9]*x[1-9]*/**.gif
AD http://image.adition.net/**.gif
AD http://ads*.revenue.net/load/**.(gif|jpg)
AD http://(www*.|)engadget.com/common/media/bnr_*.gif
AD http://ad.spieletipps.de/cgi-bin/avp/bimg.pl?**
AD http://ad.spieletipps.de/avp/banners/**.gif
ADHTML http://ad.spieletipps.de/cgi-bin/avp/banners.pl?**
ADHTML http://www.nature.com/includes/**/ad.html
ADHTML http://(www*.|)jittery.com/bp/?user=**
ADHTML http://(www*|.)jittery.com/ads/*.cfm?**
ADHTML http://ads*.revenue.net/**/page.html**
ADHTML http://ads.resellerratings.com/**.html
ADHTML http://ads.betanews.com/adserve.iframe/**
ADHTML http://ads*.quarterserver.de/adserver/servlet/view/html/zone?**
ADPOPUP http://ads*.quarterserver.de/adserver/servlet/view/window/internal;**
ADPOPUP http://ads*.revenue.net/**pop.html**
ADPOPUP http://*.smartadserver.com/*/show*.asp?**
ADJS http://a.kerg.net/delivery/fa.php?**
ADJS http://*.liberation.fr/inc/smartad.js
ADSWF http://ads*/www/delivery/ajs.php?**
ADJS http://*.smarttargetting.com/**smartad.jsp?**
ADSWF http://*.smartadserver.com/**.swf**
ADSWF http://ads*/www/delivery/ai.php?**
ADSWF http://ads*.quarterserver.de/kelkoo/*.swf**
ADSWF http://aa.voice2page.com/**.swf**
ADSWF http://(www*.|)scoop.co.nz/adserver/creative/**.swf**
ADSWF http://(www*.|)fhm.ro/nou/**.swf
ADSWF http://(www*.|)komplett.no/mlf/produkt/bilder/**.swf**
ADSWF http://(www*.|)engadget.com/common/media/*.swf
ADSWF http://ad2.ip.ro/logos/*.swf?**
ADSWF http://194.145.249.110/images/logoAnim*.swf
ADSWF http://img-catgeo.paginegialle.it/clienti/**/A/*.swf**
ADSWF http://*.tiser.com.au/images/**.swf**
ADSWF http://*.specificclick.net/**swf
ADSWF http://ds.serving-sys.com/**.swf
ADJS http://*.tiser.com.au/jserver/**
ADJS http://ds1.harmony-central.com/jserver/**
ADJS http://ad-uk.tiscali.com/jserver/**
ADJS http://afe.specificclick.net/AFECache
ADJS http://afe.specificclick.net/?**&t=j**
ADJS http://ads*.msn.com/**.js                                                  
AD http://ads*.msads.net/**.jpg
AD http://*.tiscali.co.uk/**/images/*-logo-*.(gif|jpg)
AD http://*.tiser.com.au/nserver/**
AD http://*.tiser.com.au/images/**
AD http://*/[Aa]d[Ss]erver/creative/**
AD http://*.specificmedia.com/**.jpg
ADHTML http://ad2.ip.ro/please/code?**
ADHTML http://ads.specificpop.com/code?**
ADHTML http://ads.specificclick.com/code?**
ADHTML http://afe.specificclick.net/?**&t=h**
ADHTML http://www.imdb.com/google/box?**
ADHTML http://**/RealMedia/ads/adstream_sx.ads/**
ADHTML http://ad.aboutwebservices.com/cgi-bin/ad/**
ADHTML http://adserver.**/ads/adstream_nx.cgi/**.html*
ADHTML http://adserve.viaarena.com/admin/frmServeBanner.aspx?**&IFrame=1**
ADHTML http://ads.***/ads/adstream_sx.ads/**
ADHTML http://nztv.untd.com/webads/**.htm**
ADHTML http://www.penny-arcade.com/ads/advert/index.php
ADHTML http://exchange.adbanners.com/serve-banner.php?**
ADHTML http://www*.bannerspace.com/asp/getad_fc.asp?**
ADHTML http://(www*.|)rednova.com/_include/banners/**.html
ADHTML http://ad[0-9]*.neodatagroup.com/ad/seatb.jsp?**
ADJS http://ad1.neodatagroup.com/uploads/js/*.js
AD http://*.adserver.com/w/cp.x;**;tid=[78];**
AD http://cdn.specificmedia.com/contents/**.jpg
AD http://adserver*-images.backbeatmedia.com/**.gif
ADJS http://nztv.untd.com/webads/js/adtags.js
# oh the irony!
PASS http://(www*.|)nytimes.com/2004/01/19/technology/19popup.html**
ADPOPUP http://*.adserver.com/w/cp.x;**
ADPOPUP http://*.adserver.yahoo.com/a?**
ADPOPUP http://*.infinityads.com/loading.php?**
ADPOPUP http://bannerads.zwire.com/bannerads/AdWindow.asp?**
ADPOPUP http://simplemp3s.com/exit.htm
ADPOPUP http://(www*.|)adexit.de/page.phtml?**
ADPOPUP http://sweepstakes.yahoo.com/popups/*.html
ADPOPUP http://squaregallery.com/cgi-bin/ad/popup?**
ADPOPUP http://adserv.internetfuel.com/cgi-bin/newredirect.cgi?**
ADPOPUP http://adserv.internetfuel.com/cgi-bin/omnidirect.cgi?**
ADPOPUP http://nitrous.exitfuel.com/?**
ADPOPUP http://(www*.|)nightscapecreations.com/newsite/contest_pop.cfm
ADPOPUP http://adv.surinter.net/popuprich.cfm?**
ADPOPUP http://adserver.tribuneinteractive.com/event.ng/**
ADPOPUP http://*.targetnet.com/ad/id=*&opt=hkj**
ADPOPUP http://*.casalemedia.com/V2/**.html**
ADPOPUP http://*.casalemedia.com/c?**
ADPOPUP http://64.156.188.97/**.htm
AD http://64.156.188.97/fclick/*.gif
AD http://65.119.30.151/UploadFilesFor*/*125x125ad.gif
AD http://*.casalemedia.com/V2/**.(gif|jpg)
AD http://(www*.|)nightscapecreations.com/newsite/imgs/contest*.jpg
AD http://*.clicrevenus.com/cgi-bin/affc0?*.gif**
AD http://s*.xperformance.net/sys/ads?**
AD http://adsfac.net/ffp.asp?**;js=no**
ADHTML http://as.casalemedia.com/s?**
ADHTML http://*/ads/[0-9]*.htm
ADHTML http://sfads.osdn.com/*.html
ADHTML http://ads.osdn.com/?ad_id=**
ADHTML http://focusin.ads.targetnet.com/ad/id=*opt=hhj*
ADTHTML http://adsfac.net/ffp.asp?loc=*&js=no
ADJS http://adsfac.net/(ad|ffp).asp?loc=**
ADSWF http://adsfac.net/ag.asp?**
AD http://adsfac.net/getCreative.asp?**
AD http://focusin.ads.targetnet.com/ad/id=*opt=hij*
AD http://fmads.osdn.com/banner/**
AD http://ads.osdn.com/?ad_id=**
AD http://ads.addynamix.com/**
AD http://(www*.|)zanox-affiliate.de/bin/z_ct_ppc.dll?*
AD http://ar.atwola.com/image/**
AD http://ar.atwola.com/content/**
ADJS http://ar.atwola.com/html/**;ctype=application/x-javascript**
ADJS http://ar.atwola.com/file/adsWrapper.js
ADJS http://ar.atwola.com/file/adsEnd.js
ADJS http://mads.com.com/**?**&celt=js**
ADJS http://**/ads/adstream_(m|)jx.ads/**
ADJS http://*.flycast.com/FlycastUniversal/
ADJS http://*.flycast.com/**/js/**
ADJS http://*.adbureau.net/jserver/**
ADJS http://ad.adverticum.net/js.prm?**
ADJS http://amch.questionmarket.com/adsc/**/randm.js
ADJS http://amch.questionmarket.com/adsc/**/decide.php?**
ADJS http://ads.gamespy.com/jserver/**?unique
ADJS http://*.adbrite.com/mb/text_group.php?**
ADSWF http://adcontent.gamespy.com/**.swf**
ADSWF http://(www*.|)minebox.com/images/*.swf
ADSWF http://(www*.|)independent.co.uk/img/commercial/skyscrapers/*.swf
ADSWF http://creative.apn.co.nz/*.swf?**
ADHTML http://ad.yieldmanager.com/iframe**
ADHTML http://ad.yieldmanager.com/st?ad_type=iframe&**
ADHTML http://ad.yieldmanager.com/imp?**
ADJS http://ad.yieldmanager.com/rmtag2.js
AD http://content.yieldmanager.com/**.gif
AD http://(www*.|)independent.co.uk/images/*CARDSKYSCRAPER*.(gif|jpg)
AD http://adcontent.gamespy.com/**.(gif|jpg)
AD http://sher.index.hu/ad?**
AD http://creative.apn.co.nz/**.gif**
AD http://index.hu/res/hirdetes/img/**
AD http://(www*.|)ebcvg.com/img/**x600*.gif
AD http://(www*.|)smallcapcenter.com/baimg/img/**.gif
ADHTML http://ad.adverticum.net/html.prm?**
ADHTML http://ad2.netforum.hu/view.php?**
ADHTML http://ad.adware.hu/html.big?**
ADHTML http://ad.adware.hu/richadware.big?**
ADHTML http://view.atdmt.com**/iview/**
WEBBUG http://view.atdmt.com**/view/**
AD http://view.atdmt.com/avenuea/view/**
AD http://sp*.atdmt.com/b/**.(gif|jpg)
AD http://sp*.atdmt.com/ds/**.(gif|jpg)
AD http://*/img.atdmt.com/**.(gif|GIF|jpg|JPG)**
ADJS http:/view.atdmt.com/*/jview/**
PASS http://(www&.|)bankrate.com/**
PASS http://(www*.|)comcast.net/**nav.swf**
PASS http://adsrv.bankrate.com/cgi-bin/accipiter/adserver.exe/site=brm/parent=brm/**
PASS http://www.americanexpress.com/*/images/banners/**.swf
PASS http://(www*.|)uniden.com.au/AUSTRALIA/resources_oz/images/flash/banner_*.swf
PASS http://images.motogp.com/flash/banner/**.swf**
PASS http://www.optimumnutrition.com/swf/**.swf
ADSWF http://**banner**.swf**
ADSWF http://cdn.atdmt.com/**/banners/**.swf**
ADSWF http://spd.atdmt.com/ds/**.swf?**
ADSWF http://(www*.|)ananova.com/assets/*banner.swf
ADSWF http://**/(ad|ads|banner*)/**.swf**
ADSWF http://*.infosync.*/adsync/**.swf**
ADSWF http://(www*.|)blargoc.co.uk/tekheads*.swf
ADSWF http://**/BD_flashlogo.swf
ADSWF http://fstrk.net/ag.asp?**
ADSWF http://**468x60*.swf**
ADSWF http://(www*.|)ad-blazer.com/**.swf
ADSWF http://(www*.|)bejba.com/banner/*/[Bb]anner*.swf
ADPOPUP http://(www*.|)bejba.com/banner/*/[Bb]anner*.html
ADPOPUP http://context*.kanoodle.com/cgi-bin/context.cgi?**&cgroup=finpop**
ADPOPUP http://*.coolsavings.com/scripts/PopUpWindow.asp?**
ADPOPUP http://205.180.85.40/novus/*.html
ADPOPUP http://media*.fastclick.net/novus/*.html
ADPOPUP http://media*.fastclick.net/w/pop.cgi?**
ADPOPUP http://media*.fastclick.net/w/pc.cgi?**
REWRITE http://media*.fastclick.net/w/get.media?*url=(http**) $1
ADHTML http://mbe.ru/adrevolver/banner?**
ADHTML http://media.adrevolver.com/adrevolver/banner?**
ADHTML http://media*.fastclick.net/w/get.media?t=[sn]**
ADSWF http://*.fastclick.net/fastclick.net/**.swf**
AD http://media*.fastclick.net/w/get.media?(**&|)sid=**
AD http://media*.fastclick.net/cid*/media*.gif
AD http://images.fastclick.net/ref*.gif
AD http://*.fastclick.net/fastclick.net/**.gif
AD http://cserver.mii.instacontent.net/fastclick/**.gif
AD http://*.infosync.*/adsync/**.(gif|jpg)
AD http://(www*.|)macinstein.com/adSQL/banners/*.JPG
AD http://**/adserver/image?ID=**
AD http://**/accipiter/adserver.exe**
AD http://accipiter.speedera.net/*-images.adbureau.net/**
AD http://**/accipiter/nserver/**
AD http://**-images.adbureau.net/**.gif
AD http://inl.adbureau.net/adserver/**/AAMSZ=**
AD http://*.flycast.com/**
AD http://*.linkexchange.ru/cgi-bin/**
AD http://(*.|)(advernet.ru|m2k.ru:8080)/(img|images)/([0-9]*).(gif|jpg|jpeg)
AD http://ad*.aaddzz.com/image/**
AD http://az.yandex.ru/bshow?banner=**
AD http://pics.rbc.ru/rbcmill/img/**.gif
AD http://content.ad-flow.com/**.gif
AD http://(www*.|)cbx*.com/images/button*.gif
AD http://(www*.|)cbx2.net/images/banbtn.gif
AD http://(www*.|)cbx*.com/*-*x*.gif
AD http://(www*.|)cbx*.com/cgi-bin/showbanner.cgi?**
AD http://(www*.|)looksmart.com/plainads/**
AD http://advertising.quote.com/**
AD http://(www*.|)advertisingbay.com/banner/**.GIF
AD http://gfx.tv2.dk/images/**banner*.gif
AD http://tourgfx.tv2.dk/spons/*.gif
AD http://(www*.|)makestuff.com/images/*_banner.gif
AD http://imp.partner2profit.com/bt/p2p.gif?**
AD http://images.about.com/partners/vpn/partnerbox/**.gif
AD http://images.about.com/specials/aboutads/**.gif
AD http://**/partners/*banner.gif
AD http://**/partners/**/468*.gif
AD http://**/partnertiles/*.gif
AD http://partner.xerox.com/asknancy/images/*banner.gif
AD http://images.villagevoice.com/tiles/*.gif
AD http://**/ad_graphics/**
AD http://(www*.|)quotestream.com/images/webbanners/**
AD http://rewards.macandbumble.com/rectangle_banners/*.(jpg|gif)
AD http://(www*.|)skins.be/banners/**
AD http://(www*.|)skins.be/*_60x468_*.gif
AD http://(www*.|)skins.be/ss/*.gif
AD http://citi.bridgetrack.com/ads/image/_raw.htm?**
AD http://adpush.dreamscape.com/adpush/bin2/adserve.cgi?**
AD http://*/DA/**.(gif|jpg)
AD http://spinbox*.filez.com/?*
AD http://*.spinbox.net/?SIT=**
AD http://*.spinbox.net/?AI=**
AD http://spinbox.*/DA/**
AD http://*.dvlabs.com/klipmart/**.(gif|jpg)
WEBBUG http://*.kliptracker.com/klipinsert*.gif**
ADHTML http://klipads.dvlabs.com/klipmart/**.htm
ADSWF http://*.dvlabs.com/klipmart/**.swf**
ADSWF http://images.tvnz.co.nz/spinbox/**.swf
ADJS http://*.spinbox.net/?DC=**&JS=Y**
ADJS http://klipads.dvlabs.com/klipmart/**.js
ADHTML http://*.spinbox.net/?DC=**
ADHTML http://servedby.advertising.com/site=**
ADHTML http://ad.sensismediasmart.com.au/images/sensis/*/*.html?**                                                                          
ADJS http://ad.sensismediasmart.com.au/images/sensis/*/Utilities.js                                                                         
ADJS http://*servedby.advertising.com/pops=**
AD http://*servedby.advertising.com/**
AD http://babs*.dk/pro-banner.php*?**
AD http://babs.dk/uimg/**.gif
AD http://ad.borsen.dk/uimg/**
AD http://ad.admediaserver.com/host/jserv_imp.php/**
AD http://ad.admediaserver.com/host/reg_imp.php/**
AD http://(www*.|)alphatradefn.com/l.php?**
AD http://(www*.|)aip.org/aserver/**.gif
AD http://*.adoptimizer.eu/adi.php**
ADHTML http://*.adoptimizer.eu/adi-i.php**
##ADPOPUP http://*.doubleclick.net/adi/**;sz=**
ADHTML http://*.doubleclick.net/adi/**
ADHTML http://babs*.dk/pro-html.php*?**
ADHTML http://ad.borsen.dk/html.php*?**
ADHTML http://ad.borsen.dk/html?**
ADHTML http://(www*.|)wkrn.com/global/ad.asp?type=core&**
ADHTML http://(www*.|)securityfocus.com/frames/ad.html?**
ADHTML http://bannervip.webjump.com/webjump/valet/b1.asp?**
ADHTML http://(www*.|)nettaxi.com/cit_frames/ae-frame.html
ADHTML http://fs.dai.net/htm/nettaxi/leader.html
ADHTML http://204.246.215.162/~banners/frame.html
ADPOPUP http://**popover.cfm?**
ADPOPUP http://**popunder;**
ADPOPUP http://**popunder.(asp|htm)**
ADPOPUP http://**-popback-*.htm*
REWRITE http://ad.doubleclick.net/clk;*?(http**) $1
REWRITE http://fls.doubleclick.net/act;*rdr=?(http**) $1
PASS http://ad.doubleclick.net/crossdomain.xml
PASS http://*.doubleclick.net/clk;**
PASS http://fastbuy.doubleclick.net/WebSteps?**
ADJS http://*.doubleclick.net/adj/**
PASS http://(www*.|)doubleclick.net/**
PASS http://ad.doubleclick.net/cgi-bin/**
PASS http://**/DartShellPlayer*_*_*.swf
ADHTML http://ad.doubleclick.net/adl/**
AD http://*.doubleclick.net/**
AD http://**.2mdn.net/**.(gif|jpg|png)
ADJS http://*.valueclick.com/cycle?**&t=js**
ADJS http://*.valueclick.com/jsmaster
ADPOPUP http://images.ad-flow.com/**/bnr_*x*/bnr.html
AD http://ads*.ad-flow.com/?DC=**
AD http://ads*.ad-flow.com/?SIT=**
AD http://(www*.|)bepaid.com/images/*.gif
AD http://stats.adage.com/sponsors/*/banners/**
AD http://*.pheedo.com/img.phdo?**
AD http://*.pheedo.com/bgimg.php?**
AD http://*.valueclick.com/**cycle?**
AD http://*.valueclick.com/ad.s/*.gif
AD http://image.click2net.com/?**
AD http://pub.nomade.fr/media/*.gif
AD http://*.pointroll.com/**Media/**.(gif|jpg)
AD http://*.pointroll.com/DefaultAd/?**
AD http://(www*.|)click-fr.com/print.cgi?a=**
AD http://(www*.|)click-fr.com/printj.cgi?a=**
ADHTML http://(www*|).click-fr.com/printk.cgi?a=**
ADHTML http://(www.|)pheedo.com/ad.php?**
##AD http://(www*.|)theregister.co.uk/media/*.gif
AD http://(www*.|)theregister.co.uk/media/1098.gif
ADHTML http://a.tribalfusion.com/f.ad?**
ADPOPUP http://a.tribalfusion.com/p.media/**.html
ADJS http://a.tribalfusion.com/j.ad?**
AD http://*tribalfusion.*/media/**.(gif|jpg)
AD http://a.tribalfusion.com/i.ad?**
ADSWF http://*tribalfusion.*/**.swf?**
ADSWF http://(www.|)pheedo.com/images/**.swf**
ADSWF http://*.pointroll.com/**/Media/**.swf**
ADSWF http://(www*.|)europemedia.net/art/*_(button|banner).swf
ADSWF http://(www*.|)der-schacht.com/**/banner*.swf
ADSWF http://(www*.|)2cpu.com/Images/zzqbanner*.swf
ADSWF http://java.yahoo.com/a/1-/flash/datek/datekgan46860.swf
ADSWF http://**java*.yahoo.com/**.swf**
ADSWF http://(www*.|)theregister.co.uk/media/*.swf
ADSWF http://movies.go.com/img/movie_search.swf
ADSWF http://(www*.|)beijing-olympic.org.cn/eolympic/image/title_*.swf
ADSWF http://*.2mdn.net/**.swf
ADSWF http://(www*.|)nrl.com.au/s200[0-9]/images/flash/intro.swf
AD    http://(www*.|)nrl.com.au/s200[0-9]/images/frontpage/*banner*.gif
AD    http://(www*.|)nrl.com.au/s200[0-9]/images/stateoforigin/*banner*.gif
AD    http://(www*.|)nrl.com.au/s200[0-9]/images/frontpage/telstra_button_bigevent.gif
AD    http://(www*.|)nrl.com.au/s200[0-9]/images/frontpage/buttons/*.gif
AD    http://(www*.|)wallpaper-desktop.net/gifs/buttons/*.gif
PASS http://(www*.|)cjr.org/images/**
PASS http://212.113.5.84/media/53.gif
PASS http://(www*.|)conrad.fr/images/banner/banner_*.gif
PASS http://(www*.|)monitorbusiness.com.au/media/banner[0-9].gif
PASS http://**/toolbar/**
PASS http://(www*.|)cisco.com/images**banner**
PASS http://(www*.|)hp.cz/**/banner*.gif
PASS http://europa.eu.int/**
PASS http://*.westpac.com.au/images/banner_*.gif
PASS http://*.uni-essen.de/Library/images/**
PASS http://*.panasonic.de/common/images/banner/**gif
AD http://**/banner[_0-9]*.gif
AD http://**/banr/*.gif
AD http://**/hostban*.gif
AD http://212.113.5.84/media/*.gif
AD http://199.172.144.25/**.gif
AD http://**/*banner/*banner*.gif
AD http://**/linkpic*.gif
AD http://banner.topping.com.ua/cgi-bin/pbn_click.cgi?**
AD http://4click.com.ua/cgi-bin/pc100.cgi?**
AD http://b.abn.com.ua/abnl.php?**
PASS http://(www*.|)oilnet.ru/**
ADHTML http://ad.adriver.ru/cgi-bin/erle.cgi?**bt=1?**
ADHTML http://ad[0-9].lbn.ru/bb.cgi?cmd=ad&**
ADJS http://ad.adriver.ru/cgi-bin/erle.cgi?**bt=16?**
ADJS http://tx3.design.ru/cgi-bin/banner/**
ADJS http://bs.yandex.ru/show/**
AD http://ad[0-9].lbn.ru/bb.cgi?cmd=ad&pubid=**
AD http://(www*.|)bizlink.ru/cgi-bin/irads.cgi?**
AD http://1000stars.ru/cgi-bin/d1000.pl?**
AD http://1000stars.ru/cgi-bin/1000s.cgi?**
AD http://(www*.|)ranker.ru/scripts/sqltmex.dll?**
AD http://reklama.netskate.ru/banner.pl?action=Show**
AD http://*.reklama.ru/cgi-bin/banner/**
AD http://*rb[0-9].design.ru/cgi-bin/banner/**
AD http://(www*.|)banners.ru/cgi-bin/banner/**
AD http://sj[0-9].lenta.ru/cgi-bin/banner/**
AD http://banner.netskate.ru:82/*.gif
AD http://rotabanner.**/cgi-bin/**
AD http://*.totemcash.com/free/rotative_banner.php?**&size=**
AD http://ad[0-9].bb.ru/bb.cgi?cmd=ad**
AD http://gazetaru[0-9].express.ru**/?action=show&magic=**
AD http://**:8080/?action=show&magic=**
ADSWF http://**netoscope.ru/i/**.swf
ADHTML http://ad[0-9].bannerbank.ru/bb.cgi?cmd=ad&**
AD http://ad[0-9].bannerbank.ru/bb.cgi?cmd=ad**
AD http://engine.awaps.net/**.gif?**
AD http://468.smi.ru/cgi-bin/banner/**
AD http://195.54.209.142/cgi-bin/img?user=**
AD http://*.rambler.ru*/ban.ban?**
AD http://*.rambler.ru/top100/*.gif
AD http://bannervip.web1000.com/images/**.gif
AD http://212.24.32.74/cgi-bin/banner/**
AD http://ad.kimo.com.tw/**.gif
AD http://ad.linksynergy.com/fs-bin/show?**
AD http://banner.linksynergy.com/fs/banners/*.gif
AD http://**/bannerprogram/**.gif
AD http://(www*.|)nh.com/cgi/adgenie/loadimage.cgi?**
AD http://(www*.|)nh.com/adgenie/images/*.gif
AD http://(www*.|)hubbe.net/gfx/*banner*.gif
AD http://(www*.|)stomped.com/counter-bin/images/*_banner.gif
ADSWF http://(www*.|)ad.tomshardware.com/**.swf
ADSWF http://g.fool.com/**.swf
AD http://216.92.21.16/images/banner/**.swf
AD http://(www*.|)buffalo.com/images/banner*/**.gif
AD http://(www*.|)ad.tomshardware.com/cgi-bin/bd.m?**
AD http://(www*.|)ad.tomshardware.com/images/banner/**
AD http://(www*.|)ad.tomshardware.com/cgi-bin/bannerdisplay.m?**
AD http://(www*.|)tomshardware.com/images/new/pair.gif
AD http://(www*.|)tomshardware.com/images/new/100hot_logo.gif
AD http://(www*.|)bluesnews.com/images/*-ad.gif
AD http://(www*.|)bluesnews.com/images/sub_skyscr*.gif
AD http://(www*.|)sysopt.com/i/resellerratings2.jpg
AD http://(www*.|)sysopt.com/i/dicejobs.gif
AD http://(www*.|)sysopt.com/i/ss2000trial4.gif
AD http://(www*.|)sysopt.com/pcmech2.gif
AD http://(www*.|)sysopt.com/charles.gif
AD http://adopt.hbmediapro.com/contents/([0-9]*[0-9])/([0-9]*[0-9]).gif
AD http://(www*.|)voodooextreme.com/affiliate_search_120x90_bottom.gif
AD http://(www*.|)pcoutfitters.com/stores/ve/pco_anim.gif
AD http://(www*.|)dimension3d.com/images/jpabutton.gif
AD http://(www*.|)macintouch.com/images/acius08.gif
AD http://216.87.208.127/images/fb_button_105X30.gif
AD http://(www*.|)bcentral.com/images/bc/ie-static.gif
AD http://(www*.|)bcentral.com/images/meta/logo/msnlogo.gif
AD http://(www*.|)expedia.com/daily/home/images/amex.gif
AD http://(www*.|)expedia.com/daily/home/images/worldspan.gif
AD http://gs.cdnow.com/RP/CDN/graphics/home/home_visa.gif
AD http://cdn*.adsdk.com/CDN/**.gif
AD http://gs.cdnow.com/graphics/CMS/65/7865.gif
AD http://(www*.|)reel.com/content/reelimages/gbl/visa_logo.gif
AD http://(www*.|)reel.com/content/reelimages/gbl/nav_wingspan.gif
AD http://(www*.|)hollywoodvideo.com/pix/gc_logo_blk.jpg
AD http://(www*.|)whatisthematrix.com/234x60_v5.gif
AD http://images.resellerratings.com/images/prices/*.(gif|jpg)
ADHTML http://(www*.|)resellerratings.com/price-direct-theinquirer.pl
ADHTML http://www.gizmag.com/ads/**.htm
ADHTML http://www.gizmag.com/ads.php**
ADHTML http://cp.intl.match.com/eng/prm/**.html
ADPOPUP http://**ads/**popups/**.html
ADPOPUP http://**popups/**promo**.html
ADPOPUP http://32.96.232.10/teleweb/autopop/pop.asp?**
ADPOPUP http://(www*.|)novuslink.net/mk/get/fc2
ADPOPUP http://(www*.|)barnesandnoble.com/promo/coupon/popups/**.asp?**
ADPOPUP http://(www*.|)barnesandnoble.com/popup_cds*.asp?**
ADPOPUP http://adserver.trb.com/html.ng/**adtype=popwindow**
ADPOPUP http://images.weeklyworldnews.com/ad_server/**.html
ADPOPUP http://216.40.195.26/Reliaquote/**.html
ADPOPUP http://(www*.|)zdmcirc.com/zdmcirc/popups/*.html
AD http://(www*.|)zdmcirc.com/graphics/*pop*.gif
AD http://app-05.www.ibm.com/images/**.gif
AD https://ssl-images.amazon.com/images/**
## Now much too general. Yanking and making a new one.
##AD http://g-images.amazon.com/images/G/***.gif
ADHTML http://bwp.zdnet.com.au/search
ADHTML http://(www*.|)zdnet.com/fcgi-bin/becky/**
ADHTML http://rcm**.amazon.**/e/cm?**f=ifr**
ADHTML http://(www*.|)burstnet.com/cgi-bin/ads/**.cgi/**/RETURN-CODE
ADHTML http://*/cgi-bin/ad/inline?**
ADJS http://rcm.amazon.com/e/cm?**
ADJS http://ads[0-9].gamecity.net/modperl/jsformat.pl?**
ADJS http://(www*.|)burstnet.com/cgi-bin/ads/**.cgi/**/JS**
AD http://(www*.|)burstnet.com/cgi-bin/ads/ad*.cgi/ns
AD http://(www*.|)burstnet.com/cgi-bin/ads/**.cgi**
AD http://(www*.|)burstnet.com/gifs/*.gif
AD http://ds.serving-sys.com/BurstingRes/**.(gif|jpg)
AD http://ads[0-9].gamecity.net/images/*.gif
AD http://(www*.|)mp3.com/images/MP3Com/bigwords_120x25.gif
AD http://216.200.201.200/img/template/va-logo.gif
AD http://webcenters.netscape.com/shopping/gr/shoplogo.gif
AD http://(www*.|)video-now.com/research/salesBanner*.gif
AD http://*/cgi-bin/webconnect.dll?*
AD http://secure.webconnect.net/cgi-bin/webconnecthome.dll?**
AD http://209.90.128.55/click2/ad_bin/**.gif
AD http://usa.nedstatbasic.net/cgi-bin/referstat.gif?**
AD http://ad[0-9]*.yourmedia.com/datas/**/img/*.gif
AD http://ad[0-9].pamedia.com.au/images/*.gif
AD http://(*.|)linkbuddies.com/image.go?*
ADHTML http://mm.chitika.net/minimall?**
ADHTML http://*.linkbuddies.com/image.php?**
ADHTML http://*.desktopia.ru/index/iframe*.htm
ADHTML http://*.lbe.ru/cgi-bin/iframe/**
AD http://*.lbe.ru/bb.cgi?**
AD http://*.lbe.ru/cgi-bin/banner/**
AD http://(*.|)websponsors.com/**.gif
AD http://(www*.|)websponsors.com/**.gif
AD http://images.thisislondon.co.uk/**/sponsorship**.gif
AD http://ad.linkexchange.com/**
AD http://media.exchange-it.com/image.go?**
AD http://banner.freeservers.com/*.gif
AD http://banner.linkexchange.com/**
AD http://leader.linkexchange.com/**
AD http://**/*468[x_]60*.(gif|jpg)
AD http://gif.hitexchange.net/**
AD http://ad2.jwtt3.com/**
AD http://ads*.zdnet.com/**
AD http://adserv.net/but/*.gif
AD http://**/adserver/**.gif
AD http://**/adserver/**.jpg
AD http://**/adserver/banner_request/**
AD http://**/adserver.phtml**
AD http://**/adserver.exe/**
AD http://**/AdServer.exe/**
AD http://*/bm/*.gif
AD http://**/oasisi.php?**
AD http://assets.bravenet.com/bravenet/images/c/**
ADBG http://**/ad_bkgd.gif
ADBG http://ads.cmpnet.com/cmpnet/bgimage?**
ADBG http://(www*.|)bigcharts.com/images/ads/compaq.gif
ADBG http://cbs.marketwatch.com/images/ads/*_paper.gif
ADPOPUP http://cbs.marketwatch.com/membership/promo/memberB_access_promo.asp?**
ADHTML http://adserv.ads-tracker.com:8080/server/iframe-ad/client/realgn.com/banner/**
ADJS http://adserv.ads-tracker.com:8080/server/js-ad/client/realgn.com/banner/**
ADJS http://adserv.bravenet.com/cpceng.php?*type=sponsorbar*
ADJS http://mercury.bravenet.com/rover/**
ADJS http://au.java.yahoo.com/java/js_template/468_*.js
ADJS http://**/adjs.php**
ADJS http://www.timesonline.co.uk/genads/**.js
ADJS http://news.ninemsn.com.au/9msnshared/spac.js
PASS http://adserver.yahoo.com/a?*p=broadcast*
WEBBUG http://geo.yahoo.com/f?**
WEBBUG http://*.adserver.yahoo.com/l?**
WEBBUG http://www.bravenet.com/setcookie.php
WEBBUG http://*.statcamp.net/logging/**
ADHTML http://*.yahoo.com/java/js_template/728_reg_061501_loop_true.js
ADHTML http://ypn-js.overture.com/d/search/p/ypn/jsads/?**
ADHTML http://**/phpads.php**
PASS http://(www*.|)ad.nl/ad/**.gif
PASS http://(www*.|)mamut.com/images/ads/**
PASS http://(www*.|)retravision.com.au/**
PASS http://*.adobe.com/ads/**
PASS http://(www*.|)internettg.org/newsletter/dec00/images/ad_gif.gif
PASS http://((www*.|)skins.be)/framepic.php?(*) http://$1/kijk_onder.php?$3
PASS http://(*.|)skins.be/kijk_onder.php?**
PASS http://(www*.|)molendatabase.nl/nederland/kijk.php?**
PASS http://(www*.|)bikepoint.com.au/bikecontent/**
ADHTML http://adserver.news.com.au/html.ng/**
ADHTML http://**/(kijk*|adframe).php**
ADHTML http:/(www*.|)dgmaustralia.com/m/ii.asp?contid=**
ADSWF http://adimages.go.com/ad/**.swf**
ADSWF http://**/(onlineads|[Aa]ds)/**.swf**
ADSWF http://assets.bravenet.com/bravenet/images/**.swf*
ADSWF http://ads.adx.nu/dn/html/**.swf**
ADSWF http://img-cdn.mediaplex.com/**.swf
ADSWF http://**/advert**.swf
ADSWF http://(www*.|)qrz.com/pix/**.swf**
ADSWF http://hypecouncil.com--live.com/flv/**.swf**
ADSWF http://(www*.|)hypemakers.net/**/creative/**.swf
ADSWF http://**.swf?clickTag=**
ADSWF http://adtech.panthercustomer.com/apps/**.swf**
ADSWF http://eas.statcamp.net//media**.swf**
ADJS http://**/adx.js
ADJS http://adserv*.adtech*/?addyn**
ADJS http://adserv*.adtech*/addyn/**
ADJS http://adforce*/?addyn**
ADTEXT http://ads.addynamix.com/**
AD http://*.media.addynamix.com/**.gif**
AD http://(www*.|)qrz.com/pix/[0-9]*.gif
AD http://adserv*.adtech.de/?adserv**
AD http://adtech.panthercustomer.com/apps/**.(jpg|gif|png)
AD http://helios.aftenposten.no/adserv**
AD http://*/iserver/**/AAMSZ=**
AD http://(*.|)nytimes.com/adx/**.(jpg|gif)
AD http://graphics*.nytimes.com/marketing/**.(gif|jpg)
AD http://**/adcycle.cgi?**
AD http://*/adimages/**
AD http://adserver.*/**
AD http://adserv.*.de/images/**.(gif|jpg)
AD http://(www*.|)worknwoman.com/adserve/ads_2.cgi?page=*
AD http://(www*.|)worknwoman.com/adserve/images/**.gif
AD http://ads*.hyperbanner.net/gif.cfm?**
AD http://(www*.|)contentserver.com.au/ads/ad_loader.cfm?**
AD http://adimages.criticalmass.com/**
AD http://*/adserv/**.gif
AD http://*/ad_images/**.gif
AD http://*/nsadimages/**
AD http://**/ad/*.gif
AD http://*/ad?**
AD http://*/topcash/*.gif
AD http://*/*flashclick*.gif
AD http://205.153.208.93/?**
AD http://208.178.186.243/**.gif
AD http://image1.narrative.com/news/*.gif
AD http://**?adserv**
AD http://service.bfast.com/bfast/serve/**
AD http://service.bfast.com/bfast/serve?**
AD http://*/AdSwap.dll?**
AD http://*/images_ads/*.gif
AD http://*/button_ads/**.gif
AD http://*/images/*_ads/**.gif
AD http://*/adjuggler/images/*.gif
AD http://(www*.|)thenation.com/images/aj/*.gif
AD http://*/clickthrough/*.gif
AD http://**/adimg/**
AD http://**/ad_imgs/**
AD http://**/ad_*.gif
AD http://adimg.egroups.com/img/**
AD http://adimgpj.voila.fr/bandeaux/**
AD http://(www*.|)jememarre.dpn.ch/publicite/**
AD http://(www*.|)clicmoi.com/cgi-bin/pub.exe?*
AD http://**/publicidad/**.gif
AD http://**/fwiadimages/**.gif
AD http://**/ban[0-9].gif
AD http://**/ban[0-9][0-9].gif
AD http://*/cobanner*.gif
AD http://*/cobanner*.jpg
AD http://**/ABS/**.GIF
AD http://**/ABS/**.JPG
AD http://*/annons/**.gif
AD http://*/servfu.pl?**
AD http://sunserver1.songline.com:1971/*?
AD http://ad.blm.net/image?**
AD http://*/ad/**.gif
AD http://*/onlinead/**.gif
AD http://*.mtree.com/xbs/**
AD http://*/ad/igc.cgi/**
AD http://cgi3.fxweb.com/v2-trackrun.cgi?**
AD http://(www*.|)fxweb.holowww.com/Assets/*.gif
AD http://yoda.cybereps.com:8000/**.gif
AD http://images.cybereps.com/traffic/images/**
AD http://my.netscape.com/publish/images/addchannel_anim.gif
AD http://**/showad.cgi?**
AD http://ads.hbv.de/**
AD http://*/viewbanner.php*?bannerID*
AD http://images*.iac-online.de/**.gif
AD http://service.bol.de/partner/*.gif
AD http://(www*.|)manager-magazin.de/mmo_banner/*.gif
AD http://**servant.guj.de/**
AD http://(www*.|)linux-magazin.de/banner*
AD http://banner.websitesponsor.de/nt-bin/show**
AD http://(www*.|)websitesponsors.com/cgi-bin/system/image?**
AD http://(www*.|)websitesponsors.com/cgi-bin/system/eimage?**
AD http://(www*.|)websitesponsors.com/referrals/*.gif
AD http://(www*.|)websitestop.com/clicktrade/**.gif
AD http://**/linkshare/**.(gif|jpg)
AD http://(*.|)iwin.com/ad/**
AD http://ad.*/cgi-bin/rotate.php*?*
AD http://**/468x60**.gif
AD http://**/(adview|adimage|viewbanner).php?**
AD http://admech.*.com/AdCall.asp?**
AD http://oa.techcrunch.com/openads/www/delivery/ai.php?**&contenttype=(gif|jpeg)**
AD http://images.trafficmp.com/tmpad/**.gif
AD http://*.trafficmp.com/a/bpix?**
AD http://**/delivery/lg.php?bannerid=**
WEBBUG http://oa.techcrunch.com/openads/www/delivery/lg.php?bannerid=**
WEBBUG http://i.ixnp.com/**.gif
ADHTML http://*.trafficmp.com/tmpad/banner/itrack*.asp?**
ADHTML http://*.trafficmp.com/a/i?**
ADHTML http://(www*.|)sponsorads.de/click.php?**
ADHTML http://info-ad.de/oben.php?**
ADHTML http://openads.zeads.com/www/delivery/afr.php?**
ADHTML http://banners.webmasterplan.com/view.asp?**
ADHTML http://www.game-advertising-online.com/index.php?**output=html**
ADHTML http://server.cpmstar.com/view.aspx?**
ADJS http://server.cpmstar.com/cached/flashad.js
ADSWF http://server.cpmstar.com/cached/creatives/*.swf
ADSWF http://www.game-advertising-online.com/b/**.swf**
AD http://server.cpmstar.com/cached/creatives/*.(gif|jpg)
AD http://www.game-advertising-online.com/b/**.png
PASS http://load.weatheronline.co.uk/**popup.html
PASS http://pages.ebay.com**popup.htm**
PASS http://*.ergophizmiz.com/**
PASS http://*.mini-itx.com/**
PASS http://www.saunalahti.fi/~ojn/photos/popup.html?**
PASS http://(*.|)pbs.org/includes/tvschedules/**popup.htm**
PASS http://(*.|)regiftable.com/regiftingrobinpopup.html
ADPOPUP **popup.htm**
ADPOPUP http://ad.iwin.com/tmpad/**.htm
ADPOPUP http://ad.iwin.com/tmpad/content/netflix/rollover.html
ADPOPUP http://ad.iwin.com/tmpad/banner/itrack.asp?**
ADPOPUP http://*.focalex.com/pops/popup(_general.emp|.mpl)?**
ADPOPUP http://*.focalex.com/offers.mpl?**
ADPOPUP http://*.puretec.de/werbung**
ADPOPUP http://popup.zmedia.com/popups/**
ADPOPUP http://popup.found404.com/*.*html?**
ADPOPUP http://popup.msn.com/*popupad.asp?**
ADPOPUP http://popup.msn.com/*PopupAd.asp?**
ADPOPUP http://(www*.|)gopopup.com/redir.php**
ADPOPUP http://(www*.|)deluxelink.de/script/gopopup.php?**
ADPOPUP http://(www*.|)sitepoint.com/popup/popup.php?**
ADPOPUP http://*.adsrevenue.net/popup.php?**
ADPOPUP http://(www*.|)7host.com/**/pop.asp?**
ADPOPUP http://*.popupmoney.com/**.php?**
ADPOPUP http://**/popup_exit/**.*html**
ADPOPUP http://**/aoexit.shtml?**
ADPOPUP http://nitrous.*fuel.com/**/exitpop*.html**
ADPOPUP http://nitrous.*fuel.com/framer.html**
ADPOPUP http://nitrous.*fuel.com/sites/hp4group2.html
ADPOPUP http://nitrous.*fuel.com/sites/aboutcom.html
ADPOPUP http://(www*.|)found404.com/affiliate*/pc404.html?**
ADPOPUP http://affiliate.cfdebt.com/banners/popupwin.asp?**
ADPOPUP http://**/hidden_popup.htm
ADPOPUP http://direct.ninemsn.com.au/**[Mm][Ee][Tt][Hh][Oo][Dd]=[Pp][Oo][Pp][Uu][Pp]**
ADPOPUP http://(www*.|)bt-chat.com/overlib.js
# German for "ad"
COUNTER http://**/werbung/ziAdCount?**
PASS http://(www*.|)kodi.de/werbung/**
# ad: de:werbung,anzeige da:reklame no:annonser es:reklaam
ADJS http://(anzeige|werbung|WERBUNG|annonser|reklame|reklaam).*/**.([Jj][Ss])
ADJS http://helios.aftenposten.no/addyn**
ADJS http://annonser.dagbladet.no/eas?**;js=y
AD http://annonser.dagbladet.no/eas?**;cre=img
ADHTML http://www.dagbladet.no/inc3/hmarg/dblinker.php
ADHTML http://annonser.dagbladet.no/eas?**
AD http://(anzeige|werbung|WERBUNG|annonser|reklame|reklaam).*/**.([Gg][Ii][Ff]|[Jj][Pp][Gg])
AD http://**/(anzeige|werbung|WERBUNG|annonser|reklame|reklaam)/**.([Gg][Ii][Ff]|[Jj][Pp][Gg])
AD http://*.de/images/wrb/**
# several patterns from Sergey Smirnov
AD http://www.hotlog.ru/buttons/*.gif
AD http://217.73.192.65/top100/banner*.gif
AD http://reklama.utro.ru/images/**
AD http://reklama.utro.ru/bb.cgi?*
AD http://images.directtrack.com/**.gif
AD http://(www*.|)keralanext.com/image/**.gif
AD http://adv.aport.ru/scripts/adv.dll?*
ADHTML http://(www*.|)netzagent.com/freetv/ad.htm
ADHTML http://*/hserver/**
ADHTML http://bannervip.web1000.com/web1000/[ab].asp
ADHTML http://**.adbutler.*/view.php?**inv=if**
ADHTML http://imgserv.adbutler.*/ieservad?**
ADHTML http://imgserv.adbutler.*/adserve/**type=iframe**
ADHTML http://channels.real.com/getlatest.glh?**
ADHTML http://(www.|)smh.com.au/adredirect.html?ad=**
WEBBUG http://tracking.starmedia.com/track.gif**
WEBBUG http://c.ninemsn.com.au/c.gif?**
ADJS http://ds.starmedia.com/jserver/**
ADJS http://(www*.|)real.com/scripts/popunder2_.js
PASS http://(www*.|)smh.com.au/animations/bn.gif
PASS http://(www*.|)3dpulpit.com/animations/*.gif
PASS http://(www*.|)smh.com.au/animations/*.gif
AD http://*/animations/*.gif
AD http://imgserv.adbutler.com/imgserve.ibs?**
AD http://**/ani.gif
AD http://**/anim.gif
AD http://**/gifanim*.gif
AD http://adfarm.mediaplex.com/ad/bn/**
AD http://(www*.|)date.com/GetImage.do?**
AD http://img*.mediaplex.com/**.gif
AD https://img*.mediaplex.com/**.gif
AD http://www.104.ch/bn/*.jpg
AD http://*/img/clients/bn*.gif
AD http://*/client/button**.gif
AD http://*.mediaplex.com/ads/**
AD http://*.mediaplex.com/ad/bn/**
AD http://**/ban/ani[0-9]*.gif
AD http://(www*.|)nmnews.net/images/ani**.gif
AD http://(www*.|)fxsound.com/grfx/dfx_animated.gif
AD http://*/animeu/*.gif
AD http://cdn.eyewonder.com/**.gif
ADJS http://cdn.eyewonder.com/**/*.js?**
ADJS http://imgserv.adbutler.com/jad?**
ADJS http://*.cybereps.com:8880/jserver**
ADJS http://216.148.128.89/jserver/**
ADJS http://home.netscape.com/h.js
ADJS http://*.usercash.com/**.js
ADHTML http://img.mediaplex.com/cgi-bin/html/**
ADHTML http://*.usercash.com/*.php**
ADHTML http://www.megaupload.com/adbrite.php?**
ADPOPUP http://**/ads/popup.shtml
ADPOPUP http://*.billiger-telefonieren.de/popup/*
ADPOPUP http://businessfactory.delphi.com/click.asp?**
ADPOPUP http://(www*.|)avault.com/ads/**
ADPOPUP http://*.doubleclick.net/ad**popup**
ADPOPUP http://ads.freecity.de/popup**
ADPOPUP http://ads.i2as.ulimit.com/oasisi-i.php?**
ADPOPUP http://(www*.|)fortunecity.com/marketplace/
ADPOPUP http://**/**/reclama/disp_banner.php**
ADPOPUP http://**.tvmovie.de/static/popup/**
ADPOPUP http://**.tvtoday.de/**popup**
ADPOPUP http://**.2xt.de/**popup**
ADPOPUP http://click4cash.de/popup/**
ADPOPUP http://**.aax.de/weblet/Banner**
ADPOPUP http://adserv.spiegel.de/**/ads/**.html
ADPOPUP http://(www*.|)babylon-x.com/servlet/click**
ADPOPUP http://(www*.|)t50.com/extra2.html
ADPOPUP http://(www*.|)t50.com/cgi-bin/download2.cgi
ADPOPUP http://(www*.|)altrawarez.com/**
ADPOPUP http://(www*.|)icewarez.net/popup*.htm*
ADPOPUP http://(www*.|)mywarez.net/my_files/exit.php
ADPOPUP http://(www*.|)easywarez.com/newsecrets.html
ADPOPUP http://(www*.|)spaceports.com/cgi-bin/ad.cgi?*
ADPOPUP http://(home.|www.|)netscape.com/misc/snf/popup_*.html
ADPOPUP http://(home.|www.|)netscape.com/misc/popup.html?**
ADPOPUP http://bannervip.webjump.com/ads/web1000/pop-up.html
ADPOPUP http://*go2net.com/adpopup?**
ADPOPUP http://server*.hypermart.net/adpopup?**
ADPOPUP http://*.to/pop.asp?**
ADPOPUP http://*tantofaz.net/local/misc/points/popup.asp
ADPOPUP http://cvo.tsx.org/window.mml
ADPOPUP http://(|www).space.com/php/popup/promo/**.php
ADPOPUP http://**/popupad.php
ADPOPUP http://(www*.|)nwfusion.com/auddev/pop/*.html
ADPOPUP http://img-snv.mediaplex.com/ads/**/pop_under_source.htm
ADPOPUP http://**/ads/popups/**.html
ADPOPUP http://(www*.|)popupad.net/ats/switch.php
ADPOPUP http://**/Ads/Media/Rich/**.html
ADPOPUP http://*.freeze.com/**.asp?**
AD http://(www*.|)tutopia.com/images/model/**.(gif|jpg)
AD http://(www*.|)tutopia.com/images/arControl/*.jpg
AD http://(|www).space.com/promo/images_cj/**.jpg
AD http://(www*.|)smh.com.au/images/**promo*.(gif|jpg)
ADJS http://www.space.com/js/site_pops.js
PASS http://*.cnet.com/Ads/Media/Images/Buttons/*sas*
PASS http://*.cnet.com/Ads/Media/Images/Buttons/*pfc*
AD http://(www*.|)msnbc.com/site_elements/msn_shopping_nbc_snap.gif
PASS http://(www*.|)msnbc.com/ads/i/corners.gif
PASS http://(www*.|)msnbc.com/ads/i/grey.gif
PASS http://(www*.|)topjobs.com.au/ads/**.gif
PASS http://(www*.|)eonline.com/Ads/Includes/Images/search.back.gif
PASS http://(www*.|)zdnet.com/include/**
PASS http://(www*.|)norml.org/about/ads/NORML_*
PASS http://(www*.|)adobe.com/ads/**.gif
PASS http://(www*.|)apple.com/hardware/ads/**
PASS http://(www*.|)buyersport.com/**/ads/**.html*
PASS http://images.salon.com/src/ads/**_flashme*.html?**
PASS http://cache.ultramercial.com/ads/**.gif
ADSWF http://**/Ads/Media/Flash/**.swf**
PASS http://**apple.com/switch/ads/**
PASS http://tanopah.jo.free.fr/ADS/bloc**
ADJS http://c*.zedo.com/**jsc/**.js
ADHTML http://mozo-widgets.f2.com.au/widgets/multiwidget3/SMH/**
ADHTML http://static.thebigchair.com.au/egnonline/**
ADHTML http://xads.zedo.com/ads*/[a-z]?**
ADHTML http://ccas.clearchannel.com/CCAS_tag.html?**
ADPOPUP http://c*.zedo.com/jsc/c1/ff2.html?**
WEBBUG http://c[0-9].zedo.com/*/0/0/0/blank.gif
WEBBUG http://adlog.com.com/adlog/i/**
ADSWF http://**/bannerfarm/**.swf
ADSWF http://adsys.townnews.com/*/creative/**.swf**
PASS http://ads.vnuemedia.com/ads/amusementbusiness/**
PASS http://(www*.|)acmehorses.com/media/ads/**
PASS http://(www*.|)emagen.com.au/Ads/**
PASS http://www.yamaha-motor.com.au/images/**
PASS http://images.apple.com/getamac/ads/**
AD http://*ads.zedo.com/ads2/[a-z]?**
AD http://**/([Aa][Dd][Ss]|_ads|ad.s|ads2|adsart|ars-ads|bfarm|bannerfarm|liveads|adlinks|[Bb]anner*[Aa]ds)/**.([Gg][Ii][Ff]|[Jj][Pp][Gg])**
AD http://**/ads.(pl|cgi)?**
AD http://images.salon.com/src/bizwidget/travelocity/bali.gif
AD http://(www*.|)salon.com/Creatives/**.(jpg|gif)
AD http://(www*.|)realcastmedia.com/creatives/ml/*_[1-9]*x[1-9]*.gif
AD http://adsys.townnews.com/*/creative/**.jpg
AD http://ccas.clearchannel.com/cc-common/CCAS_media/**.(gif|jpg)
AD   http://view.iballs.*.avenuea.com/iballs/view/**/direct/**
AD   http://view.avenuea.com/view/**
AD   http://view.avenuea.com/avenuea/view/**
AD   http://image.*.avenuea.com/**/image.*.avenuea.com/Banners/**.gif
AD   http://a[0-9]*.akamai*.net/**/(promo|promos)/**.(gif|jpg)
AD   http://a[0-9]*.akamai*.net/**/www.dealtime.com/**affiliate/**.gif
AD   http://a[0-9]*.akamai*.net/**/imgsrc.*.avenuea.com/Banners/**.gif
AD   http://a[0-9]*.akamai*.net/**/image.*.avenuea.com/Banners/**.gif
AD   http://a[0-9]*.akamai*.net/**/www.salon.com/Creatives/**.gif
AD   http://a[0-9]*.akamai*.net/**/www.space.com/images/space_shop_badge.gif
AD   http://a[0-9]*.akamai*.net/**/www.space.com/**/sponsors/**.gif
AD   http://a[0-9]*.akamai*.net/**/www.namezero.com/images/*.gif
AD   http://a[0-9]*.akamai*.net/**/ad.caramail.com/pub/**
AD   http://a[0-9]*.akamai*.net/**/ad.adtraq.com/**
AD   http://a[0-9]*.akamai*.net/**/(ad(|image)(|s)|[Bb]anner(|ad)(|s))/**.gif
ADSWF http://a*.akamai*.net/**/*.shoshkeles.com/**.swf
ADPOPUP http://(www*.|)zeropaid.com/images/ads/**pop*.html
ADPOPUP http://adv*.eblocs.com/spyblocs/adv/**.html
PASS http://www.pers.mq.edu.au/ads/**
PASS http://nx1.salon.com/RealMedia/ads/click_lx.ads/www.salonmagazine.com/**.html/**
PASS http://cache.ultramercial.com/ads/**.html
ADHTML http://**/ads/**.html**
ADSWF http://**/ads/**.swf
WEBBUGJS http://static.woopra.com/js/woopra.js
WEBBUGJS http://s.clicktale.net/WRa.js
WEBBUGJS http://a[0-9]*.g.akamai*.net/**/stats.hitbox.com/js/**.js
WEBBUG http://*.hitbox.com/HG**
WEBBUG http://hits.gureport.co.uk/HG**
ADJS http://*.akamai*.net/**/www.msnbc.com/m/js/flash.js
ADJS http://*.akamai*.net/**/www.msnbc.com/m/js/flash.vbs
PASS http://a[0-9]*.g.akamai*.net/arttoday.token/sites/clip-art/**.gif
PASS http://a[0-9]*.g.akamai*.net/**/bg*.gif
PASS http://a[0-9]*.g.akamai*.net/**/*.*.*/**.gif
PASS http://a[0-9]*.g.akamai*.net/**/*.com/**.gif
PASS http://a[0-9]*.g.akamai*.net/**/background*.gif
PASS http://a[0-9]*.g.akamai*.net/**/backtile*.gif
PASS http://a[0-9]*.g.akamai*.net/**/bg_*.gif
PASS http://a[0-9]*.g.akamai*.net/**/icon**.gif
PASS http://a[0-9]*.g.akamai*.net/**/logos/**.gif
PASS http://a[0-9]*.g.akamai*.net/**/header**.gif
PASS http://a[0-9]*.g.akamai*.net/**/nav**.gif
PASS http://a[0-9]*.g.akamai*.net/**/spacer*.gif
PASS http://a[0-9]*.g.akamai*.net/**/rules/*.gif
PASS http://a[0-9]*.g.akamai*.net/**/dotclear*.gif
PASS http://a[0-9]*.g.akamai*.net/**/bg*.gif
AD   http://a[0-9]*.g.akamai*.net/**.gif
PASS http://(www*.|)csiro.au/promos/**.gif
PASS http://(www*.|)smh.com.au/media/promo/iconsm.gif
PASS http://(www*.|)afl.com.au/lib/images/promos/*.gif
PASS http://pics.ebay.com/aw/pics/**/buyItNow_*x*.gif
PASS http://(www*.|)redhat.com/img/*promo*.gif
PASS http://(www*.|)*sony.com/**promo**.gif
PASS http://*.dell.com/images/**
##AD http://**/*promo[0-9]*.(gif|jpg)
##AD http://**/[Pp]romo(s|)/**.(gif|jpg)
AD http://images.getrelevant.com/**
AD http://icache.getrelevant.com/**
AD http://*.getrelevant.com/**.gif**
AD http://(www*.|)airgunstore.com/AGS*.GIF
AD http://adgraphics.theonion.com/**.(gif|jpg)
AD http://203.147.223.47/retro_au/**.gif
AD http://images.yahoo.com/promotions/*/*.gif
AD http://rd.yahoo.com/**http://store.yahoo.com/cgi-bin/clink?ydomains+merchant-ad**
AD http://au.java.yahoo.com/java/*/abn*
ADHTML http://red.namezero.com/strip2/strip.jhtml?**
PASS http://(www*.|)direct.bigpond.com/images/banner/*.gif
PASS http://(www*.|)cai.com/banner/*.gif
PASS http://(www*.|)google.com/adv/*.html
PASS http://images.google.(co.*|com|com.*)/images?**
PASS http://(www*.|)advantedgeonline.com.au/adv/**
PASS http://(www*.|)fuzzyfur.net/DSOS/adv/**
PASS http://**/banner/site/menu/**.jpg
PASS http://*cyberjaya-msc.com/images/banner/**
PASS http://(www*.|)stgeorge.com.au/resources/stg/images/banner/**.gif
PASS http://(www*.|)indoorclimbing.com.au/images/banner/**
PASS http://(www*.|)ap.dell.com/ap/images/banner/*.(jpg|gif)
PASS http://(www*.|)info.gov.hk/banner/**
PASS http://(www*.|)saintcorporation.com/images/banner/**
PASS http://(www*.|)sueddeutsche.de/imperia/md/images/banner/**
PASS http://nosoftwarepatents.com/**
PASS http://(www*.|)tmanime.com/tmanime/wallpapers/banner**
PASS http://(www*.|)axiossystems.com/images/banner/**
PASS http://zzz.com.ru/banners/**
PASS http://*.openoffice.org/banners/**
PASS http://newsimg.bbc.co.uk/**.(gif|jpg)
PASS http://(www*.|)supergo.com/images/banners/**
PASS http://(www*.|)sabregen.co.za/[Pp]ict_banner/**
PASS http://(www*.|)bridgestone.com.au/common/commonimages/banners/**
PASS http://(www*.|)gamesmarket.com.au/images/banners/**
PASS http://mckague.com/photographs/special/banners/**
PASS http://(www*.|)pulitzer.org/**
PASS http://(www*.|)pch.net/images/sponsors/*.gif
PASS http://www.ati.com/banners/images/**
PASS http://(www*.|)epson.*/banners/**.(gif|jpg)
PASS http://discussion.ottawabusinessjournal.com/pubfiles/obj/banners/**.jpg
PASS http://(www*.|)racv.com.au/images/augbanners/hmpage_top_*_top_*.jpg
PASS http://(www*.|)wasabisystems.com/images/banner*/**
PASS http://(www*.|)ow.com.au/images/Left_banners/**
PASS http://(www*.|)palmone.com/asia/images/entry/banner/**
PASS http://partner.scribona.no/upload/banner/**
PASS http://(www*.|)abc.net.au/news/img/*banner*.gif
PASS http://advocacy.daemonnews.org/**
PASS http://dvdstation.com.au/images/adverts/**
PASS http://shop.private.com/shop/media/**
PASS http://(www.|)seek.com.au/**
PASS http://(www*.|)bunnings.com.au/layouts/cust_bunnings/adverts/**
PASS http://www.sigpet.com.au/assets/**
PASS http://www.fredart.com/fredart/banners/**
PASS http://www.stuff.co.nz/stuff/masthead/banner/**
PASS http://ez.no/var/ezno/storage/images/images/**
PASS http://(www.|)epa.ie/**
PASS http://(www*.|)alternate.nl/pix/misc/bgtreebanner.gif
PASS http://(www*.|)genright.com/images/**
PASS http://cisco.netacad.net/**
PASS http://www.edubase.com.my/**
PASS http://upload.wikimedia.org/wikipedia/**
PASS http://www.avico.com.au/_lib/images/**
PASS http://www.insuremyride.com.au/images/**
PASS http://(www*.|)trading*post.com.au/ContentManagement/**
PASS http://www.agentpp.com/**.gif
PASS http://www.parallels.com/files/img/**
PASS http://(www*.|)wavefield-inseis.com/images/**
PASS http://*/var/ezwebin_site/storage/images/**
PASS http://(www*.|)matrox.com/*/banners/**
PASS http://(www*.|)research.att.com/**
PASS http://(www*.|)javasoft.com/images/banners/*.gif
PASS http://(www*.|)lancrypto.com/images/banners/*.gif
PASS http://(www*.|)agcrc.csiro.au/img/banners/*.gif
PASS http://(www*.|)Europe.DataFellows.com/images/banners/*.gif
PASS http://*/images/banners/anonline.jpg
PASS http://(www*.|)corel.com/graphics/banners/**
PASS http://(www*.|)verifone.com/images/banners/*.gif
PASS http://java.sun.com/images/banners/*.gif
PASS http://(www*.|)tandberg.com/images/banners/*.gif
PASS http://virtuallythere.com/cgi-bin/mqcustomconnect?**
PASS http://(www*.|)parentingplace.com/images/banners/*.gif
PASS http://**/banners/**spacer.gif
PASS http://image.weather.com/pics/banners/banner_general.jpg
PASS http://s3.amazonaws.com/twitter_production/**
PASS http://(www.|)tvs.org.au/rw_common/themes/**
PASS http://(www.|)telstra.com.au/banners/**
PASS http://(www.|)alifexi.org/images/**
PASS http://(www.|)moxa.com/banner/**
PASS http://static.gamesradar.com/images/**
PASS http:/bigpond.com/cms/res/unmetered/images/**
PASS http://yggdrasilradio.net/images/banners/**
PASS http://thetvdb.com/banners/**jpg
AD http://(www*.|)planet3dnow.de/images/zusatz/*.gif
AD http://(www*.|)sueddeutsche.de/sz/misc/marktplatz/**.gif
AD http://**/([Aa]dvert|ADVERT|advbn|adgifs|blipverts|showsell|*[Bb]anner|bann|bannerlink|linkbacks|liveads|adproof|SiteSponsor|spon)**.([Gg][Ii][Ff]|[Jj][Pp][Gg]|[Pp][Nn][Gg])*
AD http://*/advert/bin/image?**
AD http://*/Ad=*/**
AD http://**/sponsorad.gif
AD http://**/bin/statdeploy?*
AD http://**/images/ads_new/*.gif
AD http://**/images/ads-side*/ad-*.gif
AD http://**/images/sponsor.gif
AD http://*.the-park.com/images/*banner*.gif
AD http://*/*/ba_ad/*.gif
AD http://*/cgi-bin**/banner.cgi**
PASS http://(www*.|)uq.edu.au/**banner**.gif
PASS http://(www*.|)mpce.mq.edu.au/images/**
PASS http://msdn.microsoft.com/msdn-online/shared/graphics/banners/*-banner.gif
PASS http://(www*.|)mozilla.org/**-banner.gif
AD http://**-banner.gif
PASS http://(www*.|)amazon.com/g/v9/icons/*-banner-*.gif
AD http://**/*-banner-*.gif
## PASS http://(www*.|)ztree.com/assets/images/**
## PASS http://(www*.|)doschdesign.de/assets/images/**
## PASS http://(www*.|)stallion.com.au/assets/images/**
## PASS http://209.1.197.35/assets/images/**
## AD http://*/assets/images/*.jpg
ADJAVA http://(www*.|)ntexplorer.com/DynamicBanner.class
AD http://(www*.|)matrox.com/mga/media/int_banners/*.gif
AD http://image.weather.com/creatives/**.gif
AD http://**/webbanners/*.gif
PASS http://**/banners/back.gif
PASS http://**/banners/bgpic.gif
PASS http://(www*.|)energy.gov/images/banners/*.gif
PASS http://(www*.|)blackwell-science.com/**/banners/**
PASS http://d.yimg.com/a/p/rids/2[0-9][0-9][0-9][0-9][0-9][0-9][0-9]/**
WEBBUG http://*.yimg.com/**/i/**.jpg?**sig=**
PASS http://*.yimg.com/**/(bin|auc)/**.gif
PASS http://*.yimg.com**/(i|xp|cx)/**.(gif|jpg)
ADSWF http://*.yimg.com/**/*[0-9]x[1-9]*.swf**
AD http://l.yimg.com/cv/ae/us/**.swf
AD http://*.yimg.com**/(a|adv|ba2)/**.(gif|jpg)
AD http://**/banners/*.banner
AD http://**/Banners/Images/**
AD http://**/bnrs*/*.gif
AD http://**/bn/**.gif
AD http://**/bnr-*.gif
AD http://**/(bann|banrgifs|ad-(banner|images|bin)|sponsor|((pr|s|other|)banner(s|sp|))|baners|Banner(s|)|BANNER(S|)|banniere|baneri)*/**.(gif|GIF|jpg|JPG)**
AD http://**/adserve?*;image;**
AD http://(www*.|)eads.com/adserve/adserve.dll/banner?**
AD http://images.blogads.com/**/thumb?**
AD http://ads*.intelliads.com/html-bin/adselect-**
AD http://ads*.intelliads.com/images/**.gif
AD http://ads*.intelliads.com/html-bin/adselect300.asp?obnum=*
ADSWF http://**/ad-bin/*.swf
ADSWF http://**/bannieres/**.swf**
ADSWF http://reiter.typepad.com/*/banniere.swf
PASS http://**/SmartBanner/**single_pixel.gif
PASS http://**/SmartBanner/**1ptrans.gif
PASS http://**/SmartBanner/chtml/*/page/*.html/**
ADJS http://**/SmartBanner/jsad**
ADJS http://icc.intellisrv.net/adopt.jsp?**
ADJS http://**/DynamicJSAd?**
ADJS http://(www*.|)budsinc.com/pubcodes/banner.js
ADJS http://show.budsinc.com/jserver/**
ADHTML http://(www*.|)advertwizard.com/plugin/plugin.phtml?**
ADHTML http://**/SmartBanner/htmlad?**
PASS http://wyse.com.au/graphics/ban/**
AD http://(www*.|)advertwizard.com/banner_display/show_banner.phtml?**
AD http://**/SmartBanner/**.gif
AD http://**/SmartBanner/nph-graphic**
AD http://**/SmartBanner/nph-defgraphic**
AD http://**/maxcash/*.jpg
AD http://**/cgi-bin/cash4views.pl?banner=**
AD http://**/adstream.cgi/**
AD http://**/*adbans*.gif
AD http://**/roto/rotoad*.jpg
AD http://**/roto/**ban*.jpg
AD http://**/sponsor/banner*.jpg
AD http://**/sponsor/*.gif
AD http://**/(banners|banniere)/**.jpg
AD http://**/ban/*.gif
AD http://**/ban/*.jpg
ADHTML http://www.s2d6.com/**
ADHTML http://ad.preferences.com/iframe;**
ADHTML http://ad.preferences.com/oframe;**
ADJS http://ad.preferences.com/oscript;**
ADJS http://ad.preferences.com/jscript**
AD http://gm.preferences.com/image;**
AD http://ad.preferences.com/image;**
AD http://ad.preferences.com/**.gif
AD http://media.preferences.com/**.gif
AD http://privacyproxy.nytimes.com/RealMedia/PP/IMP/**
AD http://(www*.|)reftracker.de/buttons/button*.gif
AD http://tracker.advancewebhosting.com/images/*.gif
AD http://tracker.advancewebhosting.com/image.phtml?**
AD http://199.172.144.25/*.gif
AD http://207.168.8.47/*.gif
AD http://207.178.253.240/banners/**.gif
AD http://ad.blm.net/image?**
AD http://(www*.|)sun.com/sunworldonline/swol-ad/**
AD http://207.87.27.37/news/an_*.gif
AD http://*/graphics/ad-banner/*.gif
AD http://*times*/*.*x*.gif?**
AD http://*times*/TT*.*x*.gif?**
AD http://199.78.52.10/*web_ani/*.gif
AD http://199.78.52.10/web_gif/*.gif
AD http://199.78.52.10/~web_ani/*.gif
AD http://**/*_ad_*x*.gif
AD http://**/[Aa]d[Bb]anner**.(gif|jpg)
AD http://**/image.avenuea.com/Banners/**
AD http://**/Ads/Media/Images/**.gif**
AD http://**/Ads/Media/Images/**.jpg**
AD http://*/bfast/serve?**
PASS http://ads.vnuemedia.com/image.ng/Site=amusementbusiness&**
AD http://*/image.ng;**
AD http://*/image.ng/**
AD http://ak.maxserving.com/images/**.gif
ADPOPUP http://*.maxserving.com/adclick/**
ADPOPUP http://**/phpAdsNew/adclick.php?**
ADJS http://*.maxserving.com/gen.js?**
PASS http://*.djnr.com/**/buttons/*blink.gif
PASS http://(www*.|)dpreview.com/reviews/*/Images/Captures/*blink.gif
PASS http://**/emoticons/blink.gif
AD http://**blink.gif
AD http://**/baner*.gif
AD http://register.ero.ru/pc/*.gif
AD http://xb.xoom.com/images/*.gif
AD http://(www*.|)addfreestats.com/cgi-bin/connect.cgi?**
AD http://admedia.xoom.com/Banners/**.gif
AD http://members.xoom.com/**/anixoom.gif
AD http://a*.interclick.com/**.gif
PASS http://ads.bmais.net/*.ng**
PASS http://ads.adsag.com/*.ng**
ADHTML http://a*.interclick.com/getJs.aspx**
ADHTML http://ilinks.industrybrains.com/showct?**
ADHTML http://**/advertpro/banners.pl?**
ADHTML http://**/advertpro/servlet/file?**
ADHTML http://**/advertpro/servlet/view/banner/html/**
ADHTML http://(www*.|).sys-con.com/(banner|ads)/**.cfm
ADHTML http://banners.sys-con.com/IFrames/*.php
ADHTML http://xb.xoom.*/xb*.odt
ADHTML http://adforce*/?adiframe**
ADHTML http://www2.efront.com/adserve.iframe/**
ADHTML http://(www*.|)macaddict.com/ad_frame/
ADHTML http://(www*.|)itworld.com/ad_*.htm**
ADHTML http://**/html.ng/**
ADJS http://banners.sys-con.com/phpAds**.js
WEBBUG http://(www*.|)powerweb.net/*/tracker.cfm/**.gif
WEBBUG http://*.2o7.net/b/ss/**?**
WEBBUG http://dw.com.com/clear/**.gif?**
WEBBUG http://**/AdsManager/adlog.php?**
WEBBUG http://log.go.com/log?**
WEBBUG http://*netshelter.*/serve.cgi?**
WEBBUG http://195.25.89.17/**_v?**
WEBBUG http://195.25.89.18/**_p?**
WEBBUG http://stat.cybermonitor.com/**_p?**
WEBBUG http://**/audit/track.cgi?**
WEBBUG http://*.netscape.com/c.cgi?**
WEBBUG http://*.sextracker.com/clit?**
WEBBUG http://register.ero.ru/g/ch.gif?**
WEBBUG http://register.ero.ru/g/cw.gif?**
WEBBUG http://*/0.gif?tag=**
WEBBUG http://*.microsoft.com/trans_pixel.asp?**
WEBBUG http://(www*.|)planet3dnow.de/cgi-bin/picount/count.pl
WEBBUG http://refcounter.sexhound.com/?id=**
WEBBUG http://images.sexhound.com/NewSite/spacer.gif
WEBBUG http://y1.extreme-dm.com/z/?tag=**
WEBBUG http://counter*.hitslink.com/stats-ns.asp?**
WEBBUG http://*.burstnet.com/*/blank.gif?**
PASS http://(www*.|)info.gov.hk/cgi-bin/forms/count.cgi?**
PASS http://s1.thecounter.com/**
COUNTERJS http://(www*.|)addfreestats.com/cgi-bin/countnow.cgi?**
COUNTERHTML http://count0r.customize.org/count0r.php?**
COUNTERHTML http://okcounter.com/okcounter.html?id=**
AD http://counter.yadro.ru/logo?**
COUNTER http://counter.yadro.ru/hit?**
COUNTER http://e.ofuda.cc/disp/[0-9]**.gif
COUNTER http://mom.freelogs.com/counter/index.php?**
COUNTER http://top.novgorod.ru:81/**
COUNTER http://bar.hit-counter.udub.com/counter/index.php?**
COUNTER http://okcounter.com/okcounter.html?id=**
COUNTER http://a.xcounters.com/?*
COUNTER http://count.2ch.net/ct.php/*
COUNTER http://counters.freewebs.com/Members/Counters/counter.jsp?**
COUNTER http://counter.animehost.de/showhits.php?*&st=img*
COUNTER http://c*.gostats.com/gogi/count.pl?**
COUNTER http://webcounter.goweb.de/**
COUNTER http://webcounter.goweb.de:90/**
COUNTER http://sys.bool.co.il/cgi-bin/bu_counter.cgi?**
COUNTER http://(www*.|)counter4u.de/cgi-bin/counter4u/img_counter_fast.pl?**
COUNTER http://counter.mycomputer.com/c.count?**
COUNTER http://**/count?ID=**
COUNTER http://**/cgi/count?**
COUNTER http://(www*.|)geocities.com/cgi-bin/counter**
COUNTER http://tools.geocities.**/@geocounter
COUNTER http://**/counter.cgi?**
COUNTER http://**/cgi-bin/counter/odometer.pl?**
COUNTER http://*/hit.counter?**
COUNTER http://*/nfcounter?**
COUNTER http://*.thecounter.com/id=**
COUNTER http://**/fpcount.exe**
COUNTER http://**/Count.exe?**
COUNTER http://*/cgi-bin/counter?**
COUNTER http://*/cgi-bin/count?**
COUNTER http://**/tb2count.fcgi**
COUNTER http://**/pqcount.fcgi**
COUNTER http://**/count.cgi?**
COUNTER http://**/Count.cgi**
COUNTER http://*/cgi-bin/SmartCounter?**
COUNTER http://*.xoom.*/*/counter.gif**
COUNTER http://*/counter?**
COUNTER http://counter.*/?**
COUNTER http://www[0-9].pagecount.com/*/counter.gif?**
COUNTER http://work.goen.ne.jp/counter*/fs/count?**
COUNTER http://top.list.ru/counter?**
COUNTER http://counter.rambler.ru/top100.cnt?**
COUNTER http://**/top100/nph-top100?A=**
COUNTER http://www[0-9].pagecount.com/images/xoom_counter_logo_basic.gif
COUNTER http://counter[0-9]*.com/c*/id/**
COUNTER http://c[0-9].*counter.com/c*/id/**
COUNTER http://hardware.pagecount.com/hardware/counter.gif?**
COUNTER http://fastcounter.linkexchange.com/digits?**
COUNTER http://fastcounter.bcentral.com/digits?**
COUNTER http://fastcounter.linkexchange.com/fastcounter?**
COUNTER http://fastcounter.bcentral.com/fastcounter?**
COUNTER http://**/counter.gif?**
COUNTER http://*.digits.com/wc/**
COUNTER http://*/cgi-bin/wc?**
COUNTER http://*/cgi-bin/wc/**
COUNTER http://counter[0-9].*/c**
COUNTER http://*/counters/*.gif
COUNTER http://*counter.com/counter/**
COUNTER http://fakecounter.com/[0-9]*.gif
COUNTER http://fakecounter.com/home.page?**
COUNTER http://*/cgi-bin/newcount?**
COUNTER http://*/cgi-bin/c2countit/c2countit.cgi?*
COUNTER http://*/cgi-bin/imagecounter?**
COUNTER http://**/counter.exe?**
COUNTER http://**/counter.gif
COUNTER http://*/cgi-bin/hits/hitmat.cgi?**
COUNTER http://**/Geo-counter.gif?**
COUNTER http://book.pagecount.com/book/counter.gif?*
COUNTER http://**/wwwcount.cgi?**
COUNTER http://(www*.|)mirc.to/public/counter?*
COUNTER http://(www*.|)whatsis.com/whatsis-bin/swc?**
COUNTER http://bilbo.counted.com/[0-9]**
COUNTER http://(www*.|)yandex.ru/cycounter?**
COUNTER http://u[0-9]*.spylog.com/cnt?**
COUNTER http://(www*.|)compteur.com/cgi-bin/compteur.cpt?**
COUNTER http://(www*.|)imingo.com/services/compteur/icptgr.php?**
COUNTER http://(www*.|)perl-gratuit.com/cgi-bin/count/compteur?**
COUNTER http://(www*.|)addfreecounter.com/cgi-bin/cptconnect.cgi?**
COUNTER http://**/HitCounter.dll?**
COUNTER http://210.239.47.44/~inosuke/count/dream.cgi?id=*
COUNTER http://(www*.|)deadline.demon.co.uk/cgi-bin/count
COUNTER http://(www*.|)webd.org/fr/services/compteur/counter.asp?id=**
COUNTER http://**/nph-count(|.cgi)?**
COUNTER http://*.hypercount.com*/**/?**
COUNTER http://loga.hit-parade.com/logo*.gif**
COUNTER http://log*.xiti.com/hit.xiti?**
AD http://img.hypercount.com/*.jpg
AD http://escati.linkopp.net/logos/counter2000.gif
WEBBUG http://cs.sexcounter.com/cs/?**
COUNTERJS http://*.sitemeter.com/js/counter.js?**
COUNTER http://*.sitemeter.com/meter.asp?**
COUNTER http://escati.linkopp.net/cgi-bin/counter2000.cgi?**
COUNTER http://(www*.|)peakpeak.com/cgi-bin/counter/counter.pl?**
COUNTER http://portal.plocman.pl/top100/cgi-bin/stat.cgi?**
COUNTER http://**/hitometer.cgi
COUNTER http://gratiscounter.de/hit.cgi?**
COUNTER http://statse.webtrendslive.com/**button*.asp**
COUNTER http://counter*.sextracker.com/**
COUNTER http://*.sextracker.com/stx/send/**
COUNTER http://count.paycounter.com/?fn=0**
COUNTER http://web.ukonline.co.uk/public-cgi/wcount/**
COUNTER http://counter.hitslink.com/counter.asp?**
COUNTER http://counter.hitslink.com/counterupdate.asp?**
COUNTER http://*/cgi-bin/cnt.cgi?**
COUNTER http://counters.honesty.com/cgi-bin/honesty-counter.cgi?**
COUNTER http://**/counter.img?**
COUNTER http://*/counter.php?**
COUNTER http://*/counter.php3?**
COUNTER http://(www*.|)apcupsd.org/cgi-bin/apcupsdCount.cgi?**
COUNTER http://c.sexcounter.com/counter.html?**
COUNTER http://c.sexcounter.com/cnt.html?**
COUNTER http://(www*.|)topwebmaster.de/modul-center.html?modul=counter&**
COUNTER http://(www*.|)alphalink.com.au/cgi-bin/Count2.cgi?**
COUNTER http://(www*.|)btinternet.com/cgi-bin/counter/**
COUNTER http://(www*.|)stomped.com/counter-bin/images/icompz-banner.gif?**
COUNTER http://((www*.|)web-chart.de|151.189.43.51)/cgi-bin/chart/webchart.cgi?**
COUNTER http://hit*.hotlog.ru/cgi-bin/hotlog/count?**
COUNTER http://(www*.|)top-chart.de/cgi/topchart2.cgi?**
COUNTER http://(www*.|)hitlogger.com/cgi-bin/nstats-bin/do/stats.cgi?**
AD http://(www*.|)hitlogger.com/nstats-web/banner.gif
COUNTERJS http://(www*.|)top-chart.de/code/code_tc4.js
COUNTERJS http://((www*.|)web-chart.de|151.189.43.51)/counter.js
PASS http://ads.vnuemedia.com/js.ng/Site=amusementbusiness&**
ADJS http://adserv.*/**.js
ADJS http://(www*.|)efront.com/adserve.jscript/**
ADJS http://(www*.|)geocities.com/js_source/pu5geo.js
ADJS http://(www*.|)geocities.com/js_source/ygNSLib9.js?*
ADJS http://**/js.ng/**
ADJS http://adproxy.whowhere.com/ad.cgi?*response_type=JS
ADJS http://(www*.|)teknosurf.com/text/*.js
ADJS http://layer-ads.de/**
ADJS http://*.intellitxt.com/intellitxt/front.asp?**
ADJS http://vpdc.ru4.com/aw.asp?**
# ADSWF http://vpdc.ru4.com/SWF/Window/AffiliateWindow/**.swf?**
ADSWF http://http.edge.vru4.com/smartserve/**.swf
AD http://*.ru4.com/content/images/**.(gif|jpg)
AD http://*.ru4.com/images/**.(gif|jpg)
ADHTML http://*.ru4.com/smartserve/ad?**
ADHTML http://(www*.|)danworld.net/cgi-pub/centralad/ssirand.cgi/**
ADHTML http://display.adhearus.com/display_ad.php?**
ADHTML http://*.pricegrabber.com/search_getprod_ad.php/**
ADHTML http://layer-ads.de/ad.php?**
ADHTML http://layer-ads.de/refer.php?**
ADHTML http://cp-co.kir.jp/banner/*/
AD http://dist.belnk.com/4/placement/**.jpg
ADJS http://webpdp.gator.com/4/placement/[0-9]*/
AD http://webpdp.gator.com/**.gif
AD http://**/centralad/**getimage**
AD http://(www*.|)edacafe.com/common/getimage.php?**
PASS http://home.netscape.com/affiliate/images/jump_*.gif
PASS http://(www*.|)ofoto.com/affiliates/**
PASS http://(www*.|)ebags-backpacks.com/affiliate/**
AD http://affiliate.plugnpay.com/*.gif
AD http://static.admaximize.com/gifs/**
AD http://adforce*.imgis.com/**
AD http://adforce*/?adserv**
AD http://(www*.|)efront.com/adserve.image/**
AD http://imageserv*.imgis.com/**
AD http://fp.cache.imgis.com/images/Ad*
AD http://(www*.|)sfgate.com/place-ads/**.gif
AD http://(www*.|)ad-up.com/cgi-bin/view.cgi/**
AD http://bizad.nikkeibp.co.jp/image/**.gif
AD http://(www*.|)nikkeibp.asiabiztech.com/image/Ad_*.gif
AD http://ads1.zdnet.com/adverts/**
AD http://*currents.net/ccigraph/vendors/*.gif
AD http://(www*.|)dgmaustralia.com/merchants/**.gif
AD http://headline.gamespot.com/rotations/graphics/*.gif
AD http://**/~web_ani/*.gif
AD http://static.wired.com/advertising/**
AD http://static.wired.com/advertising/*.gif
AD http://static.wired.com/news/images/button_ads_*.gif
AD http://(www*.|)motorcycle.com/mo/mcads/**.gif
AD http://(www*.|)motorcycle.com/mo/mcads/**.jpg
AD http://(www*.|)motorcyclenews.com/global_graphics/bikemart.gif
AD http://(www*.|)motorcyclenews.com/global_graphics/duke_video.gif
AD http://(www*.|)motorcyclenews.com/global_graphics/on_sale_arrows.gif
AD http://(www*.|)motorcyclenews.com/global_graphics/fantasy_road_race.gif
AD http://(www*.|)motorcyclenews.com/global_graphics/sidelinks/mandp_button.gif
AD http://(www*.|)csmonitor.com/advertising/*.gif
AD http://(www*.|)currents.net/ccigraph/vendors/*.gif
AD http://(www*.|)dvdresource.com/images/*banner*.gif
AD http://(www*.|)ednprodmag.com/images/prbanner/*.GIF
AD http://(www*.|)latimes.com/ADS/*.gif
AD http://(www*.|)mcafee.com/banners/*.gif
AD http://(www*.|)dvdtown.com/gfx/banners/*.gif
AD http://(www*.|)askdigitalman.com/gfx/*banner.gif
AD http://banner.orb.net/ORBitBanner/*/banner.gif?**.10.21.22.15.10
AD http://(www*.|)mediacity.com.sg/cgi-bin/adopt/place_ad_cookie?**
AD http://(www*.|)ohio.com/advertising/*.gif
AD http://image.pathfinder.com/shared/images/ad/*.gif
AD http://image.pathfinder.com/shared/images/marketing/*.gif
AD http://a.mktw.net/MarketWatch/**.gif
AD http://images.people2people.com/images/marketing/**.gif
AD http://marketing.nyi.net/**.gif
AD http://image.pathfinder.com/sponsors*/**.gif
AD http://(www*.|)smartclicks.com:81/**/smartimg
AD http://(www*.|)sofcom.com.au/cgi-bin/Banner/Show.cgi?function=pic**
AD http://(www*.|)submit-it.com/images/animbanner_*.gif
PASS http://(www*.|)storedj.com.au/images/anim*.gif
PASS http://sfx-images.mozilla.org/affiliates/**
AD http://**/anim[0-9].gif
AD http://**/anim[0-9][0-9].gif
AD http://**/animban*.gif
AD http://**/aniban*.gif
AD http://**/anim_btn*.gif
AD http://(www*.|)wallpapervault.com/btn*.gif
AD http://(www*.|)thestar.com/**/ad/**.gif
AD http://(www*.|)thestar.com/thestar/images7/*_ani.gif
AD http://(www*.|)tradingpost.com.au/gfx/advt/*.gif
AD http://(www*.|)uexpress.com/comics_channel/images/IE4_ANIMATED.gif
AD http://(www*.|)superstats.com/images/ss.gif
AD http://(www*.|)cashcount.com/cgi-bin/hits/log.cgi?**
AD http://(www*.|)geocities.com/MemberBanners/live/*.gif
AD http://pic.geocities.com/images/mbe/mbe*.gif
AD http://pagesthatpay.geocities.com/thumbnails/*.gif
AD http://(www*.|)geocities.com/sponsor/*.gif
AD http://(www*.|)geocities.com/cgi-bin-local/GeoAD?**
AD http://(www*.|)village.com.au:1971/*?**
AD http://(www*.|)upside.com:8001/*?**
AD http://(www*.|)phillynews.com/advts/images/*.gif
AD http://ad.gamespot.com/rotations/graphics/*.gif
AD http://ad.gamespot.com/rotations/graphics/*.gif
AD http://(www*.|)thewebsubmitter.com/wsbanner3
AD http://(www*.|)topcenter.com/*.gif
AD http://images.yahoo.com/a/eg/egghead/*.gif
AD http://(www*.|)sofcom.com.au/cgi-bin/banserv/s?**
AD http://(www*.|)excite.com/img/art4/home/promo/*.gif
AD http://**/getimage.cgi**
AD http://**/getimage.exe/*?**
AD http://*/banmat/*.jpg
AD http://**/[Aa]ffiliates/**.gif
AD http://**/(affiliate|affilies)/**.gif
AD http://images.ifriends.net/affiliate_programs/**.GIF
AD http://www5.zdnet.com/graphics/pcast.gif
AD http://(www*.|)zdnet.com/zdtv/graphics/library/*.gif
AD http://208.156.39.144:80/*?
AD http://img.getstats.com/?**
AD http://**/ads/ad.pl?**
AD http://(www*.|)LinkAustralia.com/cgi-localbin/ads.pl?**
AD http://bs7.gsanet.com/gsa_bs/gsa_bs.cmdl?**
AD http://(www*.|)sun.com/sunworldonline/swol-ad/**
AD http://(www*.|)digitaleyes.net/images/Banner*.gif
AD http://banner.rootsweb.com/cgi-bin/newbanner.cgi?**
AD http://bannerbrokers.com/cgi-bin/banner.cgi?**
AD http://bannermaster.geektech.com/**.gif
AD http://206.132.234.218/**.gif
AD http://(www*.|)activeie.com/images/ukchat2.jpg
AD http://(www*.|)chipcom.net/*ad.gif
AD http://(www*.|)elibrary.com/advertising/*/*.gif
AD http://www3.switchboard.com/home/disspbox.gif
AD http://www3.switchboard.com/images/disbar.gif
AD http://www3.switchboard.com/images/ebay54.gif
AD http://www3.switchboard.com/images/coupon.gif
AD http://(www*.|)gottsoftware.com/CGI/mln_nonssi.pl?**
AD http://(www*.|)speed-links.com/cgi-local/adssl.pl?**
AD http://(www*.|)hostamerica.com/images/ha_banner*.gif
AD http://echo.znet.de/banner/factumbanner.gif
AD http://(www*.|)bannerweb.com/click/**
AD http://(www*.|)vrserv.com/clicktrade/*.gif
AD http://(www*.|)ml.org/gfx/spon/*/*.gif
AD http://(www*.|)twice.com/rvanim.gif
AD http://(www*.|)twice.com/hbobanne.gif
AD http://(www*.|)abc.net.au/news/graphics/the_dial.gif
AD http://(www*.|)newscientist.com/houseads/*.gif
AD http://(www*.|)dvdresource.com/images/adventure1.gif
AD http://image1.narrative.com/internet/*.gif
AD http://(www*.|)slugburger.com/ThAlley/Graphics/banner*.gif
AD http://(www*.|)puretec.de/gifs/sieben1.gif
AD http://(www*.|)dansdata.com/images/*banner*.gif
AD http://(www*.|)dansdata.com/images/fo32.gif
AD http://www.dansdata.com/images/dotnet3.gif
AD http://dansdata.com/images/*banner.gif
AD http://(www*.|)dansdata.com/images/tsurf.GIF
AD http://(www*.|)dansdata.com/images/referral1.gif
AD http://(www*.|)dansdata.com/images/apple.gif
AD http://(www*.|)dansdata.com/images/sb1.gif
AD http://(www*.|)dansdata.com/images/cg_400.gif
AD http://(www*.|)mamma.com/feature*.gif
AD http://(www*.|)dvd.com/stories/splash_page/pic_*.gif
AD http://(www*.|)floridatoday.com/*/ad/*.gif
AD http://(www*.|)nypostonline.com/images/p6teaser/*.gif
AD http://(www*.|)eweek.com/dropdown/*.jpg
AD http://bs[0-9]*.gmx.net/[0-9]**
AD http://**/advertisers/*.gif
PASS http://*.yimg.com**/a/i/**/twip/yahoo_twip*.swf
ADSWF http://**/advertise(|r(|s))/**.swf**
ADSWF http://temp.customize.org/*.swf
ADSWF http://(www*.|)gamespy.com/aspcommon/120x38/arcade_120x38.swf
ADSWF http://*.yimg.com**/(a|ads*)/**.swf**
ADSWF http://*.yimg.com**/a/**.swf**
ADSWF http://*extremetech.*/dropdown/**.swf?**
ADJS http://*extremetech.*/dropdown/**.js
ADJS http://www*.gmx.net/de/ad/*banner*.js
ADJS http://adimp.excite.co.jp/bservers/**
AD http://(www*.|)altavista.com/av/gifs/ie_horiz.gif
AD http://guide-p.infoseek.com/images/promo/*.gif
AD http://(www*.|)infoseek.com/rimage?**
AD http://infoseek.go.com/cimages?*Promo*
AD http://images.usatoday.com/shop/_images/**.gif
AD http://(www*.|)usatoday.com/marketpl/**.gif
AD http://(www*.|)usatoday.com/library/commerce/img/*.gif
AD http://(www*.|)usatoday.com/gen/wtg/img/*.gif
AD http://(www*.|)usatoday.com/20[0-9][0-9]/enterprise/*_468*.gif
WEBBUG http://images.usatoday.com/**/clear.gif**
WEBBUG http://images.clickability.com/**/spacer.gif**
WEBBUGJS http://www.usatoday.com/_common/_scripts/counter.js
ADPOPUP http://(www*.|)usatoday.com/advertising/orbitz/orbitz-window*.htm
ADPOPUP http://*actionsplash.com/PC1.asp?**
ADPOPUP http://*actionsplash.com/JR90.asp?**
ADPOPUP http://(www*.|)focalex.com/pops/popup_internet.emp?**
ADPOPUP http://jumpeu.altavista.com/popups/**
AD http://adaver1.altavista.yellowpages.com.au*/ad_image;**
AD http://(www*.|)yellowpages.com.au/yp/images/ll/*.gif
AD http://(www*.|)yellowpages.com.au/yp/images/yp_gettoit.gif
PASS http://linuxtoday.com/pics/lt.gif
PASS http://*.linuxtoday.com/pics/lt.gif
PASS http://linuxtoday.com/pics/lt.jpg
PASS http://linuxtoday.com/pics/new.jpg
PASS http://linuxtoday.com/pics/icom-linmicro.jpg
PASS http://linuxtoday.com/pics/logo-mini.gif
AD http://linuxtoday.com/pics/*.gif
AD http://linuxtoday.com/pics/*.jpg
AD http://linuxtoday.com/ltbs/pics/*.gif
AD http://linuxtoday.com/ltbs/pics/*.GIF
AD http://*.linuxtoday.com/pics/*.gif
AD http://(www*.|)linux-directory.com/button_88x31.gif
AD http://(www*.|)amasuperbike.com/image/ad_*.gif
AD http://(www*.|)amasuperbike.com/image/new/ad_*.gif
AD http://(www*.|)amasuperbike.com/r1.gif
AD http://(www*.|)amasuperbike.com/GSXR750.gif
AD http://(www*.|)amasuperbike.com/tbrc51.gif
AD http://(www*.|)amasuperbike.com/*banner*.gif
AD http://(www*.|)amasuperbike.com/dunlop.jpg
AD http://(www*.|)amasuperbike.com/parts.jpg
AD http://(www*.|)amasuperbike.com/agv2.gif
AD http://(www*.|)amasuperbike.com/muzzyanim.gif
AD http://(www*.|)amasuperbike.com/vr1000.gif
AD http://(www*.|)amasuperbike.com/hondaanim.gif
AD http://(www*.|)amasuperbike.com/image/vnh.gif
AD http://(www*.|)amasuperbike.com/super.gif
AD http://www*.burstnet.com/gifs/*X*.gif
AD http://(www*.|)flatoday.com/space/today/resume.gif
AD http://(www*.|)flatoday.com/**ad-*.gif
AD http://(www*.|)flatoday.com/space/today/pr-*.gif
AD http://(www*.|)flatoday.com/space/resume.gif
AD http://(www*.|)ohms.com/toolbar.gif
AD http://(www*.|)ohms.com/jmpbanner.gif
AD http://(www*.|)34u.com/images/34ubanner.gif
AD http://(www*.|)themez.com/mini-cg1.gif
AD http://(www*.|)independent.co.uk/-images/buttons/*_*x*.(gif|jpg)
AD http://(www*.|)independent.co.uk/img/commercial/**.(gif|jpg)
ADSWF http://(www*.|)independent.co.uk/images/flash/**.swf
ADSWF http://(www*.|)heise.de/RealMedia/ads/**.swf**
ADHTML http://(www*.|)hit-now.com/b*.php**
AD http://(www*.|)dslvalley.com/images/pub/*/*x*.gif
ADHTML http://(www*.|)dslvalley.com/pub/pub.php?mode=view**
ADHTML http://ads.tripod.lycos.co.uk/ad/*/frame.php?**
ADHTML http://ads.treehugger.com/iframe/th_rightcol.php
ADJS http://*.hitbox.com/js/hbf.js
ADJS http://*.hitbox.com/js?**
WEBBUG http://heise.ivwbox.de/cgi-bin/ivw/CP/newstick_mm;**
WEBBUG http://ehg-dig.hitbox.com/HG?**
COUNTER http://hg1.hitbox.com/HG?**
COUNTER http://aibg.hitbox.com/ace?**
COUNTER http://ias.hitbox.com/**
AD http://stats.hitbox.com/buttons/*.gif
AD http://w[0-9]*.hitbox.com/Hitbox?**
AD http://w[0-9]*.hitbox.com/*.gif
AD http://w[0-9]*.hitbox.com/wc/C*.cgi
AD http://w[0-9]*.hitbox.com/wa/W44103822.cgi
AD http://ias.hitbox.com/*.gif
AD http://ibg.hitbox.com/ace?id=*
AD http://(www*.|)downloadx.com/wallpaper/ad*.gif
AD http://(www*.|)12c4.com/a/*.gif
AD http://adcreatives.imaginemedia.com/MPCN/**.gif
PASS http://g.deja.com/gifs/20x20.gif
PASS http://g.deja.com/gifs/*_x*.gif
PASS http://g.deja.com/gifs/1x1_*.gif
PASS http://g.deja.com/gifs/nextart2.gif
PASS http://g.deja.com/gifs/next_*.gif
PASS http://g.deja.com/gifs/*arrow*.gif
AD http://g.deja.com/gifs/*x*.gif
AD http://w1.dejanews.com/gifs/*.gif
AD http://*.joboptions.com/jo_deja/img/ad_banners/*.gif
AD http://207.87.22.200/content/**.gif**
AD http://(www*.|)x.org/images/banner_*.gif
AD http://(www*.|)wholesaledirect.com.au/images/banner_*.gif
AD http://(www*.|)mcpmag.com/images/ban_*.gif
AD http://*lokau.com.br/images/ban_**
AD http://*banner.inside.com.br/Banner/**
AD http://(www*.|)inside.com/img/memberarea_anonymous2.gif
AD http://(www*.|)inside.com/img/button_*_140.gif
AD http://200.212.87.26/images_capa/**
AD http://(www*.|)wincvs.org/osbanner.gif
AD http://(www*.|)wincvs.org/lw1.gif
AD http://focus.de/GLOBPICS/**.gif
AD http://(www*.|)osopinion.com/art/maxpcn*.gif
AD http://(www*.|)maccentral.com/static/*.gif
AD http://(www*.|)dilbert.com/comics/dilbert/images/*_banner_*gif
AD http://(www*.|)dilbert.com/comics/dilbert/images/*_anim.gif
AD http://(www*.|)dilbert.com/comics/dilbert/images/*_ani.gif
AD http://(www*.|)perlmonth.com/images/barnesandnoble1.gif
AD http://(www*.|)perlmonth.com/images/hv1banner.gif
AD http://(www*.|)silicon.com/image/inform_*.gif
AD http://(www*.|)silicon.com/image/mind_exp_jd.gif
AD http://(www*.|)silicon.com/image/*_ban.gif
AD http://banner.ft.com/banner/*
AD http://explorezone.com/graphics/associates/*.gif
AD http://explorezone.com/graphics/buttons/*.gif
AD http://(www*.|)sol.dk/img/partner/*.gif
AD http://(www*.|)sol.dk/it/newgraphics/banner_ie5.gif
AD http://images.cnn.com/SHOP/partners/**/images/*,gif
AD http://(www*.|)cnn.com/images/9903/barnesstory.gif
AD http://banners.imfc.com/?**
AD http://(www*.|)projo.com/words/images/words.gif
AD http://(www*.|)qsound.com/trackes/*.gif
AD http://images.fogdog.com/toolkit/images/*_*x*.gif
AD http://(www*.|)egghead.com/media/bnr/*.gif
AD http://(www*.|)email-it.net.au/MS_AUS.gif
AD http://(www*.|)hostonfly.com/*/ban/*.gif
AD http://(www*.|)pixunlimited.co.uk/sys-images/Network/Front/Merchandising/**.gif
AD http://(www*.|)amazon.com/g/associates/**.gif
AD http://rcm-images.amazon.com/images/**/associates/**.gif
AD http://(www*.|)amazon.com/**/roto-ads/*.gif
AD http://(www*.|)washingtonpost.com/wp-adv/advertisers/style/images/*.gif
WEBBUG http://rsi.washingtonpost.com/F**.gif?**
ADPOPUP http://(www*.|)washingtonpost.com/wp-srv/popjs/**.htm
ADJS http://(www*.|)washingtonpost.com/wp-srv/javascript/common/promoad.js
ADJS http://(www*.|)canoe.ca/MoneyIncludesDesign/promo_money.js
PASS http://(www*.|)canoe.(com|ca)/(CanoeGlobalnav|CNEWS*Images|MoneyDesign)/*.gif
AD http://(www*.|)canoe.(com|ca)/AdsCanoe/**
AD http://*ads*.canoe.(com|ca)/**.(gif|jpg)
AD http://*ads*.canoe.(com|ca)/event.ng/**
AD http://*.arena.ne.jp/ba/*.gif
AD http://(www*.|)clickz.com/clickz.images/*/*[0-9]x[0-9]*.gif
AD http://8ball.federated.com/*_banner.gif
# AD http://invis*.free.anonymizer.com/http://**
AD http://(www*.|)altavista.com/av/content/images/*.gif
AD http://(www*.|)redhat.com/img/banner_*.gif
AD http://(www*.|)redhat.com/img/free_hat_offer3.gif
AD http://(www*.|)redhat.com/img/button_animation.gif
AD http://(www*.|)ht.com.au/images/bo.gif
AD http://(www*.|)javaworld.com/javaworld/icons-rd/h-store.gif
AD http://lwn.net/images/aspsys/*.gif
AD http://lwn.net/images/linuxtoday/lt_wow.gif
AD http://lwn.net/images/sonysweeps_header_2.gif
AD http://(www*.|)linuxnewbie.org/newbiead.gif
AD http://(www*.|)linux.org/graphic/(square|banner)/*.(gif|jpg)
AD http://(www*.|)provantage.com/AD_*.GIF
AD http://(www*.|)kbench.com/korean/index/*[0-9]_[0-9].gif
AD http://(www*.|)videoclips.freeserve.co.uk/amazon1.gif
AD http://(www*.|)videoclips.freeserve.co.uk/*banne*r*.(gif|jpg)
AD http://(www*.|)videoclips.freeserve.co.uk/*adban*.gif
AD http://www4.macnn.com/media/*.gif
AD http://(www*.|)dvdcity.com/graphics/dvdcity-2.gif
AD http://tsms-image.tsms.com/gifs/*
AD http://(www*.|)calendarexpress.com/CEBabes143x140.gif
AD http://(www*.|)brassmonkey.net/*.gif
AD http://*/sexswapicon.gif
AD http://(www*.|)sexclicks.org/*.gif
AD http://(www*.|)sexnation.net/graphics/*.gif
AD http://(www*.|)pcworld.com/shared/graphics/smartagebutton.gif
AD http://(www*.|)luckysurf.com/BeFree/pix/*.gif
AD http://(www*.|)smartage.com/cgi-bin/befreecookie.pl
AD http://(www*.|)smartage.com/cgi-bin/resell_cookie.pl
AD http://(www*.|)smartage.com/img/promote/media_buyer/*.gif
AD http://(www*.|)slaughterhouse.com/banner/*.gif
AD http://rc5.distributed.net/cgi-bin/banners.cgi
AD http://(www*.|)thefreesite.com/alabsss.gif
AD http://64.152.192.114/stuff_tc/mb_*x20.gif
AD http://(www*.|)snafu.de/~wehe/amzn-b2.gif
AD http://(www*.|)dav[0-9]*.vhm.de/wimages/*_banner_*.gif
AD http://(www*.|)newsweek.com/nw-srv/test/patek/ir_animation.gif
AD http://macintouch.com/images/*.gif
AD http://images.100free.com/*ban[0-9]*.jpg
AD http://add.buzina.com/*.gif
AD http://(www*.|)it-seek.com/cgi-scripts/ffsbantrack.pl?action=view
AD http://(www*.|)whowhere.lycos.com/images/ebay_bst.gif
AD http://(www*.|)whowhere.lycos.com/images/find_books.gif
AD http://(www*.|)whowhere.lycos.com/images/1800/w_letters2.gif
AD http://(www*.|)ms-links.com/cgi-bin/bi2.cgi?**
AD http://home.att.net/~swchoe/desktopani.gif
AD http://(www*.|)medhelp.org/images/differenceAB.gif
AD http://appwatch.com/images/geekbanner1.gif
AD http://appwatch.com/images/banner-*.gif
AD http://(www*.|)excite.com/img/wea/applet/shwpixls.gif
AD http://htmlwizards.com/button/*.gif
AD http://(www*.|)htmlwizards.com/button/*.gif
AD http://(www*.|)freestuffcenter.com/button.gif
AD http://(www*.|)freestuffcenter.com/thegovernmentban.gif
AD http://(www*.|)freestuffcenter.com/sub/buttons/*.gif
AD http://(www*.|)gifart.com/links/*.gif
AD http://(www*.|)gifart.com/buttons/*.gif
AD http://(www*.|)dnps.com/*/banner/*.gif
AD http://(www*.|)dnps.com/*_bans/*.gif
AD http://(www*.|)dnps.com/contests/*.gif
AD http://(www*.|)dnps.com/*banners/*.gif
AD http://(www*.|)dnps.com/edison/*.gif
AD http://(www*.|)dnps.com/netgravity/*.gif
AD http://(www*.|)dnps.com/hotcompanies/top.gif
AD http://(www*.|)dnps.com/classiccars/*.gif
AD http://(www*.|)dnps.com/emf/emf.gif
AD http://(www*.|)dnps.com/huntingtonbank/evenbetter[0-9]*.gif
AD http://(www*.|)dnps.com/internal/*468.gif
AD http://(www*.|)freep.com/grafix/dci_logo.gif
AD http://(www*.|)free-search.com/weeklycontests.gif
AD http://(www*.|)looroll.com/buttons/looroll_banner.gif
AD http://(www*.|)looroll.com/buttons/looroll_button.gif
AD http://(www*.|)looroll.com/buttons/telebutton.gif
AD http://(www*.|)looroll.com/buttons/skindepth_button.gif
AD http://209.58.17.9/workbanner.phtml?action=image**
AD http://(www*.|)indsoft.net/wallpapers/*.gif
AD http://(www*.|)autoworld.com/aig/newaiglogo.gif
AD http://(www*.|)tweak3d.net/images/partof.gif
AD http://z0.extreme-dm.com/i/**
AD http://206.161.225.50/digilogo/logo.cgi?**
AD http://216.27.61.205/dmimages/0441.gif
AD http://(www*.|)mplayer.com/graphics/ad_sales/**.gif
AD http://(www*.|)mplayer.com/graphics/home/defaultad.gif
AD http://(www*.|)quake3world.com/dfnbutton.gif
AD http://(www*.|)fastgraphics.com/logos/*.*
AD http://(www*.|)safe-audit.com/sites/*/*.gif
AD http://(www*.|)alpha-processor.com/images/nav/animtickerfw.gif
AD http://(www*.|)shades.com/v1_banner2a.gif
AD http://(www*.|)globeandmail.com/**_promo.gif
AD http://dev3.ny.thinkinc.com/*/*.sdpban/**.gif
AD http://(www*.|)register.com/images/usanetbanner.gif
AD http://208.178.169.7/nonstop/infinity-120x90.gif
AD http://(www*.|)luminanet.com/[a-z]*banner.gif
AD http://(www*.|)linuxstart.com/images/banner3.gif
AD http://(www*.|)hotthemes.com/images/top501.gif
AD http://(www*.|)hotthemes.com/images/*_affilliate_*.gif
AD http://(www*.|)hotthemes.com/wall/images/myshare_rd54.gif
AD http://(www*.|)hotthemes.com/wall/allbanners/*.gif
AD http://(www*.|)digitalblasphemy.com/graphics/webshots.gif
AD http://(www*.|)commission-junction.com/banners/tracker.exe?**
ADPOPUP http://(www*.|)commission-junction.com/track/track.dll?**
##ADPOPUP http://(www*.|)amazon.*/exec/obidos/tg/browse/**site-redirect**
ADPOPUP http://(www*.|)track4.com/*?**
AD http://(www*.|)icreditreport.com/graphics/2check32.gif
AD http://(www*.|)headhunter.net/images/Aff/*.gif**
AD http://(www*.|)theage.com.au/images/shoptoday.gif
AD http://(www*.|)blackdown.org/images/simplicity.gif
AD http://home.snap.com/main/images/contest/newyear/logos.gif
AD http://(www*.|)startribune.com/mcu/promotions/investorfactory/012000/ha1.gif
AD http://(www*.|)zserver.com/?SIT=**
AD http://banners.orbitcycle.com/router/**
AD http://(www*.|)esign.com.au/*_anim.gif
AD http://(www*.|)anthemrecords.com.au/Banner*.gif
AD http://(www*.|)unsound.com.au/webring/graphics/ozcdstoreslogo.gif
AD http://(www*.|)abe.com.au/cgi-bin/bi2.cgi?**
AD http://(www*.|)abe.com.au/banners/*.gif
AD http://(www*.|)sexplanets.com/banners/*.gif
AD http://technocrat.net/technocrat_net/Image/BannerAdvertising/**
AD http://(www*.|)tvguide.com/rbitmaps/*.gif
AD http://(www*.|)tvguide.com/images/*ad.gif
AD http://(www*.|)lendingtree.com/new/branch/images/2_home_banner.gif
AD http://(www*.|)estore.com.au/images/icons/*button*.gif
AD http://(www*.|)isyndicate.com/images/nav/bignight_468.gif
AD http://(www*.|)themeworld.com/images/*468.gif
AD http://(www*.|)isyndicate.com/images/nav2/anim_logos_new.gif
PASS http://www-*.cricket.org/logos/SUPPORT/HOSTS/components/**
PASS http://www-*.cricket.org/logos/spacer*.[Gg][Ii][Ff]
PASS http://www-*.cricket.org/logos/CI/cricinfo-news.gif
ADBG http://www-*.cricket.org/logos/**-background.gif
AD http://www-*.cricket.org/logos/**.[Gg][Ii][Ff]
AD http://www-*.cricket.org/adlib/server.cgi/**
AD http://**/apbanner*.gif
AD http://**/banner[0-9]*.gif
AD http://http.a.radix.intervu.net/smirror/alembke/rules/bannerimgs125/*.gif
AD http://*/htmlad/*.gif
AD http://(www*.|)adverline.com/cgi-bin/pvis?**
AD http://(www*.|)regieclick.com/pub.zarc?**
AD http://(www*.|)regieclick.com/pubs/[0-9]*.gif
AD http://(www*.|)cybergreetings.com/clipart/associat.gif
AD http://liquidad.narrowcastmedia.com/~wsapi/ncmapi/GIF**
AD http://wwjd.net/wwjd/php_lang.gif
AD http://(www*.|)wwjd.net/wwjd/phpAds/phpads.php*
AD http://(www*.|)paypal.com/images/paypalbanner.gif
AD http://(www*.|)leadinglight.net/banad-*.gif
AD http://privacy.net/_ads/*.gif
AD http://privacy.net/analyze/cool112.gif
AD http://privacy.net/images/eyes2.jpg
AD http://(www*.|)planetmirror.com/images/pmpromo.gif
AD http://(www*.|)planetmirror.com/images/playstation.gif
AD http://(www*.|)planetmirror.com/images/poweredge.gif
AD http://(www*.|)planetmirror.com/images/pmsearch.gif
AD http://comtrack.comclick.com/cgi-bin/aff_bandeau.cgi?**
AD http://bandeau.comclick.net/bandeaux/**
AD http://(www*.|)teletranslator.com:8080/images/pub.gif?**
AD http://mirror.qkimg.net/[0-9]*/[0-9]*.gif
AD http://comtrack.comclick.com/cgi-bin/aff_bandeau.cgi?**
AD http://logv9.xiti.com/hit.xiti?**
AD http://fx4.tgv.net/servlets/adjuggler?**ajtype=cgi_image**
AD http://(www*.|)techcentralstation.com/servlet/CMBinaryServer?cid=**
AD http://fl01.ct2.comclick.com/aff_url.ct2?*
ADJS http://fl01.ct2.comclick.com/aff_js_src.ct2?**
ADHTML http://fl01.ct2.comclick.com/aff_frame.ct2?**
ADHTML http://comtrack.comclick.com/cgi-bin/rq_frame_editeur.cgi?**
PASS http://shamanismweb.org/freak/images/glassblock.gif
PASS http://shamanismweb.org/freak/images/backmain.gif
PASS http://shamanismweb.org/freak/images/pd-*.gif
AD http://shamanismweb.org/freak/images/*.gif
AD http://shamanismweb.org/freak/pictures/webspace_small2.gif
BULLET http://*/anpnt.gif
BULLET http://**/pstmdrn/posbul1a.gif
NEW http://**/buttons/1new.gif
NEW http://*/news[0-9]*.gif
NEW http://*.yimg.com/images/new*.gif
NEW http://(www*.|)yanman.com/images/sign_sm_new.gif
NEW http://(www*.|)free-graphics.com/new.gif
PASS http://(www*.|)free-graphics.com/updated.gif
PASS http://(www*.|)free-graphics.com/arrow.gif
PASS http://(www*.|)free-graphics.com/navigation.gif
PASS http://*.aol.com/price_plans/**
PASS http://movies.channel.aol.com/**/trailer.adp
ADPOPUP http://*.aol.com/**.adp
ADPOPUP http://ads.admonitor.net/clicktrack.cgi?**
ADPOPUP http://(www*.|)aol.com/popups/*.html
ADPOPUP http://eshop.msn.com/categorypopup.aspx?**
ADPOPUP http://fdimages.fairfax.com.au/crtvs/*pop*.html
## stripping the ? seems to break their image cache service
##REWRITE (http://farm*.static.flickr.com/*/buddyicons/*.jpg)?[0-9]* 302:$1
ADHTML http://*xml.eshop.msn.com/xmlbuddy/eShopOffer.aspx?**
ADJSTEXT http://adsyndication.msn.com/delivery/getads.js
AD http://adsyndication.msn.com/delivery/**
AD http://*image.eshop.msn.com/img/merch/**.(gif|jpg)
AD http://*image.eshop.msn.com/img/sinv/**.jpg
AD http://*xml.eshop.msn.com/trackofferimpression.aspx?**
AD http://affiliate.aol.com/static/aan/images/*.gif
AD http://fdimages.fairfax.com.au/*/pop_*.gif
AD http://(www*.|)aol.com/popups/gr/aol_31.gif
AD http://res.sys-con.com/**Pop_Up.gif
AD http://res.sys-con.com/portlet/**.jpg
AD http://(www*.|)newaol.com/aolcreative/images/250hours/88x31bold.gif
AD http://members.aol.com/tennmax/hs_guide.gif
AD http://(www*.|)dse.com.au/isroot/DSE/images/*_banner.gif
AD http://(www*.|)dse.com.au/isroot/DSE/images/banner_*.gif
AD http://(www*.|)wric.com/ic_aol.gif
AD http://(www*.|)wric.com/cocbannr.jpg
AD http://(www*.|)free-graphics.com/*.gif
AD http://adcontent.gamespy.com/**.gif
AD http://adimages.gamespy.com/**.gif
AD http://ad.caramail.com/pub/*.gif
AD http://(www*.|)adverline.com/cgi-bin/pvis?**
AD http://(www*.|)channelseven.com/images/*_promo_*.gif
AD http://(www*.|)cash-for-clicks.de/nt-bin/show.exe?**
AD http://(www*.|)cashforclicks.com/**.gif
AD http://(www*.|)free-banners.com/images/hitslogo.gif
AD http://(www*.|)free-banners.com/images/banner-button.gif
AD http://(www*.|)free-banners.com/images/banner-button2.gif
AD http://(www*.|)free-banners.com/images/applynowcompress.gif
AD http://(www*.|)free-banners.com/images/casino2.gif
AD http://(www*.|)free-banners.com/images/alladvantage-logo.gif
AD http://(www*.|)riva3d.com/allad.gif
AD http://(www*.|)alladvantage.com/images/*.gif
AD http://(www*.|)eads.com/images/refbutton.gif
AD http://(www*.|)jackpot.com/images/hb3.gif
AD http://(www*.|)dcypher.net/images/buttons/anibut.gif
AD http://(www*.|)netmonger.net/~chiptech/jc/pc/gfx/logobutton.jpg
AD http://(www*.|)bostonherald.com/**/images/*[0-9]x[0-9]*.gif
AD http://(www*.|)everythinglinux.com.au/images/ads/**
AD http://everythinglinux.com.au/images/ads/**
#PASS http://(www*.|)ibuypower.com/images/ibuypower-logo.gif
#PASS http://(www*.|)ibuypower.com/images/title-*.gif
AD http://(www*.|)ibuypower.com/images/ad-*.gif
AD http://(www*.|)ibuypower.com/images/logo*.gif
AD http://(www*.|)ibuypower.com/images/netscape.gif
AD http://(www*.|)ibuypower.com/images/ie.gif
AD http://(www*.|)ibuypower.com/images/dialpad_launch.gif
AD http://(www*.|)bonus.com/applets/ecards/mday/image/html/ani*.gif
AD http://(www*.|)linuxmall.com/Images/gotlx1.gif
AD http://bagel.openvista.com/images/cooltunes.gif
AD http://(www*.|)starbuzz.net/starbuzzsite.gif
AD http://(www*.|)pokertraffic.com/cgi-bin/hit.cgi?**
AD http://(www*.|)pokertraffic.com/images/*.gif**
AD http://(www*.|)guide2poker.com/images/*.gif
AD http://(www*.|)trafficoverdrive.com/bpwork2.pl?ID=*
AD http://(www*.|)trafficoverdrive.com/*.gif
AD http://*/TrafficCash/*.gif
AD http://*/TrafficCash/*.jpg
AD http://(www*.|)idirective.com/graphics/banner*.gif
ADHTML http://(www*.|)clickheretofind.com/parse.php3?**
AD http://(www*.|)clickheretofind.com/**.(gif|jpg)
AD http://(www*.|)jackpot.com/images/hb2.gif
AD http://(www*.|)ocworkbench.com/archives/mar2000/content/index.1.gif
AD http://lygo.com/ly/a/h/aff_hotbotlogo.gif
AD http://developer.netscape.com/images/apple.gif
AD http://(www*.|)penguincomputing.com/graphics/squarepc.gif
AD http://(www*.|)linuxquake.com/gif/buttons/lgdc-button.gif
AD http://(www*.|)lightningfree.com/**/buttons/*.gif
AD http://(www*.|)lightningfree.com/images/PhonePics/*.gif
AD http://(www*.|)lightningfree.com/**/*ban[0-9]*.gif
AD http://(www*.|)rdjd.net/banner1/banner1.jpg
AD http://slate.msn.com/articleimages/Drugstore_120x240cprtn_st53381.gif
AD http://slate.msn.com/animated_highlight_tm_free_.gif
AD http://(www*.|)spedia.net/imgs/spb.gif
AD http://(www*.|)uol.com.br/anuncio/goto/*.gif
AD http://*iconet.com.br/banners_front/**
AD http://*iconet.com.br/banners/**
AD http://*valevirtual.com.br/anuncio/**
AD http://*uol.com.br/anuncio/**
AD http://*bol.com.br/adlogbot**
AD http://(www*.|)christianet.com/*/btn_*.gif
AD http://(www*.|)penny-arcade.com/img/rspy.gif
AD http://allhw.com/images/netkills.gif
AD http://realbeer.com/rbi/images/banners/*.gif
AD http://(*.|)bluestreak.com/images/animated.gif
AD http://(*.|)bluestreak.com/ix.e?**
AD http://(*.|)bluestreak.com/adv/**.jpg
ADSWF http://ads.snowball.com/advertisers/**.swf**
ADSWF http://**/(adv|advertisements)/**.swf**
ADSWF http://realbeer.com/rbi/images/banners/*.swf
ADSWF http://(www*.|)tek-tips.com/images/tekattention.swf
ADSWF http://arstechnica.com/includes/tcmtile.swf
ADSWF http://images.anandtech.com/banners/**.swf
ADSWF http://(www*.|)porno-mania.net/a*.swf
ADSWF http://(www*.|)drinkinghard.com/*.swf?**
AD http://arstechnica.com/includes/ars-ad.gif
AD http://(www*.|)qksrv.net/image-**
PASS http://(www*.|)wist.uni-linz.ac.at/~didi/u2/images/jt_green1.gif
AD http://(www*.|)wist.uni-linz.ac.at/~didi/u2/images/*.gif
AD http://u2fanclub.org/cgi-bin/exchange/bpwork.cgi?**
AD http://(www*.|)megaspider.com/megaspider.gif
AD http://208.49.239.150/serv/**
AD http://216.65.106.2/*.gif
AD http://(www*.|)appleinsider.com/images/apple_design.gif
AD http://(www*.|)macosrumors.com/capitalism/*.gif
AD http://(www*.|)wfsdirect.com/graphics/winfreestuff*.gif
AD http://**/newban1.gif
AD http://(www*.|)tourbar.com/*.gif
AD http://**/ban.php?**
AD http://count.ru/cnt?id=**
AD http://(www*.|)one.ru/cgi-bin/cnt.cgi?id=**
AD http://bans.bride.ru/getb?*
AD http://**/pornotallica.gif
AD http://**/porntallica.gif
AD http://**/porntallicabutton.gif
AD http://**/uhohnet*.gif
AD http://**/rawlinks.gif
AD http://**/hioctane.gif
AD http://**/buttons/test08.gif
AD http://**/virtuagirl.gif
AD http://**/vgirl*.gif
AD http://(www*.|)freexlinks.com/images/freexlinksbutton.gif
AD http://networxxx.com/topnic.gif
AD http://static.stileproject.com/forum/link/link/l5.gif
AD http://graphics*.sextracker.com/**.gif
AD http://*.banners.sextracker.com/cids/**.gif
AD http://hestia.sextrail.trakkerd.net/**
PASS http://*.ads.**.html
PASS http://*.ads.**.js
ADPOPUP http://ads.world-free.net/adclick.cgi?**
ADPOPUP http://ads.inet1.com/html-bin/Popup-Auto.asp?**
ADHTML http://(www*.|)click4pic.com/f[0-9]*.html
ADHTML http://adserv.exxxit.com/cgi-bin/roidirect.cgi?**
ADHTML http://sbinternational.igallery.net/cgi-bin/bnd.cgi/**
ADJS http://*/jnserver/**
ADJS http://hit*.vioclicks.com/s3.asp?**
ADJS http://ad.erotik-click.de/myad_show.php*?**
ADJS http://(www*.|)porntrack.com/sexblocks/*.phtml?**
ADJS http://ads*.erotism.com/adults.js
ADJS http://js.peepfinder.com/**.js
ADJS http://(www*.|)cash2002.de/cgi-bin/cash_x.cgi?**
ADJS http://(www*.|)babebusters.com/clickzs.js
ADJS http://*.clickzs.com/**.js
ADJS http://*.clickhype.com/servlet/view/banner/javascript/zone?**
ADJS http://adcontroller.unicast.com/java**/wrapper.js
ADJS http://adcontroller.unicast.com/java/HTMLad_utils/ad2applet.js
ADHTML http://adcontroller.unicast.com/upload/**.html
# this is actually a Java file - maybe I should leave it alone
AD http://adcontroller.unicast.com/java/classes/adcontroller.jar
ADSWF http://adcontroller.unicast.com/upload/**.swf
ADSWF http://generator.zdnet.com/dell/dellbanner*.swt**
ADSWF http://(www*.|)forcevideo.com.au/force.swf
ADSWF http://se.fs.mgon.com/flashmovies/mgochannel*.swf
ADSWF http://(www*.|)fileplanet.com/gauge_accurate.swf
ADSWF http://(www*.|)babebusters.com/logo.swf
AD http://b.porncity.net/pctop/*.gif
AD http://*.porntrack.com/**
AD http://(www*.|)(boobweb.net|kinghost.com)/ban/**
AD http://bancol.babenet.com/logo.gif?**
AD http://**/bantgp*/*.gif
AD http://(www*.|)freesexspace.com/max*.gif
AD http://(www*.|)sex-mission.com/users/**/buttons/*.(gif|jpg)
AD http://(www*.|)penispill.com/**.gif
AD http://(www*.|)sugarcandys.com/files/bans/**.(gif|jpg)
AD http://(www*.|)pioneerlocal.com/graphics/badges/*
ADJS http://a8-lib.a8ww.net/scripts/sac.js
ADPOPUP http://*.mail.com/**/common/us/(ad_behind|banner_*_logout).htm*
ADPOPUP http://**/AffiliateConsoles/**.(asp|htm)**
ADPOPUP http://sex.globalporn.net/cali/console*.htm
ADPOPUP http://**/exitconsole*.cfm
ADPOPUP http://**/enter_console.php?**
ADPOPUP http://*.telia.com/*/console.html
ADPOPUP http://(www.|)shorturl.com/console.html?**
ADPOPUP http://(www*.|)weeklywallpaper.com/console*.html
ADPOPUP http://(www*.|)glamours.com/console**exit*.html
ADPOPUP http://*.issexy.tv/**popup*.html
ADPOPUP http://(www*.|)boneprone.com/shhh.html
ADPOPUP http://spunkysheets.com/console*.htm
ADPOPUP http://(www*.|)superchicken.com/privacy.html
ADPOPUP http://**/banners/icadverts/directnic/adult_java.html
ADPOPUP http://(www*.|)pantyfantasies.com/verify-nopop.htm
ADPOPUP http://*.need4xxx.net/freepop.html
ADPOPUP http://www.welcometofree.com/ban/ncc.txt
ADPOPUP http://www.welcometofree.com/exit.php3
ADPOPUP http://cgi.gammae.com/go.cgi?**
ADPOPUP http://(www*.|)elitecities.com/free-paysite-access/free-xxx-passwords.html
ADPOPUP http://(www*.|)bigtitfantasy.com/*_pop.html
ADPOPUP http://(www*.|)popadult.com/*.htm
ADPOPUP http://(www*.|)pioneerlocal.com/house/nssubscribe/ns-subscribe-pop.html
ADPOPUP http://webpdp.gator.com/v3/webpdp_v3_detect.php?**
PASS http://(www*.|)help-site.com/gif/blank.gif
PASS http://(www*.|)help-site.com/gif/hs*.gif
PASS http://(www*.|)help-site.com/gif/l_*.gif
AD http://(www*.|)help-site.com/gif/*.gif
PASS http://(www*.|)usdefense.com/images/pgdvder.gif
AD http://(www*.|)usdefense.com/images/*.gif
PASS http://www71.pair.com/compsw/firesite/wd2856/wf110.gif
AD http://www71.pair.com/compsw/firesite/wd2856/wf[0-9][0-9][0-9].gif
PASS http://www71.pair.com/compsw/firesite/wd2856/wf*.gif
PASS http://www71.pair.com/compsw/firesite/wd2833/wf*.gif
AD http://www*.pair.com/compsw/firesite/wd*/wf*.gif
AD http://(www*.|)88888.com/images/oneandonly/rules.gif
AD http://www2.idg.com.au/cwsites/mycw/my_computerworld.gif
AD http://(www*.|)olympics.com/eng/images/*logo*.gif
AD http://(www*.|)olympics.com/eng/images/*promo*.gif
AD http://(www*.|)backupcentral.com/images/banner.gif
AD http://(www*.|)themestream.com/gspd_browse/browse/view_image.gif?com_id=*
AD http://static.gfx.streamate.com/thumb/**
AD http://(www*.|)cwcom.net/ntlworld/images/*.gif
AD http://(www*.|)ntlworld.com/images/promos/*.gif
AD http://www.sanity.com.au/promos/**.gif
AD http://graphic.recommend-it.com/bigbut5mint.gif
AD http://(www*.|)twistedhumor.com/buttons/addr1.gif
AD http://(www*.|)expressindia.com/newads/*.gif
AD http://(www*.|)internet.com/_housebanners/**.gif
AD http://worldwideadultdomains.org/**/mouse.gif
AD http://rstrip.namezero.com/navbar/strip.jsp?**
AD http://turbo.ovh.net/cgi-bin/affiche.pl?**
AD http://comm.ovh.fr/cgi-bin/banniere.cgi?**
AD http://affilies.ibazar.fr/image.phtml?**
AD http://(www*.|)macbidouille.com/ads/**
AD http://(www*.|)macplus.org/cgi-bin/echange/echange.cgi?**
AD http://www.blackorange.com/blackorange/assets/product_images/**
AD http://pub.macgeneration.com/**
AD http://tracker.affistats.com/dirtag.php?**
AD http://(www*.|)regieclick.com/pub.php*?**
AD http://(www*.|)plemx.com/px.exe?**
AD http://(www*.|)techextreme.com/images/*banner.gif
AD http://taggin.com/ad/view.php*?**
AD http://nbe.net-on.net/bserve.cgi?**
AD http://naturalismedicina.com/cgibin/linswap/dis1?**
AD http://adtracking.net-on.net/sys/banner?**
AD http://(www*.|)tech-report.com/i/kagear.gif
AD http://probe.prohosting.com/show/**
AD http://(www*.|)dingoblue.com.au/images/bluesquare.gif
AD http://(www*.|)onelook.com/count/onesuite1.gif
AD http://english.peopledaily.com.cn/pict/ads.gif
AD http://(www*.|)theworldnews.com.au/axafront.gif
AD http://(www*.|)eng-slo.com/Images/pcmax*.gif
AD http://media.quinstreet.com/images/adt/adt_full_0001.gif
AD http://(www*.|)booksonline.com/bookclubs/images/partners/**.gif
AD http://(www*.|)eu.mtnsms.com/images/wildlife1.gif
AD http://adimages.go.com/ad/sponsors/**.gif
AD http://officequest.net/fq-adds/fq-ads.php?**
AD http://shkbanner*.hk.ap.valuecommerce.com/**
ADSWF http://tech-report.com/ads/coolerguys.swf**
ADSWF http://**/(affiliates|affiliation|sponsors|sponsorlogo)/**.swf**
ADSWF http://g.fool.com/art/free/moneyadvisor/**[0-9]x[0-9]**.swf
ADSWF http://(www*.|)kongthumbz.com/uv-hor*.swf?**
ADSWF http://ad.keenspace.com/Skotos/BannerBar.swf
ADSWF http://*/adflash/**.swf
ADSWF http://(www*.|)ottawabusinessjournal.com/www/*.swf
ADSWF http://(*.|)hardocp.com/ads/**.swf
ADSWF http://(*.|)hardocp.com/DA/**.swf
ADJS http://(www*.|)hk.co.kr/adscript/kt_ad_main.js
ADJS http://*/adserve?*;jscript;**
ADJS http://abcnews.go.com/jscript/hbe-v65-no10.js
ADJS http://adimages.go.com/ad/sponsors/utilities/adinsert.js
ADJS http://(*.|)hardocp.com/?DC=**JS=Y**
ADJS http://ads.adservingcentral.com/?**JS=Y**
AD http://(*.|)hardocp.com/?SIT=**
AD http://(*.|)hardocp.com/ugossi/*.(gif|jpg)
ADHTML http://(*.|)hardocp.com/?DC=**DH=Y**
ADHTML http://(*.|)hardocp.com/ugossi/*.(html|php)
ADHTML http://ads.adsonar.com/adserving/getAds.jsp?**
ADHTML http://www.streamate.com/exports/tour/?**&otype=html**
ADHTML http://(www*.|)rapigator.f2s.com/topframe.html
ADHTML http://ebiz.xxx-access.com/topframe.php**
ADPOPUP http://(www*.|)rapigator.f2s.com/tell.html
PASS http://(www*.|)rapigator.f2s.com/images/logo.gif
PASS http://(www*.|)rapigator.f2s.com/images/screenshot.gif
PASS http://(www*.|)rapigator.f2s.com/images/rapsource.gif
PASS http://(www*.|)rapigator.f2s.com/images/wow.gif
PASS http://(www*.|)rapigator.f2s.com/images/subscribe.gif
AD http://(www*.|)rapigator.f2s.com/images/*.gif
AD http://(www*.|)goto.com/images-promoters/**.gif
AD http://a*.qz3.net/**/www.eyewonder.com/customerSpace/**.jpg
AD http://213.219.40.69/*-125x1251.gif
AD http://4.78.22.8/cc*.gif
AD http://(www*.|)theinquirer.net/*-125x1251.gif
AD http://oasis1.economy.com/oasisi.php?**
AD http://mds.centrport.net/mdsefc?**
AD http://iad.anm.co.uk/*/[1-9]*.gif
AD http://(www*.|)domainbuster.com/bizad.gif
AD http://(www*.|)novuslink.net/images/*[0-9]x[0-9]*.gif
AD http://(www*.|)dagbladet.no/*/gavetips/150x500.gif
AD http://(www*.|)dn.no/ads.dn.no/**.gif
AD http://e2.emediate.se/media/**
AD http://(www|gfx).dagbladet.no/an/**
AD http://(www*.|)libertyhaven.com/images/*banner.gif
AD http://(www*.|)itv-f1.com/images/partners/*.gif
AD http://*/@*?
AD http://(www*.|)jspinsider.com/images/*.gif
AD http://(www*.|)cera2.com/*1ogo.gif**
AD http://images*.blogads.com/**/c.gif?**
AD http://**/blogads/**/thumb?**
AD http://(www*.|)komotv.com/art/frontbadges/**
PRINT http://(www*.|)komotv.com/stories/([0-9]*[0-9]).htm http://www.komotv.com/news/printstory.asp?id=$2
ADJS http://*.blogads.com/**/feed.js
WEBBUGHTML http://hb.lycos.com/header?**
WEBBUG http://dynamic.fmpub.net/adserver/adlog.php?**
WEBBUG http://tenzing.fmpub.net/?**
WEBBUGJS http://static.fmpub.net/tracking/**
WEBBUGJS http://static.fmpub.net/site/**
WEBBUGJS http://edge.quantserve.com/quant.js
WEBBUGJS http://*.imrworldwide.com/v5.js
COUNTERJS http://*.imrworldwide.com/*.js
REWRITE http://switch.atdmt.com/action/msn_hm_*_signup_link?href=(**) $1
WEBBUG http://acvs.mediaonenetwork.net/client/pixel.gif
WEBBUG http://pixel.quantserve.com/pixel**
WEBBUG http://*.imrworldwide.com/cgi-bin/m?**
WEBBUG http://*.imrworldwide.com/cgi-bin/count**
WEBBUG http://images-aud.slashdot.org/pc.gif?**
WEBBUG http://switch.atdmt.com/action/**
WEBBUG http://**/sitestats.gif?**
WEBBUG http://webhit.aftenposten.no:8080/servlet/WebHit?**
WEBBUG http://cluster.chart.dk/chart.asp?**
WEBBUG http://*.chart.dk/chart.jsp?**
WEBBUG http://jmm.livestat.com/E
WEBBUG http://(www*.|)toplist.cz/count.asp?**
WEBBUG http://(www*.|)whispa.com/tracking/exposure.dll?**
WEBBUG http://*.clickzs.com/in.gif?**
WEBBUG http://(www*.|)click-safe.com/trk**.gif
WEBBUG http://gold.weborama.fr/fcgi-bin/comptage.fcgi?**
WEBBUG http://(www*.|)cnn.com/cookie.crumb
WEBBUG http://cbs.marketwatch.com/1.gif
WEBBUG http://images*.slashdot.org/Slashdot/pc.gif?**
WEBBUG http://dot.idot.cz/?**
WEBBUG http://(*.|)vibrantmedia.com/system/SetURLCookie.asp?**
WEBBUG http://(*.|)vibrantmedia.com/**/1x1.gif
AD http://*.dynamitedata.com/cgi-bin/display_image.pl?**
AD http://*.dynamitedata.com/pods/**.(jpg|gif)
AD http://itxt.vibrantmedia.com/al.asp?ipid=**
ADHTML http://itxt.vibrantmedia.com/al.asp?**
WEBBUGHTML http://*.dynamitedata.com/cgi-bin/search.pl?**
ADHTML http://*.bbmedia.cz/please/showit/**?typkodu=html**
ADJS http://*.bbmedia.cz/please/showit/**?typkodu=js**
ADJS http://*.dynamitedata.com/pods/**.js
ADSWF http://*.im.cz/reklama/**.swf**
ADSWF http://*.im.cz/r/**.swf**
ADSWF http://(www*.|)seznam.cz/rek/**.swf
ADSWF http://(www*.|)svethardware.cz/adv/adv.nsf/**.swf**
ADSWF http://mainos.*.fi/**.swf**
ADSWF http://*.bbmedia.cz/logos/*.swf**
ADSWF http://ad*.lupa.cz/**.swf**
PASS http://imgfarm.com/images/weather.com/**
## BEGIN Sami Sundell zaps rules
# www.lumitykki.net
WEBBUG http://www.lumitykki.net/mainostus/adlog.php?*
AD http://www.lumitykki.net/mainokset/*.gif
ADSWF http://www.lumitykki.net/mainokset/*.swf
ADJS http://track.adform.net/BPL/*
AD http://track.adform.net/Adf/*
# www.radiocity.fi
ADSWF http://www.kiss.fi/images/skabat/hitmedia_win.swf
# www.alypaa.com
ADHTML http://alypaa.com/voice
# www.msn.fi
WEBBUG http://c.msn.fi/c.gif?**
ADSWF http://track.adform.net/Flash/**
ADSWF http://track.adform.net/**.swf**
# www.iltalehti.fi
ADSWF http://www.iltalehti.fi/ilmkuvat/**.swf?**
AD http://www.iltalehti.fi/ilmkuvat/**.gif
WEBBUG http://stat.www.fi/**
WEBBUG http://stat.almamedia.fi/**
# www.fmi.fi
AD http://www.fmi.fi/img/fi/Talvi.gif
# www.digitoday.fi
WEBBUG http://www.digitoday.fi/services/adlog.php?*
AD http://www.digitoday.fi/services/images/*.gif
ADSWF http://www.digitoday.fi/services/images/*.swf?**
# mycroft.mozdev.org
WEBBUG http://stat.onestat.com/asp/stat.asp?*
# www.digicamera.net
AD http://www.digicamera.net/cgi*/showsell.pl?**
# www.shooshtime.com
AD http://www.shooshtime.com/uploaded/sl1.gif
ADHTML http://www.shooshtime.com/adserver/view.php?*
ADHTML http://www.shooshtime.com/affiframe.php
ADHTML http://shooshtime.com/afffp.php
ADHTML http://www.dumpanimage.com/aff/aff.html
ADHTML http://promo.cams.com/promo/*frame.jsp**
ADHTML http://promo.ulust.com/cgb/index*.php?**
AD http://images.ulust.com/**
AD http://graphics.adultfriendfinder.com/images/piclist/promo/**.jpg
ADJS http://adultfriendfinder.com/piclist?*
ADJS http://banners.adultfriendfinder.com/piclist?*
ADHTML http://banners.adultfriendfinder.com/piclist?**
ADHTML http://banners.adultfriendfinder.com/go/page/**
ADPOPUP http://www.adultactioncam.com/?*
ADPOPUP http://www.datecam.com/exits_dynamic/index.php?*
ADSWF http://graphics.pop6.com/banners/**.swf
ADSWF http://player.videosz.com/win-style-dark.swf
# www.engadget.com
ADSWF http://*.engadget.com/common/media/griffin.swf
# www.ragnaranchorage.tk
ADPOPUP http://banners.dot.tk/bmcbanner?*
## END Sami Sundell zaps rules
AD http://imgfarm.com/images/**.gif
AD http://ad*.lupa.cz/cgi-bin/banredir.cgi?**
AD http://mainos*.fi/mainoskuvat/**.(gif|jpg)
AD http://(www*.|)mtv3.fi/ks/img/ttlogo.gif
AD http://(www*.|)mtv3.fi/uutiset/img/*_mainos.gif
AD http://(www*.|)veikkaus.fi/mtv3/i/*_mtv3.gif
AD http://*.im.cz/reklama/**
AD http://ad*.billboard.cz/**
AD http://ad*.atlas.cz/ban/**
AD http://dbbsrv.com/image/[0-9]**
AD http://i.m3.net/**.gif
AD http://*.bbmedia.cz/please/showit/**?typkodu=img**
AD http://*.bbmedia.cz/logos/*.gif**
AD http://(www*.|)bbmedia.cz/logos/*.gif?**
AD http://ad.*.cz/ad/*banner?**
AD http://ad.leadcrunch.com/show.html?**
AD http://ad*/AdRun.dll?**
AD http://ad*/adrun.dll?**
AD http://ad*/adimg*.asp?**
AD http://www.thaile.com/cgi-bin/f/start.pl?action=be&**
AD http://img.thaile.com:8080/images/**.gif
AD http://(www*.|)adbanner.cz/img/**
AD http://(www*.|)adbanner.cz/**/[Bb]an*.jpg
ADHTML http://(www*.|)banner.cz/showbanner2.php3?**
ADJS http://(www*.|)banner.cz/showbanner.php3?**
ADJS http://(www*.|)awin1.com/awshow.php?**
ADSWF http://channel.mobil.cz/flash/*.swf
AD http://*.billboard.cz/link/banner.cgi?**
AD http://*.idnes.cz/**.asp?baner=**
ADJS http://(www*.|)[Pp]ay[Pp]opup.com/popup.php?**
ADJS http://banner.0catch.com/cgi-bin/popup_mainsite.js
ADJS http://textlink.webmersion.com/cgi-bin/text_server.js
ADJS http://ad.idnes.cz/**.js?**
ADJS http://ad.iaa.cz/ad/**.js
ADJS http://asn.premium.cz/**.js
ADHTML http://ad*.atlas.cz/adhtml*.asp?**
PASS http://www.professionalmuscle.com/[Pp][Mm]_[Ll]ogo*.(gif|jpg)
AD http://www.professionalmuscle.com/*.(gif|jpg)
AD http://ad.lupa.cz/cgi-bin/banredir.cgi?**
AD http://ad.adrenaline.cz/adrun.dll?**
AD http://arbo.bbmedia.cz/logos/**
WEBBUG http://www.toplist.cz/count.asp?**
WEBBUG http://*.falkag.de/dat/bgf/trpix.gif?**
WEBBUG http://1bg.cqcounter.com/cgi-bin/c?**
WEBBUG http://stats.clickability.com/t.gif**
WEBBUG http://f2nsmh.*.2o7.net/b/ss/f2nsmh/1/**
AD http://ad.linx.sk/adrun.dll?**
AD http://ad.linx.sk/AdRun.dll?**
AD http://(www*.|)yceml.net/[0-9]**.gif
AD http://(www*.|)dialerfactory.com/**banner*.gif
AD http://content.cpxinteractive.com/**.(gif|jpg)
ADSWF http://*/dat/bgf/**.swf?**
ADSWF http://(www*.|)dialerfactory.com/**.swf
ADSWF http://members.home.nl/**/sexmaxxscroll*.swf
ADSWF http://suburbancrackhouse.org/**.swf
ADSWF http://(*.|)imdb.com/flash/*.swf
##ADSWF http://*.imdb.com/media/imdb/**.swf**
ADSWF http://(www*.|)burnoutpc.com/images/banners/**.swf
ADSWF http://(www*.|)alinom.com/t/**.swf**
ADSWF http://**/ad*[0-9]x[0-9]*.swf**
ADSWF http://(www*.|)stickyhole.com/archivbanner/**.swf**
ADSWF http://*/xxxmovieforum/posttemplateflash*/imgs/*.swf
ADSWF http://*twinkys.com/flash/**.swf
ADSWF http://(www*.|)hankooki.com/adflash/*.swf**
ADSWF http://images.bigfoot.com/images/en/directory/dir_header_*.swf
AD http://images.bigfoot.com/images/en/directory/header_girls.jpg
ADJS http://*twinkys.com/js/*.js
AD http://*twinkys.com/if/*.gif
AD http://(www*.|)smutserver.com/**/120x60.gif
AD http://images.smutserver.com/*.gif
AD http://hose-hounds.com/df/df*.jpg
PASS http://(www*|.)businessweek.com/bwdaily/dnflash/*/nf*.htm
ADHTML http://(www*.|)businessweek.com/bwdaily/dnflash/**.htm
ADHTML http://*-dialer.com/autoload.cfm?**
ADHTML http://(www*.|)start.com.au/startx/system/tracking/tracking_countclicks.asp?**
ADHTML http://oldstats.gamers.com/banman.asp?**
ADHTML http://gamershell.com/ad/*.html
ADHTML http://web.icq.com/client/ate/ad-handler/0,,clrcv,00.htm
ADHTML http://ad.sales.olympics.com/adl/**
ADHTML http://(www*.|)heatsink-guide.com/ad.htm
ADHTML http://messenger.netscape.com/bookmark/*/messengerstart.html
ADHTML http://(www*.|)ppruneadvertising.com/cgi-bin/ads_nonssi.cgi?iframe
ADHTML http://tvdk.bannerstats.dk/adiframe.php?**
AD http://tvdk.bannerstats.dk/bannerdir/*.gif
AD http://(www*.|)olivant.fo/lysingar/**
AD http://(www*.|)portal.fo/lysingar/**
AD http://(www*.|)sportal.fo/lysingar/**
AD http://(www*.|)nitsoh.com/emp.gif
AD http://(www*.|)nummar.fo/graphics/lysingar/**
AD http://(www*.|)decroix.net/Button/but*.gif
AD http://(www*.|)uf.fo/images/lysingar/**
AD http://(www*.|)bil.fo/*.gif
AD http://(www*.|)tele.fo/lysingar/**
AD http://(www*.|)seoghoer.dk/pics/*.gif
PASS http://blog.koehntopp.de/exit.php?**
ADSWF http:/www*.betway.com/itat?action=asset_req**
ADSWF http://hingis.betway.com/tbm/IT/TBM_foot/*.swf**
ADHTML http://netshelter.adtrix.com/serve.cgi?**
ADHTML http://(www*.|)ecasinoads.com/*.htm
ADHTML http://adisfy.com/iAd.php
ADHTML http://(www*.|)zipzoomfly.com/jsp/AD_Banner/*.jsp
ADHTML http://network.boyis.com/traffic/topframe.asp?**
ADPOPUP http://network.boyis.com/traffic/maiocco.asp?ADV=**
ADPOPUP http://(www*.|)planetlucky.com/retail/offer.asp?**
ADPOPUP http://(www*.|)ig.com.br/paginas/pop_ups/**
ADPOPUP http://*uol.com.br/janelas_assinantes/**
ADPOPUP http://*uol.com.br/janelas_visitantes/**
ADPOPUP http://cancaonova.org.br/janela.html
ADPOPUP http://(www*.|)smartredirect.com/smartredirect_ad.html
ADPOPUP http://(www*.|)smartredirect.com/smartredirect_ad.php?**
ADPOPUP http://(ad.|ads.|www.|)multimania.*/**/perso.phtml?**
ADPOPUP http://pub.chez.com/cgi-bin/perl/popup.pl/**
ADPOPUP http://perso.club-internet.fr/html/Popup/popup_frame*.html
ADPOPUP http://(www*.|)club-internet.fr/pagespersos/popup.phtml
ADPOPUP http://(www*.|)freestuffcenter.com/pop-up/
ADPOPUP http://(www*.|)uol.com.br/janelas_visitantes/ilimitado_comvc.htm
ADPOPUP http://*.com.br/publicidade/publicidade_popup_body.php3?**
ADPOPUP http://(www*.|)brassmonkey.net/link.htm
ADPOPUP http://(www*.|)cash4xxx.de/php-bin/exitwin.php?**
ADPOPUP http://(www*.|)adbuyindex.com/exitwindow.asp?**
ADPOPUP http://66.40.21.115/pop.html
ADPOPUP http://63.215.140.157/xit/**/index.html
ADPOPUP http://213.132.197.200/pm/popup.php**
ADPOPUP http://*/pop.phtml?**
ADPOPUP http://add.buzina.com/*popup*.html
ADPOPUP http://add.buzina.com/*exit*.html
ADPOPUP http://popup.scambiositi.com/advcode.php?**
## ADPOPUP http://**/ctc.cgi?*
ADPOPUP http://(www*.|)geocities.com/toto?*
ADPOPUP http://geocities.yahoo.com/toto?*
ADPOPUP http://*.tripod.*/adm**/popup**.shtml**
ADPOPUP http://*.tripod.com/adm**/popunder/**
ADPOPUP http://(www*.|)hitstation.com/Adserve/banner.cfm?t=1
ADPOPUP http://(www*.|)angelfire.com/cgi-bin/admem?*
ADPOPUP http://(www*.|)angelfire.com/sys/popup_source.shtml*
ADPOPUP http://(www*.|)freewebsites.com/banner/console.html
ADPOPUP http://*lolita-free.com/?**
ADPOPUP http://(www*.|)multimania.fr/general/pub/perso.phtml?**
ADPOPUP http://pub.chez.com/cgi-bin/perl/popup.pl/**
ADPOPUP http://(www*.|)popuptraffic.com/assign.php?**
ADPOPUP http://php.offshoreclicks.com/imps.php?**
ADPOPUP http://php.offshoreclicks.com/dialup_files/install.php?**
ADPOPUP http://arsconsole.global-intermedia.com/*.php?**
ADPOPUP http://all.global-intermedia.com/index.php?**
ADPOPUP http://(www*.|)reliaquote.com/banner/AdBaner/**
ADPOPUP http://(www*.|)time.com/time/interstitials/inter_mt.html?**
ADPOPUP http://(www*.|)time.com/time/interstitials/td_popprem_pi.html?**
ADPOPUP http://search.sprinks.about.com/library/dist/sperch2.htm?siteid=awspop&**
ADPOPUP http://files.slutsandladies.com/**/out*.htm*
ADPOPUP http://(www*.|)business2.com/subs/b2_puord.html?**
ADPOPUP http://bidclix.net/PopUps/Popup*.jsp?**
ADPOPUP http://images.v3.com/pop*.htm
ADPOPUP http://(www*.|)hitboss.com/*/*.htm
ADPOPUP http://(www*.|)hightrafficads.com/conframe.html?**
ADPOPUP http://media.fastclick.net/w/click.here?**pop=**
ADPOPUP http://offers.mailpref.go.com/offers
ADPOPUP http://(www*.|)nextcard.com/pxweb/**.jhtml
ADPOPUP http://instant-access.sex-explorer.com/w_ncc/warning/index.php?**
ADPOPUP http://(www*.|)nakednews.com/exit*.html
ADPOPUP http://(www*.|)xxxsexyweb.com/newspop.htm
ADPOPUP http://(www*.|)premier-blind.com/hardcore/*.html
ADPOPUP http://205.180.85.40/*special/
ADPOPUP http://home.talkcity.com/homepopup.html?**
ADPOPUP http://**/subpopup*.html
ADPOPUP http://**/mainpopup*.html
ADPOPUP http://*.mytoday.de:8200/mytoday/popup.html?**
ADPOPUP http://(www*.|)insands.com/lspop*.htm
ADPOPUP http://(www*.|)insands.com/*popup*.htm
ADPOPUP http://(www*.|)nextcard.com/pxweb/**.*html;**
ADPOPUP http://(www*.|)karasxxx.com/potd/*.shtml**
ADPOPUP http://www.daily*.com/poptopdownloads.html
ADPOPUP http://storefront.linksynergy.com/fs-bin/store?**
ADPOPUP http://(www*.|)yourwebguide.com/interneteraser*.html
ADPOPUP http://www.pokerroom.com/
ADPOPUP http://(www*.|)technologyreview.com/2free_popup.asp?ad=**
ADPOPUP http://(www*.|)mtreexxx.net/cpd/freepass/indexLC.html?**
ADPOPUP http://(www*.|)free*pass.com/free_exit/**.(htm|php)**
ADPOPUP http://(www*.|)hentai-top100.com/cgi-bin/rankem.cgi?**
ADPOPUP http://64.239.23.77/Utils/timer_**.(asp|html)
ADPOPUP http://64.239.23.77/MiniNav/**.(asp|html)
ADPOPUP http://(www*.|)fucking24x7.com/aff.html
ADPOPUP http://(www*.|)smashingthumbs.com/eliminator.html
ADPOPUP http://pop.adultplatinum.com/console/*.htm**
ADPOPUP http://pop.mircx.com/pop/default/pop/**
ADPOPUP http://pop.mircx.com/pop/cjb/pop/**
ADPOPUP http://fr.wedoo.com/ranking/popup/*.*html**
ADPOPUP http://programs.wegcash.com/exits/?**
ADPOPUP http://exits.filthyclicks.com/**
ADPOPUP http://adultdreams.com/randommulti/**.shtml**
ADPOPUP http://(www*.|)prosolutionpills.com/popup/*.html
ADPOPUP http://shopping.webmarket.com/exitpage/*.html
ADPOPUP http://*/exit*.(html|php)**
ADPOPUP http://*/the-exit.php
ADPOPUP http://(www*.|)tier1network.com/poppage-exit.htm**
ADPOPUP http://(www*.|)johnefrem.com/javab/jpop/**.html
ADPOPUP http://console.popupsponsor.com/media/ads/spec_pop.phtml?**
ADPOPUP http://(www*.|)statster.com/server/?**
ADPOPUP http://ads.popupsponsor.com/media/ads/*.phtml
ADPOPUP http://62.146.220.26/*/
ADPOPUP http://(www*.|)crazypopups.com/server/index.php?**
ADPOPUP http://(www*.|)exchangepopups.com/epop.php?**
ADPOPUP http://ad.ilse.nl/popunder.dbl?**
ADPOPUP http://(www*.|)latinmail.com/popup_*.html
ADPOPUP http://(www*.|)datafull.com/**/popup*.(htm|php)
ADPOPUP http://pollserver.interpolls.com/cache/**.html
ADPOPUP http://www.military.com/Data/Popup/New_Education_Popunder.htm
ADPOPUP http://popups.crosswinds.net/popup*.php?**
ADPOPUP http://www.galttech.com/count*.shtml
AD http://(www*.|)datafull.com/popups/*.gif
AD http://bitzi.com/image/bitzipanel-*.gif
AD http://img.suprnova.org/template/sideads/*.(gif|jpg|png)
AD http://(www*.|)p2pnet.net/images/*.gif
AD http://(www*.|)labyrinth.net.au/~mdem/cgi-bin/Advertising/**.gif
AD http://(www*.|)ezydvd.com.au/g/i/b/46860/*.gif
AD http://jnova.cjt1.net/HTM/**JavaSiteReport.asp?**URL=**.gif
AD http://jcontent.bns1.net/bns/**.gif
AD http://www.mecha.ne.jp/~wtw/2CH-*.gif
AD http://flash.2ch.net/image/*bn.gif
AD http://www2.2ch.net/2ch.gif
AD http://2ch.sakuraplus.com/images/*.gif
AD http://teeshot.maido3.com/strap/strap.jpg
ADSWF http://(www*.|)zipzoomfly.com/images/bnr/*.swf**
ADSWF http://jcontent.bns1.net/bns/**.swf**
ADSWF http://www.ezydvd.com.au/g/i/b/46860/*.swf
ADSWF http://(www*.|)datafull.com/flash/*.swf
ADSWF http://(www*.|)madman.com.au/flash/random-*.swf
ADSWF http://www.cyber-traffic.net/cgi/rank3.php
ADSWF http://www.cyber-traffic.net/2ch/link.php
ADSWF http://ad.detik.com/images/**.swf
ADSWF http://media.baventures.com/*.swf**
ADSWF http://icons.ilse.nl/patch/c4sales/*.swf?id=**
ADJS http://view.popupsponsor.com/media/lx.js?**
ADJS http://tpl*.realtracker.com/netpoll/ifreev3ia.asp?**
ADHTML http://j.2004cms.com/HTM/**JavaSite(Report|Request).asp**
ADHTML http://tpl*.realtracker.com/netpoll/MHWAdLookup.asp?AdID=*
ADHTML http://jupiter.bravenet.com/rover/f?*ctype=0*
ADHTML http://www.wallpaperlove.com/bonus.htm
ADHTML http://(www.|)adtology*.com/**.htm
ADHTML http://ads.datinggold.com/iframe*.php?**
ADHTML http://adweb2.hornymatches.com/bthumb/page.php?**
ADHTML http://*.falkag.(de|net)/server/rich.asp?cmd=ifr&**
ADJS http://*.falkag.(de|net)/dat/**.js
ADPOPUP http://*.falkag.(de|net)/server/rich.asp?**
AD http://*.falkag.(de|net)/server/?**
AD http://*.falkag.(de|net)/dat/bgf/**.gif
AD http://falk.speedera.net/dat/**.gif
AD http://*.afcyhf.com/**
AD http://stats.popupsponsor.com/pv-trck.php?**
AD http://destiny.autonomous.co.uk/destiny/servlet/autonomous.destiny.hit.AdHitServlet?**
AD http://(www*.|)astalavista.box.sk/*[0-9].(gif|jpg)
AD http://(www*.|)astalavista.box.sk/*-ani.gif
AD http://desktopsunlimited.com/images/virtual*.gif
AD http://**/virtuagirl*_[1-9]*[Xx][1-9]*.gif
AD http://(www*.|)animewallpapers.com/h/tcg/ban**.gif
AD http://*ads.datinggold.com/(pic|show.banner)*.php?**
AD http://www.wallpaperlove.com/*messages.gif
AD http://icons.ilse.nl/icons/adverts/**.(gif|jpg)
AD http://*.tradedoubler.com/imp/img/**
ADJS http://*.tradedoubler.com/imp/pool/js/**
ADJS http://destiny.autonomous.co.uk/destiny/servlet/autonomous.destiny.hit.PosHitServlet?**
ADJS http://ad*.nakednews.com/rotatetag.html
ADJS http://bidclix.net/js/pop.jsp?**
ADJS http://addictivetechnologies.net/*/js/Confirm*.js
ADJS http://install.xxxtoolbar.com/ist/scripts/prompt.php?**
ADJS http://espacio.ya.com/js/mosca.js
ADJS http://espacio.ya.com/js/var_mosca.js
ADJS http://(www*.|)bravenet.com/jsbanner.php?**
ADJS http://(www*.|)adv-network.org/advpop/js.php?**
ADJS http://srs.targetpoint.com/resources/inc/banner.js
ADJS http://ads.adorigin.com/?**JS=Y**
ADJS http://ads.digitalacre.com/motor?**
AD http://admin.digitalacre.com/images/**.(GIF|gif)
AD http://cyber-knowledge.net/blog/images/hm.gif
AD http://sportsbybrooks.com/farkbutton.gif
AD http://huuto.net/fi/huutonet/bannerit/*
AD http://ads.**.(gif|jpg|jpeg)
AD http://*.ads.**.(gif|jpg|jpeg)
AD http://ad.erotik-click.de/banner/*.gif
AD http://(www*.|)joinfree.ro/adult20.jpg
AD http://(www*.|)gm.com/nonflash_homepage/images/story*.jpg
AD http://ads.adorigin.com/?SIT=**
AD http://*/kanoodle_img.php?**
AD http://(cachep|promos).fling.com/geo/**.jpg
AD http://exit.silvercash.com/exit/**.(jpg|gif)
AD http://pics.camazon.com/**
AD http://pcash.imlive.com/releasese/images/**.gif
AD http://*.img.awempire.com/**.jpg
ADHTML http://adson.awempire.com/iframes/**
ADHTML http://iframes.awempire.com/**
ADHTML http://geo.camazon.com/?**
ADHTML http://exit.silvercash.com/exit/**.html
ADHTML http://ts.protraffic.com/as.html?**
ADHTML http://promos.fling.com/geo/custom/home.htm?**
ADHTML http://promos.fling.com/static/**.htm?**
ADHTML http://pcash.imlive.com/releasese/ActivePage*.asp?**
ADHTML http://*.wecloseyoursales.com/**.asp
ADHTML http://ads.webcamclub.com/iframe/?**
ADHTML http://fapomatic.com/aff*.html
ADHTML http://context*.kanoodle.com/cgi-bin/ctpub_adserv.cgi?id=**
ADHTML http://ads.adorigin.com/?**DH=Y**
ADHTML http://adzones.torrentspy.com/ad*.htm
ADHTML http://ad.adperium.com/st?ad_type=iframe&**                              
ADHTML http://*.cltomedia.info/delivery/afr.php?**                              
REWRITE http://*/ct/*.php?**&ctg=(**)\*\*** 302:$1
REWRITE http://xit.sexlist.com:81/?TSLID=149199/(http://**) 302:$1
REWRITE http://xxxonice.com/ct/cx.php?action=frm&**&src=(http://**)\*\*3F\*\*ids=** 302:$1
REWRITE http://xxxonice.com/ct/cx.php?action=frm&**&src=(http://**) 302:$1
REWRITE http://eurothumb.com/ct/gal.php?**&ctg=(http://**) 302:$1
REWRITE http://(*).freecyberzone.com/cgi-bin/i/images/(**) http://$1.freecyberzone.com/images/$2
REWRITE http://((www*.|)belladonnarealm.com)/downloads/view.php?photo_id=(*)&screen=** http://$1/downloads/pics/$3.jpg
PASS http://(www*.|)ibm.com/common/stats/stats.js
COUNTERJS http://**/stats.js
COUNTERJS http://*.surfaid.ihost.com/**
COUNTERJS http://**/sacdcoc.js
COUNTERJS http://**/track.js?**
COUNTER http://*.legarde.com/cans.php?page=**
COUNTER http://xyz.freeweblogger.com/counter/index.php?**
COUNTER http://counter*.house*.ch/counter/live.php?**
COUNTER http://*.foxcounter.com/foxcounter.php?**
COUNTER http://**/uc.GIF?**
# Nimda defense from Boi
# See: http://(www*.|)incidents.org/react/nimda.php, "DETAILS OF WEB BROWSER-BASED PROPAGATION:"
ADPOPUP http://**/readme.eml
HR http://**/anmcolbar.gif
HR http://(www*.|)geocities.com/SunsetStrip/Hotel/4447/bar.gif
HR http://**/barflash.gif
HR http://**/movingrainbowbar.gif
HR http://(www*.|)crosswinds.net/~donaldhinds/gif/line09a.gif
HR http://home.beseen.com/hobbies/gammaray2/tiles11.GIF
# NEXT http://home.att.net/~swchoe/next.gif
# PREV http://home.att.net/~swchoe/previous.gif
# Uber regexp to zap content from dodgy clients of doubleclick
# funneling hijack code through their flash advertising.
# Should probably remove this in a year (i.e. Nov2008).
# Ref: http://it.slashdot.org/article.pl?sid=07/11/19/1517209
# Ref: http://www.wired.com/techbiz/media/news/2007/11/doubleclick
# Ref: http://blog.wired.com/business/2007/11/doubleclick-red.html
ADSWF http://(*.|)(100it.info|10smi.info|2greatfind.com|2quickfind.com|3akoh.net|ad2cash.net|ad2profit.com|adcomatoz.com|adgurman.com|adhokuspokus.com|adnetserver.com|adredired.com|adsolutio.com|adtraff.com|adverdaemon.com|adverlounge.com|adzyclon.com|alg-search.com|alhoster.com|aligarx.biz|all-search-it.com|alphatown.us|anmira.info|anonymbrowser.com|antivirussecuritypro.com|aptprog.com|art-earn.biz|astalaprofit.com|autodealer-search.com|b2adz.com|bazaard.com|belkran.com|belshar.com|bestadmedia.com|best-biznes.info|best-cools.info|bestdatafinder.com|besteversearch.com|bestpharmacydeals.com|best-screensavers.biz|bestsearchnet.com|bestshopz.com|bestwm.info|bestwnvmovies.com|bezzz.info|bi-bi-search.com|bizadverts.com|bizmarketads.com|blessedads.com|bm-redy.com|bovavi.com|brandmarketads.com|bucksinsoft.com|burnads.com|cancerno.com|candid-search.com|carpropane.com|cashloanprofit.com|casinoaceking.com|casinoby.com|casinodealsgalore.com|cha-cha-search.com|cheap-auto-deals.com|checkstocklist.com|chushok.com|clever-at-search.com|clubheat.info|come-from-stars.com|co-search.com|creamme.net|cryptdrive.com|cyndyk.info|deuscleanerpay.com|didosearch.com|diphelp.biz|dmitry-v.info|doma2000.com|durtsev.com|easybestdeals.com|energostroj.com|enothost.com|eroticabsolute.com|errordigger.com|errorinspector.com|evrogame.info|fandasearch.com|fantazybill.com|fastwm.info|fastzetup.info|fati-gati-search.com|favourable-search.com|favouriteshop.com|feel-search.com|f-host.net|fifaallchamp.com|fight-arts.com|fileprotector.com|findbyall.com|firstbestsearch.com|firstlastsearch.com|first-ts.com|foamplastic.net|fokus-search.com|force-search.com|forceup.com|forex-instruments.info|forvatormail.com|freepcsecure.com|freerepair.org|freetvnow.net|friedads.com|fulsearch.com|getfreecar.com|gibdd.us|glass-search.com|glorymarkets.com|gosthost.net|great4mac.com|greyhathosting.com|gt-search.com|hackerpro.us|hardlinecenter.com|hebooks-service.com|hintway-international.com|homeofsite.com|hromeos.com|hyip2all.org|icq-lot.org|iddqdmarketing.com|ideal-search.com|idea-rem.com|i-forexbank.biz|i-games.biz|imamis.net|individ-search.com|information-advertising.info|infyte.com|initial-search.com|insochi2014.com|installprovider.com|internetadaultfriend.com|internetanonymizer.com|internetsupernanny.com|intervarioclick.com|investmentsgroup.org|invulnerableads.com|it-translation.biz|izol-tech.com|kamerton-tests.com|kazilkasearch.com|keytooday.com|keywordcpv.com|kiridi.net|kpoba.net|kurgan45.info|ladadc.com|lanastyle.com|ldizain.info|libresystm.com|liders.biz|linii.net|liveclix.net|loffersearch.com|londasearch.com|lovecraft-forum.net|loveopen.info|lseom.biz|luckyadcoin.com|luckyadsols.com|mad-search.com|magicsearcher.com|mailcap.info|manage-search.com|marketingdungeon.com|mass-send.com|max-expo.net|maxyanoff.com|mediatornado.com|mega-project.biz|megashopcity.com|mightyfaq.com|misc-search.com|mobilesoftmarketing.com|mobiletops.com|mobilorg.org|moneycometrue.com|moneypalacecash.com|mounthost.net|myfavouritesearch.com|myhealth-life.org|myonlinefinance.com|mysurvey4u.com|mythmarketing.com|mytravelgeek.com|myusefulsearch.com|napol.net|navygante.com|netmediagroup.net|netturbopro.com|newbieadguide.com|nryb.com|of-by.info|olgalml.com|ol-search.com|onedaysoft.com|onestopshopz.com|onwey.com|opensols.com|original-search.com|osetua.com|osminog.org|parischat.org|passwordinspector.com|pcsoftw.com|pcsupercharger.com|performanceoptimizer.com|piramidki.com|podelkin.info|popadprovider.com|popsmedia.com|popupnukerpro.com|postcity.info|prenetsearch.com|prevedmarketing.com|prizesforyou.com|pro-dom.info|propotolok.info|pro-svet.info|r2d2adverising.com|radiosfera.net|rocktheads.com|roller-search.com|rombic-search.com|rus-invest.net|rusnets.info|russia-post.com|sajruen.info|samson-pro.com|sauni.net|se7ensearch.com|search-and-win.com|search-angle.com|searchcolours.com|searchcompleteness.com|search-deal.com|search-expand.com|search-into.com|searchmandrake.com|searchonline-ease.com|searchoperation.com|search-the-best.com|search-the-prey.com|searchvirtuoso.com|search-west.com|sellmoresoft.com|selvascreensaver.com|seorule.com|serebro1.info|sergp.info|sevna.org|sex-mp4.info|sharpadverts.com|shivanetworking.com|shootnix.net|shopshot.com|simplesamplesearch.com|siputa.com|smssrv.com|softgeeks.net|softwcs.com|sotaman.info|spbcoffee.info|sterx.org|stolovaya.info|stratosearch.com|such-search.com|sus-upp.com|svadba-buket.info|svadba-center.info|svadba-dress.info|svadba-rings.info|svadba-scenarii.info|svadba-toast.info|svadba-vikyp.info|takeheree.com|tallgrass-seach.com|the-same-search.com|traffalo.com|traveltray.com|treekindsearch.com|type-and-find.com|typeblogger.info|unicsearch.com|uniqads.com|unrealcommander.biz|unrealcommander.com|unrealcommander.info|unrealcommander.org|vip-mails.com|vitecmedia.com|vkpb.net|wape3a.net|waytotheprofit.com|web-feed.net|web-work.biz|wewillfind.com|windefender.com|windfiresearch.com|wmbserg.org|wmclick.info|wmdoxod.info|wmlasvegas.com|wmlasvegas.net|wmolotok.org|wmrabota.info|wm-source.info|wmzmails.info|wontu-search.com|wordwide.info|workhomecenter.com|work-world.info|world-promo.net|x-diesel.biz|x-diesel.com|x-diesel.info|x-diesel.net|x-diesel.org|x-lave.info|yourseeker.com|yourshopz.com|yourteacheronline.com|y-piter.com|zalex.info|zappinads.com|zapsibir.com|zooworld-search.com|zvukko.net)/**
### END AUTO __DATA__ AREA
