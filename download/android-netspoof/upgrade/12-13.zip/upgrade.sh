#!/bin/sh
chmod a+x /rewriters/adblock.pl
